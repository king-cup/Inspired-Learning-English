#!/usr/bin/env python3
"""Copy the audited v1.10 PWA into minimal Android assets reproducibly."""

from __future__ import annotations

import hashlib
import json
import re
import shutil
from pathlib import Path

ANDROID = Path(__file__).resolve().parent.parent
WEB = ANDROID.parent / "Vocab Drill Web"
TARGET = ANDROID / "app" / "build" / "generated" / "learner-assets" / "web"

ROOT_FILES = (
    "advanced-practice.json",
    "app.css",
    "reader.css",
    "passage-glossary.json",
    "audio-index.json",
    "audio-packs.json",
    "cloze.json",
    "curriculum-audit.json",
    "index.html",
    "manifest.webmanifest",
    "middle-school.json",
    "reading-audio-manifest.json",
    "reading-content.json",
    "release-policy.json",
    "sw.js",
    "vocab.json",
)
DIRECTORIES = ("icons", "js")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def require_audited_release() -> None:
    reading = json.loads((WEB / 'reading-content.json').read_text())
    answers = json.loads((WEB / 'reading-answer-audit.json').read_text())['summary']
    if not reading.get('answerAuditVersion') or reading.get('editorialDraft') or answers['errors'] or answers['publicationBlockers']:
        raise SystemExit('refusing to package draft or unverified reading keys')
    audit = json.loads((WEB / "curriculum-audit.json").read_text(encoding="utf-8"))
    if audit.get("contentVersion") != "1.10" or audit.get("errors"):
        raise SystemExit("refusing to package an unaudited curriculum")
    if audit.get("readingArticles") != 144 or audit.get("recordings") != 144:
        raise SystemExit("refusing to package an incomplete reading release")


def main() -> None:
    require_audited_release()
    missing = [name for name in (*ROOT_FILES, *DIRECTORIES) if not (WEB / name).exists()]
    if missing:
        raise SystemExit("missing web release assets: " + ", ".join(missing))

    # TARGET is a fixed child of this Android project. Replacing it prevents a
    # removed web asset from lingering inside a later APK.
    if TARGET.exists():
        shutil.rmtree(TARGET)
    TARGET.mkdir(parents=True)

    for name in ROOT_FILES:
        shutil.copy2(WEB / name, TARGET / name)
    for name in DIRECTORIES:
        shutil.copytree(WEB / name, TARGET / name)

    # Preserve word audio offline, without duplicate per-book/unit packs.
    # Reading narration is fetched on demand from the PWA and cached locally.
    (TARGET / 'audio').mkdir()
    for slug in json.loads((WEB / 'audio-index.json').read_text()):
        shutil.copy2(WEB / 'audio' / (slug + '.m4a'), TARGET / 'audio' / (slug + '.m4a'))
    manifest = json.loads((WEB / 'content' / 'manifest.json').read_text())
    (TARGET / 'content').mkdir()
    shutil.copy2(WEB / 'content' / 'manifest.json', TARGET / 'content' / 'manifest.json')
    for key in ('vocabUrl', 'audioIndexUrl', 'audioPacksUrl'):
        if manifest.get(key): shutil.copy2(WEB / manifest[key], TARGET / manifest[key])
    # Minify data only in the package; source/audit formatting stays reviewable.
    for path in TARGET.rglob('*.json'):
        path.write_text(json.dumps(json.loads(path.read_text()), ensure_ascii=False, separators=(',', ':')))

    rows = []
    for path in sorted(p for p in TARGET.rglob("*") if p.is_file()):
        rows.append({
            "path": path.relative_to(TARGET).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        })
    manifest = {
        "release": re.search(r"APP_VERSION = '([^']+)'", (WEB / 'js/data.js').read_text()).group(1),
        "source": "Vocab Drill Web",
        "files": len(rows),
        "bytes": sum(row["bytes"] for row in rows),
        "assets": rows,
    }
    (TARGET / "android-release-manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(f"synced {len(rows)} files ({manifest['bytes'] / 1048576:.1f} MiB) to {TARGET}")


if __name__ == "__main__":
    main()
