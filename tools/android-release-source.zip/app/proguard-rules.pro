-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class com.vocabdrill.student.data.** {
    *** Companion;
}
-keepclasseswithmembers class com.vocabdrill.student.data.** {
    kotlinx.serialization.KSerializer serializer(...);
}
