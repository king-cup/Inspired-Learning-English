package com.vocabdrill.student

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.JsResult
import android.webkit.MimeTypeMap
import android.webkit.ServiceWorkerClient
import android.webkit.ServiceWorkerController
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import java.io.File
import java.io.FileNotFoundException

/**
 * v1.09 uses the final PWA as the single learner experience on Android. The
 * secure virtual origin lets ES modules, fetch(), Cache Storage and localStorage
 * behave exactly as they do on the installed web app while every release asset
 * is served from the APK.
 */
class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var migrationRunning = false

    private val pickFile = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        fileCallback?.onReceiveValue(uri?.let { arrayOf(it) })
        fileCallback = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            overScrollMode = WebView.OVER_SCROLL_NEVER
            settings.apply {
                javaScriptEnabled = true
                val version = packageManager.getPackageInfo(packageName, 0).versionName
                userAgentString = "$userAgentString InspiredEnglishAndroid/$version"
                domStorageEnabled = true
                databaseEnabled = true
                cacheMode = WebSettings.LOAD_DEFAULT
                mediaPlaybackRequiresUserGesture = true
                allowFileAccess = false
                allowContentAccess = true
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                setSupportMultipleWindows(false)
            }
            webViewClient = ReleaseAssetClient()
            webChromeClient = AppChromeClient()
        }
        ServiceWorkerController.getInstance().setServiceWorkerClient(object : ServiceWorkerClient() {
            override fun shouldInterceptRequest(request: WebResourceRequest): WebResourceResponse? =
                interceptReleaseAsset(request)
        })
        setContentView(webView)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    webView.url?.contains("#/") == true && webView.url?.endsWith("#/") == false ->
                        webView.evaluateJavascript("history.back()", null)
                    webView.canGoBack() -> webView.goBack()
                    else -> finish()
                }
            }
        })

        if (savedInstanceState == null) webView.loadUrl(APP_URL)
        else webView.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        webView.stopLoading()
        webView.destroy()
        super.onDestroy()
    }

    private inner class ReleaseAssetClient : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse? {
            return interceptReleaseAsset(request)
        }

        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest): Boolean {
            val uri = request.url
            if (uri.scheme == "https" && uri.host == APP_HOST) return false
            return runCatching {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
                true
            }.getOrDefault(true)
        }

        override fun onPageFinished(view: WebView, url: String) {
            super.onPageFinished(view, url)
            migrateLegacyDataOnce(view)
            refreshBundledShell(view, url)
        }
    }

    private inner class AppChromeClient : WebChromeClient() {
        override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
            AlertDialog.Builder(this@MainActivity)
                .setMessage(message.orEmpty())
                .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                .setOnCancelListener { result.cancel() }
                .show()
            return true
        }

        override fun onShowFileChooser(
            webView: WebView?,
            newCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
        ): Boolean {
            fileCallback?.onReceiveValue(null)
            fileCallback = newCallback
            pickFile.launch("application/json")
            return true
        }
    }

    private fun refreshBundledShell(view: WebView, url: String) {
        if (Uri.parse(url).host != APP_HOST) return
        val version = JSONObject.quote(packageManager.getPackageInfo(packageName, 0).versionName)
        // Older APKs installed a PWA worker. Retire only its shell caches;
        // keep localStorage, IndexedDB and downloaded audio intact.
        view.evaluateJavascript("""
            (async () => {
              const key = 'ie.androidAssetVersion';
              if (localStorage.getItem(key) === $version) return;
              if ('serviceWorker' in navigator) {
                const registrations = await navigator.serviceWorker.getRegistrations();
                await Promise.all(registrations.map(r => r.unregister()));
              }
              if ('caches' in window) {
                const names = await caches.keys();
                await Promise.all(names.filter(n => n.startsWith('vd-shell-')).map(n => caches.delete(n)));
              }
              localStorage.setItem(key, $version);
              location.reload();
            })().catch(error => console.error('Android shell upgrade failed', error));
        """.trimIndent(), null)
    }

    private fun migrateLegacyDataOnce(view: WebView) {
        val prefs = getSharedPreferences("web_release", MODE_PRIVATE)
        if (prefs.getBoolean(MIGRATION_KEY, false) || migrationRunning) return
        migrationRunning = true

        val progress = readLegacy("progress.json")
        val profile = readLegacy("profile.json")
        val script = """
            (() => {
              let changed = false;
              if (!localStorage.getItem('vd.progress.v1') && $progress !== null) {
                localStorage.setItem('vd.progress.v1', $progress); changed = true;
              }
              if (!localStorage.getItem('vd.profile.v1') && $profile !== null) {
                const raw = JSON.parse($profile);
                localStorage.setItem('vd.profile.v1', JSON.stringify({
                  name: raw.name || '', lang: raw.lang || 'en', inverted: !!raw.inverted,
                  cardsReversed: !!raw.cardsReversed, onboarded: !!raw.onboarded
                }));
                if (raw.lastUnit) localStorage.setItem('vd.lastUnit', raw.lastUnit);
                if (raw.lastBackupMs) localStorage.setItem('vd.lastBackup', String(raw.lastBackupMs));
                changed = true;
              }
              return changed;
            })()
        """.trimIndent()
        view.evaluateJavascript(script) { value ->
            prefs.edit().putBoolean(MIGRATION_KEY, true).apply()
            migrationRunning = false
            if (value == "true") view.reload()
        }
    }

    private fun readLegacy(name: String): String {
        val file = File(filesDir, name)
        return if (file.isFile) JSONObject.quote(file.readText()) else "null"
    }

    private fun safeAssetPath(path: String): String? {
        val clean = path.removePrefix("/").ifBlank { "index.html" }
        if (clean.split('/').any { it == ".." }) return null
        return clean
    }

    private fun interceptReleaseAsset(request: WebResourceRequest): WebResourceResponse? {
        val uri = request.url
        if (request.method != "GET" || uri.scheme != "https" || uri.host != APP_HOST) return null
        val assetPath = safeAssetPath(uri.path ?: "/") ?: return notFound()
        return try {
            val mime = mimeFor(assetPath)
            val charset = if (mime.startsWith("text/") || mime.contains("json") || mime.contains("javascript")) "UTF-8" else null
            WebResourceResponse(mime, charset, assets.open("web/$assetPath", android.content.res.AssetManager.ACCESS_STREAMING))
        } catch (_: FileNotFoundException) {
            notFound()
        }
    }

    private fun mimeFor(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
        "html" -> "text/html"
        "css" -> "text/css"
        "js", "mjs" -> "text/javascript"
        "json", "webmanifest" -> "application/json"
        "m4a" -> "audio/mp4"
        "ogg" -> "audio/ogg"
        "png" -> "image/png"
        "svg" -> "image/svg+xml"
        "ico" -> "image/x-icon"
        else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(path.substringAfterLast('.', "")) ?: "application/octet-stream"
    }

    private fun notFound() = WebResourceResponse(
        "text/plain", "UTF-8", 404, "Not Found", emptyMap(), "Not Found".byteInputStream()
    )

    companion object {
        private const val APP_HOST = "app.local"
        private const val APP_URL = "https://app.local/index.html#/"
        private const val MIGRATION_KEY = "legacy_native_to_web_v109"
    }
}
