package com.vocabdrill.student.data

import kotlin.random.Random

enum class QType { WORD_TO_MEANING, MEANING_TO_WORD, SENTENCE_GAP }

data class Question(
    val entry: Entry,
    val type: QType,
    val prompt: String,
    val subPrompt: String,
    val instruction: String,
    val options: List<String>,
    val correctIndex: Int
)

/**
 * Builds one multiple-choice item for a word, drawing its distractors from the
 * same unit so the choices are always plausible. Same part of speech is
 * preferred; if there aren't three of those, it falls back to the whole unit.
 */
object QuestionFactory {

    private const val GAP = " ______ "

    /**
     * [allowedTypes] restricts which question shapes may be produced. Test mode
     * passes the two recall directions only: a sentence gap shows the answer
     * inside its own example, which is a fair prompt while practising and a free
     * mark in an exam. Practice passes null and keeps all three.
     *
     * The filter is applied AFTER the candidate list is built, so a word that
     * can only support a gap still yields a question rather than nothing.
     */
    fun build(
        entry: Entry,
        pool: List<Entry>,
        rnd: Random,
        allowedTypes: List<QType>? = null
    ): Question {
        val canGap = entry.e.isNotBlank() &&
            entry.e.contains(entry.w.trim(), ignoreCase = true) &&
            entry.w.trim().length > 2
        val canMeaning = entry.c.isNotBlank()

        val candidates = buildList {
            if (canMeaning) add(QType.WORD_TO_MEANING)
            if (canMeaning) add(QType.MEANING_TO_WORD)
            if (canGap) add(QType.SENTENCE_GAP)
        }.ifEmpty { listOf(QType.MEANING_TO_WORD) }

        val types = if (allowedTypes == null) candidates else {
            candidates.filter { it in allowedTypes }.ifEmpty { listOf(allowedTypes.first()) }
        }

        return when (types[rnd.nextInt(types.size)]) {
            QType.WORD_TO_MEANING -> assemble(
                entry, pool, rnd,
                prompt = entry.w,
                subPrompt = entry.p,
                instruction = "What does this word mean?",
                answerOf = { it.c },
                type = QType.WORD_TO_MEANING
            )
            QType.MEANING_TO_WORD -> assemble(
                entry, pool, rnd,
                prompt = entry.c,
                subPrompt = entry.p,
                instruction = "Which word means this?",
                answerOf = { it.w },
                type = QType.MEANING_TO_WORD
            )
            QType.SENTENCE_GAP -> assemble(
                entry, pool, rnd,
                prompt = blank(entry.e, entry.w),
                subPrompt = "",
                instruction = "Which word fills the gap?",
                answerOf = { it.w },
                type = QType.SENTENCE_GAP
            )
        }
    }

    private fun assemble(
        entry: Entry,
        pool: List<Entry>,
        rnd: Random,
        prompt: String,
        subPrompt: String,
        instruction: String,
        answerOf: (Entry) -> String,
        type: QType
    ): Question {
        val correct = answerOf(entry)
        val taken = linkedSetOf(correct.trim().lowercase())

        val samePos = pool.filter {
            it.key != entry.key && it.p.equals(entry.p, true) && answerOf(it).isNotBlank()
        }.shuffled(rnd)
        val anyOther = pool.filter {
            it.key != entry.key && answerOf(it).isNotBlank()
        }.shuffled(rnd)

        val distractors = mutableListOf<String>()
        for (candidate in samePos + anyOther) {
            if (distractors.size == 3) break
            val text = answerOf(candidate).trim()
            if (text.isBlank()) continue
            if (!taken.add(text.lowercase())) continue
            distractors += text
        }

        val options = (distractors + correct).shuffled(rnd)
        return Question(
            entry = entry,
            type = type,
            prompt = prompt,
            subPrompt = subPrompt,
            instruction = instruction,
            options = options,
            correctIndex = options.indexOf(correct)
        )
    }

    /** Replace the target word in its own example sentence with a rule. */
    fun blank(sentence: String, word: String): String {
        val stem = word.trim()
        if (stem.isEmpty()) return sentence
        val idx = sentence.indexOf(stem, ignoreCase = true)
        if (idx < 0) return sentence
        return sentence.substring(0, idx) + GAP + sentence.substring(idx + stem.length)
    }
}
