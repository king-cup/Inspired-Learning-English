package com.vocabdrill.student.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.LaunchedEffect
import com.vocabdrill.student.data.CardsSession
import com.vocabdrill.student.data.Entry
import com.vocabdrill.student.data.SessionStore
import com.vocabdrill.student.data.ProfileStore
import com.vocabdrill.student.data.ProgressStore
import com.vocabdrill.student.data.VocabRepository
import com.vocabdrill.student.i18n.LocalStrings
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlin.math.abs
import kotlin.math.roundToInt

private val SESSION_JSON = Json { ignoreUnknownKeys = true; encodeDefaults = true }

/** Lets the buttons under the deck drive whichever card is on top. */
class CardHandle {
    var swipe: ((Boolean) -> Unit)? = null
    var flip: (() -> Unit)? = null
}

@Composable
fun FlashcardsScreen(
    unitId: String,
    onlyKeys: List<String>?,
    onBack: () -> Unit,
    onDrillMissed: (List<String>) -> Unit,
    onDone: () -> Unit
) {
    val t = LocalStrings.current
    val unit = remember(unitId) { VocabRepository.resolve(unitId) }
    val speaker = LocalSpeaker.current
    val profile by ProfileStore.state.collectAsState()
    val reversed = profile.cardsReversed

    val deck = remember(unitId, onlyKeys) {
        val all = unit?.words.orEmpty()
        val chosen = if (onlyKeys == null) all else all.filter { onlyKeys.contains(it.key) }
        chosen.shuffled()
    }

    var index by remember(deck) { mutableStateOf(0) }
    val results = remember(deck) { mutableStateMapOf<String, Boolean>() }

    // A card is committed exactly once. Without this a fast double-tap on
    // "I know it" fires the handle twice before index has recomposed, and the
    // second tap silently advances past an uncommitted card.
    var committing by remember(deck) { mutableStateOf(false) }

    var resumeOffer by remember(deck) { mutableStateOf<CardsSession?>(null) }
    var restoreChecked by remember(deck) { mutableStateOf(false) }
    var confirmLeave by remember(deck) { mutableStateOf(false) }

    fun persistDeck() {
        // A finished deck is not a resumable one -- clear it rather than leave a
        // record that would offer to "carry on" from the results screen.
        if (index >= deck.size) { SessionStore.clear(unitId, SessionStore.MODE_CARDS); return }
        if (index == 0) return
        SessionStore.save(
            unitId, SessionStore.MODE_CARDS,
            SESSION_JSON.encodeToString(
                CardsSession.serializer(),
                CardsSession(
                    orderKeys = deck.map { it.key },
                    index = index,
                    knownKeys = results.filterValues { it }.keys.toList(),
                    missedKeys = results.filterValues { !it }.keys.toList(),
                    onlyKeys = onlyKeys
                )
            )
        )
    }

    LaunchedEffect(deck) {
        if (restoreChecked || deck.isEmpty()) return@LaunchedEffect
        restoreChecked = true
        val raw = SessionStore.load(unitId, SessionStore.MODE_CARDS) ?: return@LaunchedEffect
        val saved = runCatching {
            SESSION_JSON.decodeFromString(CardsSession.serializer(), raw)
        }.getOrNull()
        // A saved run of the whole unit must not be offered on a "drill the
        // missed ones" deck, and vice versa -- they are different decks.
        if (saved != null && saved.onlyKeys == onlyKeys && saved.index in 1 until deck.size) {
            resumeOffer = saved
        } else if (saved != null && saved.onlyKeys != onlyKeys) {
            // leave it alone; it belongs to the other deck
        } else {
            SessionStore.clear(unitId, SessionStore.MODE_CARDS)
        }
    }

    LaunchedEffect(index) { persistDeck() }

    if (deck.isEmpty()) {
        Column(Modifier.fillMaxSize().background(Ink.paper).padding(14.dp)) {
            TopBar(t["common.back"], t["mode.cards"], onBack)
            Spacer(Modifier.height(30.dp))
            Text(t["cards.empty"].uppercase(), style = kicker(12, 3.0), color = Ink.ink)
        }
        return
    }

    resumeOffer?.let { saved ->
        ResumeDialog(
            modeLabel = t["session.cards"],
            onResume = {
                results.clear()
                saved.knownKeys.forEach { results[it] = true }
                saved.missedKeys.forEach { results[it] = false }
                // The deck was reshuffled on entry; restore by counting how many
                // of THIS deck's cards were already decided rather than trusting
                // the old position.
                index = deck.indexOfFirst { !results.containsKey(it.key) }
                    .let { if (it < 0) deck.size else it }
                resumeOffer = null
            },
            onStartOver = {
                SessionStore.clear(unitId, SessionStore.MODE_CARDS)
                resumeOffer = null
            }
        )
        return
    }

    if (confirmLeave) {
        LeaveDialog(
            modeLabel = t["session.cards"],
            onStay = { confirmLeave = false },
            onLeave = { confirmLeave = false; persistDeck(); onBack() }
        )
    }

    BackHandler(enabled = index in 1 until deck.size) { confirmLeave = true }

    if (index >= deck.size) {
        DeckResults(
            unitLabel = unit?.label ?: unitId,
            deck = deck,
            results = results,
            onAgain = { index = 0; results.clear(); SessionStore.clear(unitId, SessionStore.MODE_CARDS) },
            onDrillMissed = {
                val missed = deck.filter { results[it.key] == false }.map { it.key }
                if (missed.isNotEmpty()) onDrillMissed(missed)
            },
            onDone = { ProgressStore.finishCards(unitId); onDone() }
        )
        return
    }

    val entry = deck[index]
    val handle = remember(index) { CardHandle() }

    Column(Modifier.fillMaxSize().background(Ink.paper).padding(14.dp)) {

        TopBar(t["common.back"], if (onlyKeys == null) t["mode.cards"] else t["cards.retry"], onBack)

        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("${index + 1} / ${deck.size}", style = kicker(11, 2.0, FontWeight.Bold))
            RuleBar(
                index.toFloat() / deck.size,
                Modifier.padding(start = 12.dp).weight(1f),
                height = 11
            )
        }

        Spacer(Modifier.height(14.dp))

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            // The card underneath is the REAL next word, not an empty outline.
            // Seeing what is coming is most of what makes a deck feel like a
            // deck rather than a queue of unrelated prompts.
            if (index + 1 < deck.size) {
                Box(
                    Modifier
                        .offset { IntOffset(8, 13) }
                        .fillMaxSize()
                        .border(1.5.dp, Ink.ink.copy(alpha = 0.35f))
                        .background(Ink.paper)
                ) {
                    CardFront(deck[index + 1], reversed) {}
                }
            }
            key(index) {
                SwipeCard(
                    entry = entry,
                    handle = handle,
                    reversed = reversed,
                    onSpeak = { speaker?.speak(entry.w) },
                    onSwiped = { knew ->
                        results[entry.key] = knew
                        ProgressStore.markKnown(unitId, entry, knew)
                        committing = false
                        index += 1
                    }
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HardButton(
                t["cards.dontKnow"],
                Modifier.weight(1f).border(2.dp, Ink.wrongEdge),
                fill = Ink.wrongFill, edge = Ink.wrongEdge, fontSize = 11, padH = 6
            ) { if (!committing) { committing = true; handle.swipe?.invoke(false) } }
            HardButton(
                t["cards.flip"],
                Modifier.border(2.dp, Ink.ink),
                fontSize = 11, padH = 12
            ) { handle.flip?.invoke() }
            HardButton(
                t["cards.know"],
                Modifier.weight(1f).border(2.dp, Ink.rightEdge),
                fill = Ink.rightFill, edge = Ink.rightEdge, fontSize = 11, padH = 6
            ) { if (!committing) { committing = true; handle.swipe?.invoke(true) } }
        }
        Spacer(Modifier.height(7.dp))
        Text(
            t["cards.hint"].uppercase(),
            style = kicker(8, 1.5),
            color = Ink.ink,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun SwipeCard(
    entry: Entry,
    handle: CardHandle,
    reversed: Boolean,
    onSpeak: () -> Unit,
    onSwiped: (Boolean) -> Unit
) {
    val scope = rememberCoroutineScope()
    val offsetX = remember { Animatable(0f) }
    var flipped by remember { mutableStateOf(false) }
    var width by remember { mutableStateOf(1000f) }
    val rot by animateFloatAsState(if (flipped) 180f else 0f, tween(320), label = "flip")

    SideEffect {
        handle.swipe = { knew ->
            scope.launch {
                offsetX.animateTo(if (knew) width * 1.6f else -width * 1.6f, tween(200))
                onSwiped(knew)
            }
        }
        handle.flip = { flipped = !flipped }
    }

    val stampAlpha = abs(offsetX.value) / (width * 0.30f).coerceAtLeast(1f)
    val tint = when {
        offsetX.value > 20f -> Ink.rightFill
        offsetX.value < -20f -> Ink.wrongFill
        else -> Ink.paper
    }
    val edge = when {
        offsetX.value > 20f -> Ink.rightEdge
        offsetX.value < -20f -> Ink.wrongEdge
        else -> Ink.ink
    }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { if (it.width > 0) width = it.width.toFloat() }
            .offset { IntOffset(offsetX.value.roundToInt(), 0) }
            .graphicsLayer {
                rotationZ = offsetX.value / 45f
                rotationY = rot
                cameraDistance = 14f * density
            }
            .border(2.5.dp, edge)
            .background(tint)
            .pointerInput(entry.key) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            val threshold = size.width * 0.28f
                            when {
                                offsetX.value > threshold -> {
                                    offsetX.animateTo(size.width * 1.6f, tween(200)); onSwiped(true)
                                }
                                offsetX.value < -threshold -> {
                                    offsetX.animateTo(-size.width * 1.6f, tween(200)); onSwiped(false)
                                }
                                else -> offsetX.animateTo(0f, spring())
                            }
                        }
                    },
                    onDragCancel = { scope.launch { offsetX.animateTo(0f, spring()) } },
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        scope.launch { offsetX.snapTo(offsetX.value + dx) }
                    }
                )
            }
            .pointerInput(entry.key) {
                detectTapGestures(onTap = { flipped = !flipped })
            }
    ) {
        if (rot <= 90f) {
            CardFront(entry, reversed, onSpeak)
        } else {
            Box(Modifier.fillMaxSize().graphicsLayer { rotationY = 180f }) {
                CardBack(entry, reversed, onSpeak)
            }
        }

        if (offsetX.value > 20f) Stamp("Know", Ink.rightEdge, stampAlpha, Alignment.TopStart)
        else if (offsetX.value < -20f) Stamp("Again", Ink.wrongEdge, stampAlpha, Alignment.TopEnd)
    }
}

@Composable
private fun BoxScope.Stamp(text: String, color: Color, alpha: Float, align: Alignment) {
    Text(
        text.uppercase(),
        style = kicker(20, 4.0, FontWeight.Black),
        color = color,
        modifier = Modifier
            .align(align)
            .padding(18.dp)
            .graphicsLayer {
                this.alpha = alpha.coerceIn(0f, 1f)
                rotationZ = if (align == Alignment.TopStart) -12f else 12f
            }
            .border(3.dp, color)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
private fun CardFront(entry: Entry, reversed: Boolean, onSpeak: () -> Unit) {
    val t = LocalStrings.current
    Column(
        Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(t["cards.tapToFlip"].uppercase(), style = kicker(8, 3.0), color = Ink.ink)
        Spacer(Modifier.height(16.dp))
        if (reversed) {
            // Chinese first: the student recalls the English word. Harder, and
            // the direction most learners avoid, which is why it is worth doing.
            Text(
                entry.c,
                fontFamily = Serif, fontSize = 34.sp, lineHeight = 44.sp,
                fontWeight = FontWeight.Bold, color = Ink.ink, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
            PosTag(entry.p)
        } else {
            Text(
                entry.w,
                fontFamily = Serif, fontSize = 40.sp, lineHeight = 46.sp,
                fontWeight = FontWeight.Bold, color = Ink.ink, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
            PosTag(entry.p)
            Spacer(Modifier.height(20.dp))
            HardButton(t["cards.sayIt"], Modifier.border(1.5.dp, Ink.ink), fontSize = 10) { onSpeak() }
        }
    }
}

@Composable
private fun CardBack(entry: Entry, reversed: Boolean, onSpeak: () -> Unit) {
    val t = LocalStrings.current
    if (reversed) {
        // Reverse direction: the answer is simply the English word.
        Column(
            Modifier.fillMaxSize().padding(22.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                entry.w,
                fontFamily = Serif, fontSize = 40.sp, lineHeight = 46.sp,
                fontWeight = FontWeight.Bold, color = Ink.ink, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(14.dp))
            HardButton(t["cards.sayIt"], Modifier.border(1.5.dp, Ink.ink), fontSize = 10) { onSpeak() }
        }
        return
    }

    // Forward direction: the Chinese is the answer, so it gets the centre of
    // the card at full size -- a direct counterpart to the English on the
    // front, not a caption. The sentence sits at the foot.
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                entry.w,
                fontFamily = Serif, fontSize = 19.sp, fontWeight = FontWeight.Bold,
                color = Ink.ink.copy(alpha = 0.7f), modifier = Modifier.weight(1f)
            )
            PosTag(entry.p, Modifier.padding(end = 8.dp))
            HardButton("▶", Modifier.border(1.5.dp, Ink.ink), fontSize = 11, padH = 9, padV = 5) { onSpeak() }
        }
        Spacer(Modifier.height(10.dp))
        HRule(2.0)

        Column(
            Modifier.fillMaxWidth().weight(1f).padding(vertical = 20.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                entry.c,
                fontFamily = Serif, fontSize = 34.sp, lineHeight = 46.sp,
                fontWeight = FontWeight.Bold, color = Ink.ink, textAlign = TextAlign.Center
            )
            if (entry.s.isNotBlank() || entry.a.isNotBlank()) {
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    if (entry.s.isNotBlank()) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(t["study.same"].uppercase(), style = kicker(8, 2.0), color = Ink.ink)
                        Text(entry.s, fontFamily = Serif, fontSize = 14.sp, color = Ink.ink)
                    }
                    if (entry.a.isNotBlank()) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(t["study.opposite"].uppercase(), style = kicker(8, 2.0), color = Ink.ink)
                        Text(entry.a, fontFamily = Serif, fontSize = 14.sp, color = Ink.ink)
                    }
                }
            }
        }

        if (entry.e.isNotBlank()) {
            HRule(1.0)
            Spacer(Modifier.height(10.dp))
            Text(t["study.example"].uppercase(), style = kicker(8, 2.5), color = Ink.ink)
            Spacer(Modifier.height(4.dp))
            Text(entry.e, fontFamily = Serif, fontSize = 13.sp, lineHeight = 20.sp, color = Ink.ink)
        }
    }
}

@Composable
private fun DeckResults(
    unitLabel: String,
    deck: List<Entry>,
    results: Map<String, Boolean>,
    onAgain: () -> Unit,
    onDrillMissed: () -> Unit,
    onDone: () -> Unit
) {
    val t = LocalStrings.current
    val knew = deck.count { results[it.key] == true }
    val missed = deck.filter { results[it.key] == false }
    Column(
        Modifier.fillMaxSize().background(Ink.paper).verticalScroll(rememberScrollState()).padding(14.dp)
    ) {
        PaperHeader(
            kickerText = t["cards.finished"],
            title = unitLabel,
            leftFoot = t.f("cards.knownOf", knew, deck.size),
            rightFoot = "${(knew * 100) / deck.size.coerceAtLeast(1)}%"
        )
        Spacer(Modifier.height(14.dp))
        if (missed.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().border(2.dp, Ink.wrongEdge)) {
                BarLabel(t["cards.stillToLearn"], right = "${missed.size}")
                Column(Modifier.background(Ink.wrongFill).fillMaxWidth().padding(12.dp)) {
                    missed.forEach {
                        Text(
                            "${it.w}   —   ${it.c}",
                            fontFamily = Serif, fontSize = 14.sp, color = Ink.ink,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            BlockButton(t.f("cards.drillMissed", missed.size), t["cards.drillMissedCaption"]) { onDrillMissed() }
            Spacer(Modifier.height(10.dp))
        } else {
            Column(
                Modifier.fillMaxWidth().border(2.dp, Ink.rightEdge).background(Ink.rightFill).padding(14.dp)
            ) {
                Text(t["cards.allKnown"].uppercase(), style = kicker(13, 2.5, FontWeight.Bold), color = Ink.rightEdge)
            }
            Spacer(Modifier.height(12.dp))
        }
        BlockButton(t["cards.again"], t["cards.againCaption"]) { onAgain() }
        Spacer(Modifier.height(10.dp))
        HardButton(t["common.done"], Modifier.fillMaxWidth().border(2.dp, Ink.ink), fontSize = 12) { onDone() }
        Spacer(Modifier.height(24.dp))
    }
}
