package com.vocabdrill.student.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Single JSON file in the app's private storage. Writes go to a .tmp first and
 * are then renamed, so a kill mid-write can never leave a half file behind.
 */
object ProgressStore {

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var file: File
    private lateinit var tmp: File
    private var started = false

    private val _state = MutableStateFlow(Progress())
    val state: StateFlow<Progress> = _state

    fun init(context: Context) {
        if (started) return
        started = true
        file = File(context.filesDir, "progress.json")
        tmp = File(context.filesDir, "progress.json.tmp")
        runCatching {
            if (file.exists()) {
                _state.value = json.decodeFromString(Progress.serializer(), file.readText())
            }
        }
    }

    private fun persist(p: Progress) {
        if (!started) return
        scope.launch {
            runCatching {
                tmp.writeText(json.encodeToString(Progress.serializer(), p))
                if (file.exists()) file.delete()
                tmp.renameTo(file)
            }
        }
    }

    private fun update(block: (Progress) -> Progress) {
        val next = block(_state.value)
        _state.value = next
        persist(next)
    }

    // ---- mutations -------------------------------------------------------

    fun markKnown(unitId: String, e: Entry, known: Boolean) = update { p ->
        val k = p.wordKey(unitId, e)
        val old = p.words[k] ?: WordStat()
        val next = old.copy(
            known = known,
            seen = old.seen + 1,
            right = old.right + if (known) 1 else 0,
            wrong = old.wrong + if (known) 0 else 1,
            lastMs = System.currentTimeMillis()
        )
        p.copy(words = p.words + (k to next))
    }

    fun recordAnswer(unitId: String, e: Entry, correct: Boolean) =
        markKnown(unitId, e, correct)

    /**
     * A test answer. Unlike practice this never PROMOTES a word to known -- a
     * lucky guess in an exam is not evidence of learning -- but a wrong answer
     * does send it back to the to-learn pile.
     */
    fun recordTestAnswer(unitId: String, e: Entry, correct: Boolean) = update { p ->
        val k = p.wordKey(unitId, e)
        val old = p.words[k] ?: WordStat()
        p.copy(words = p.words + (k to old.copy(
            known = if (correct) old.known else false,
            seen = old.seen + 1,
            right = old.right + if (correct) 1 else 0,
            wrong = old.wrong + if (correct) 0 else 1,
            lastMs = System.currentTimeMillis()
        )))
    }

    fun finishCards(unitId: String) = update { p ->
        val u = p.unit(unitId)
        p.copy(units = p.units + (unitId to u.copy(
            cardRuns = u.cardRuns + 1,
            lastMs = System.currentTimeMillis()
        )))
    }

    fun finishLearn(unitId: String, pct: Int) = update { p ->
        val u = p.unit(unitId)
        p.copy(units = p.units + (unitId to u.copy(
            learnRuns = u.learnRuns + 1,
            lastPct = pct,
            bestPct = maxOf(u.bestPct, pct),
            lastMs = System.currentTimeMillis()
        )))
    }

    fun touch(unitId: String) = update { p ->
        val u = p.unit(unitId)
        p.copy(units = p.units + (unitId to u.copy(lastMs = System.currentTimeMillis())))
    }

    /** Records a finished test. Wrong answers have already been folded in by
     *  recordAnswer; this only writes the history row and the headline score. */
    fun finishTest(unitId: String, correct: Int, total: Int, retest: Boolean) = update { p ->
        val u = p.unit(unitId)
        val run = TestRun(
            at = System.currentTimeMillis(),
            attempt = u.tests.count { !it.retest } + if (retest) 0 else 1,
            correct = correct, total = total, retest = retest
        )
        val pct = run.pct
        p.copy(units = p.units + (unitId to u.copy(
            tests = u.tests + run,
            lastPct = pct,
            bestPct = maxOf(u.bestPct, pct),
            lastMs = run.at
        )))
    }

    fun resetUnit(unitId: String) = update { p ->
        // An unfinished run for this unit would immediately re-create the records
        // the student just asked to clear.
        SessionStore.clearUnit(unitId)
        val prefix = "$unitId|"
        p.copy(
            words = p.words.filterKeys { !it.startsWith(prefix) },
            units = p.units - unitId
        )
    }

    fun resetAll() = update {
        SessionStore.clearAll()
        Progress()
    }

    /** Replaces everything from a backup file. Unfinished runs belong to the old
     *  records and would write into the restored ones, so they go too. */
    fun replaceAll(p: Progress) = update {
        SessionStore.clearAll()
        p
    }
}
