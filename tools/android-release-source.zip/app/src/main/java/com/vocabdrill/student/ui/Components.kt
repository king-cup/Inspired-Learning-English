package com.vocabdrill.student.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import com.vocabdrill.student.i18n.LocalLang
import com.vocabdrill.student.i18n.LocalStrings
import com.vocabdrill.student.i18n.displayPos

/** The double-ruled header box: 3px outer, 1px inner. */
@Composable
fun PaperHeader(
    kickerText: String,
    title: String,
    leftFoot: String,
    rightFoot: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier
            .fillMaxWidth()
            .border(3.dp, Ink.ink)
    ) {
        Box(
            Modifier
                .matchParentSize()
                .padding(3.dp)
                .border(1.dp, Ink.ink)
        )
        Column(Modifier.padding(horizontal = 18.dp, vertical = 13.dp)) {
            Text(kickerText.uppercase(), style = kickerFor(kickerText, 11, 3.0))
            Text(
                title.uppercase(),
                fontFamily = Serif,
                fontSize = 27.sp,
                lineHeight = 29.sp,
                letterSpacing = 1.sp,
                fontWeight = FontWeight.Black,
                color = Ink.ink
            )
            Box(
                Modifier
                    .padding(top = 9.dp)
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(Ink.ink)
            )
            Row(
                Modifier
                    .padding(top = 6.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(leftFoot.uppercase(), style = kickerFor(leftFoot, 11, 2.0))
                Text(rightFoot.uppercase(), style = kickerFor(rightFoot, 11, 2.0))
            }
        }
    }
}

/** Black bar with white letterspaced caps -- the .rowlbl of the desktop board. */
@Composable
fun BarLabel(text: String, modifier: Modifier = Modifier, right: String? = null) {
    Row(
        modifier
            .fillMaxWidth()
            .background(Ink.ink)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text.uppercase(), style = kickerFor(text, 11, 2.0), color = Ink.paper)
        if (right != null) Text(right.uppercase(), style = kickerFor(right, 11, 2.0), color = Ink.paper)
    }
}

/** A hard-edged button that inverts while pressed. No ripple, no rounding. */
@Composable
fun HardButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    selected: Boolean = false,
    fontSize: Int = 11,
    spacing: Double = 1.5,
    padH: Int = 15,
    padV: Int = 10,
    fill: Color? = null,
    edge: Color = Ink.ink,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val on = selected || pressed
    val bg = when {
        on -> Ink.ink
        fill != null -> fill
        else -> Ink.paper
    }
    val fg = if (on) Ink.paper else if (fill != null) edge else Ink.ink
    Box(
        modifier
            .clip(RectangleShape)
            .background(if (enabled) bg else Ink.paper)
            .clickable(
                enabled = enabled,
                interactionSource = interaction,
                indication = null
            ) { onClick() }
            .padding(horizontal = padH.dp, vertical = padV.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text.uppercase(),
            style = kicker(fontSize, spacing, FontWeight.Bold),
            color = if (enabled) fg else Ink.ink.copy(alpha = 0.3f),
            textAlign = TextAlign.Center
        )
    }
}

/** Big block action button used on the unit page. */
@Composable
fun BlockButton(
    label: String,
    caption: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val bg = if (pressed) Ink.ink else Ink.paper
    val fg = if (pressed) Ink.paper else Ink.ink
    Column(
        modifier
            .fillMaxWidth()
            .border(2.dp, Ink.ink)
            .background(bg)
            .clickable(enabled = enabled, interactionSource = interaction, indication = null) { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Text(label.uppercase(), style = kicker(16, 2.5, FontWeight.Bold), color = fg)
        Text(
            caption,
            fontFamily = Serif,
            fontSize = 13.sp,
            color = fg.copy(alpha = 0.85f),
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

/** The 13px ruled progress track from the board. */
@Composable
fun RuleBar(fraction: Float, modifier: Modifier = Modifier, height: Int = 13) {
    val f = fraction.coerceIn(0f, 1f)
    Box(
        modifier
            .height(height.dp)
            .border(1.5.dp, Ink.ink)
            .semantics { progressBarRangeInfo = ProgressBarRangeInfo(f, 0f..1f) }
    ) {
        Box(
            Modifier
                .fillMaxWidth(f)
                .fillMaxHeight()
                .background(Ink.ink)
        )
    }
}

/** Small caps tag, e.g. the part-of-speech chip. */
@Composable
fun Tag(text: String, modifier: Modifier = Modifier, inverted: Boolean = false) {
    Text(
        text.uppercase(),
        style = kickerFor(text, 11, 1.5, FontWeight.Bold),
        color = if (inverted) Ink.paper else Ink.ink,
        modifier = modifier
            .background(if (inverted) Ink.ink else Ink.paper)
            .border(1.dp, Ink.ink)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    )
}

/**
 * The part-of-speech chip.
 *
 * Expands "phr.v" to "Phrasal verb" / "短语动词" for the student. The raw value
 * stays in Entry.p and therefore in every progress key -- this is a display
 * layer and nothing else. An entry with no part of speech renders no chip at
 * all rather than an empty box.
 */
@Composable
fun PosTag(rawPos: String, modifier: Modifier = Modifier, inverted: Boolean = false) {
    val label = displayPos(rawPos, LocalLang.current)
    if (label.isBlank()) return
    Tag(label, modifier, inverted)
}

@Composable
fun HRule(thickness: Double = 1.5, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(thickness.dp)
            .background(Ink.ink)
    )
}

@Composable
fun SpeakerGlyph(size: Int = 22, color: Color = Ink.ink) {
    val label = LocalStrings.current["a11y.speak"]
    Text(
        "▶",
        fontFamily = Mono,
        fontSize = (size * 0.55).sp,
        color = color,
        modifier = Modifier
            .semantics { contentDescription = label }
            .border(1.2.dp, color)
            .padding(horizontal = 5.dp, vertical = 1.dp),
        textAlign = TextAlign.Center
    )
}

// ---------------------------------------------------------------------------
// v1.01 additions
// ---------------------------------------------------------------------------

/** Black bar label + a hard-edged dropdown. Replaces the horizontal tab strips,
 *  which do not scale past three or four books on a phone. */
@Composable
fun PaperDropdown(
    label: String,
    value: String,
    options: List<String>,
    modifier: Modifier = Modifier,
    onPick: (Int) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Column(modifier.fillMaxWidth()) {
        BarLabel(label)
        Box {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Ink.paper)
                    .clickable { open = true }
                    .padding(horizontal = 13.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    value,
                    style = kicker(12, 1.0, FontWeight.Bold),
                    color = Ink.ink,
                    modifier = Modifier.weight(1f)
                )
                Text("▾", fontFamily = Mono, fontSize = 14.sp, color = Ink.ink)
            }
            DropdownMenu(
                expanded = open,
                onDismissRequest = { open = false },
                modifier = Modifier
                    .background(Ink.paper)
                    .border(2.dp, Ink.ink)
            ) {
                options.forEachIndexed { i, opt ->
                    val on = opt == value
                    DropdownMenuItem(
                        text = {
                            Text(
                                opt,
                                style = kicker(11, 1.0, FontWeight.Bold),
                                color = if (on) Ink.paper else Ink.ink
                            )
                        },
                        onClick = { open = false; onPick(i) },
                        modifier = Modifier.background(if (on) Ink.ink else Ink.paper)
                    )
                }
            }
        }
    }
}

/** A settings row: title, one line of explanation, and an ON/OFF toggle that
 *  is a hard button rather than a Material switch. */
@Composable
fun ToggleRow(
    title: String,
    help: String,
    checked: Boolean,
    onLabel: String,
    offLabel: String,
    onChange: (Boolean) -> Unit
) {
    val stateLabel = if (checked) onLabel else offLabel
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .clickable { onChange(!checked) }
            .semantics {
                role = Role.Switch
                stateDescription = stateLabel
            }
            .padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = kickerFor(title, 12, 1.5, FontWeight.Bold), color = Ink.ink)
            Text(
                help,
                fontFamily = Serif,
                fontSize = 13.sp,
                color = Ink.ink.copy(alpha = 0.75f),
                modifier = Modifier.padding(top = 3.dp)
            )
        }
        Box(
            Modifier
                .border(2.dp, Ink.ink)
                .background(if (checked) Ink.ink else Ink.paper)
                .padding(horizontal = 13.dp, vertical = 8.dp)
        ) {
            Text(
                (if (checked) onLabel else offLabel).uppercase(),
                style = kicker(11, 1.5, FontWeight.Bold),
                color = if (checked) Ink.paper else Ink.ink
            )
        }
    }
}

/** The big pass/fail number on the test result screen. */
@Composable
fun GradeBlock(pct: Int, correct: Int, total: Int, passed: Boolean, caption: String) {
    val edge = if (passed) Ink.rightEdge else Ink.wrongEdge
    val fill = if (passed) Ink.rightFill else Ink.wrongFill
    Column(
        Modifier
            .fillMaxWidth()
            .border(3.dp, edge)
            .background(fill)
            .padding(vertical = 26.dp, horizontal = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("$pct%", fontFamily = Mono, fontSize = 76.sp, fontWeight = FontWeight.Black, color = edge)
        Text(
            "$correct / $total",
            style = kicker(13, 3.0, FontWeight.Bold),
            color = edge,
            modifier = Modifier.padding(top = 2.dp)
        )
        Text(
            caption,
            fontFamily = Serif,
            fontSize = 17.sp,
            color = Ink.ink,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 14.dp)
        )
    }
}


/**
 * The update strip: new vocabulary is waiting, but nothing is interrupted.
 *
 * Deliberately NOT a dialog. A student mid-test must never be pulled out of it
 * by an announcement, and ignoring this bar is always safe -- the new words
 * install by themselves the next time they leave the drill. The × is there so a
 * student who does not care can make it go away.
 */
@Composable
fun UpdateBar(
    message: String,
    actionLabel: String,
    dismissLabel: String,
    onAction: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier
            .fillMaxWidth()
            .background(Ink.ink)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            message,
            style = kickerFor(message, 11, 1.0, FontWeight.Bold),
            color = Ink.paper,
            modifier = Modifier.weight(1f).padding(end = 10.dp)
        )
        Text(
            actionLabel.uppercase(),
            style = kickerFor(actionLabel, 11, 1.5, FontWeight.Bold),
            color = Ink.ink,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .heightIn(min = 44.dp)
                .widthIn(min = 88.dp)
                .background(Ink.paper)
                .clickable { onAction() }
                .padding(horizontal = 12.dp, vertical = 13.dp)
        )
        Text(
            "\u00d7",
            fontFamily = Mono,
            fontSize = 20.sp,
            color = Ink.paper,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .semantics { contentDescription = dismissLabel }
                .heightIn(min = 44.dp)
                .widthIn(min = 44.dp)
                .clickable { onDismiss() }
                .padding(horizontal = 10.dp, vertical = 10.dp)
        )
    }
}


/**
 * Offered when an unfinished run is found for this unit.
 *
 * There is no "later" option on purpose: the student is standing in front of
 * the mode right now, so the only two honest answers are carry on or bin it.
 * Dismissing by tapping outside means carry on, because that is the safer
 * default -- it cannot destroy work.
 */
@Composable
fun ResumeDialog(modeLabel: String, onResume: () -> Unit, onStartOver: () -> Unit) {
    val t = LocalStrings.current
    AlertDialog(
        onDismissRequest = onResume,
        containerColor = Ink.paper,
        title = {
            Text(
                t["session.resumeTitle"],
                style = kickerFor(t["session.resumeTitle"], 12, 2.0, FontWeight.Bold),
                color = Ink.ink
            )
        },
        text = {
            Text(
                t.f("session.resumeBody", modeLabel),
                fontFamily = Serif, fontSize = 14.sp, color = Ink.ink
            )
        },
        confirmButton = { HardButton(t["session.resume"], fontSize = 11, onClick = onResume) },
        dismissButton = { HardButton(t["session.startOver"], fontSize = 11, onClick = onStartOver) }
    )
}

/** Asked before backing out of a run that has answers in it. Leaving is safe --
 *  the run is saved either way -- so the wording promises that rather than warning. */
@Composable
fun LeaveDialog(modeLabel: String, onStay: () -> Unit, onLeave: () -> Unit) {
    val t = LocalStrings.current
    AlertDialog(
        onDismissRequest = onStay,
        containerColor = Ink.paper,
        title = {
            Text(
                t.f("session.leaveTitle", modeLabel),
                style = kickerFor(modeLabel, 12, 2.0, FontWeight.Bold),
                color = Ink.ink
            )
        },
        text = {
            Text(t["session.leaveBody"], fontFamily = Serif, fontSize = 14.sp, color = Ink.ink)
        },
        confirmButton = { HardButton(t["session.keepGoing"], fontSize = 11, onClick = onStay) },
        dismissButton = { HardButton(t["session.leave"], fontSize = 11, onClick = onLeave) }
    )
}
