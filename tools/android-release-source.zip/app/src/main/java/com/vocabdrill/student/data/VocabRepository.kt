package com.vocabdrill.student.data

import android.content.Context
import kotlinx.serialization.json.Json

object VocabRepository {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    @Volatile private var bundle: Bundle? = null

    /** Blocking parse of assets/vocab.json. Call from a background dispatcher. */
    fun load(context: Context): Bundle {
        bundle?.let { return it }
        synchronized(this) {
            bundle?.let { return it }
            val text = context.assets.open("vocab.json").bufferedReader().use { it.readText() }
            val b = json.decodeFromString(Bundle.serializer(), text)
            bundle = b
            return b
        }
    }

    fun requireBundle(): Bundle = bundle ?: Bundle()

    /**
     * Install a bundle produced by ContentRepository. That object owns WHERE the
     * words come from -- a remote release, a cached release, or the APK's own
     * assets; this one only owns the in-memory view of them.
     */
    fun adopt(b: Bundle) {
        synchronized(this) { bundle = b }
    }

    /**
     * Display order, imposed here rather than in the drill board's BUNDLE so the
     * teacher's live in-class tool is not disturbed. Books run easiest first;
     * anything not listed sorts to the end in its original order.
     */
    private val TYPE_ORDER = listOf("Book Units", "HSE Packages")
    private val GROUP_ORDER = listOf(
        "Prepare Level 1", "Prepare Level 2", "Prepare Level 3", "Prepare Level 4",
        "Prepare Level 5",
        "Unlock 3", "Unlock 4", "Openworld FCE",
        "Reading Explorer Foundations", "Reading Explorer 1",
        "Reading Explorer 2", "Reading Explorer 3"
    )

    private fun rank(order: List<String>, name: String): Int =
        order.indexOf(name).let { if (it < 0) order.size else it }

    /** Types that actually contain at least one unit with words, in teaching order. */
    fun types(): List<TypeBlock> {
        val b = requireBundle()
        return b.types.mapNotNull { t ->
            val groups = t.groups.mapNotNull { g ->
                val units = g.units.filter { (b.data[it.id]?.size ?: 0) > 0 }
                if (units.isEmpty()) null else g.copy(units = units)
            }.sortedBy { rank(GROUP_ORDER, it.name) }
            if (groups.isEmpty()) null else t.copy(groups = groups)
        }.sortedBy { rank(TYPE_ORDER, it.type) }
    }

    fun wordsFor(unitId: String): List<Entry> = requireBundle().data[unitId].orEmpty()

    fun resolve(unitId: String): ResolvedUnit? {
        for (t in types()) for (g in t.groups) for (u in g.units) {
            if (u.id == unitId) {
                return ResolvedUnit(u.id, u.label, g.name, t.type, wordsFor(unitId))
            }
        }
        val words = wordsFor(unitId)
        return if (words.isEmpty()) null
        else ResolvedUnit(unitId, unitId, "", "", words)
    }

    fun totalWords(): Int = requireBundle().data.values.sumOf { it.size }
    fun totalUnits(): Int = types().sumOf { t -> t.groups.sumOf { it.units.size } }
}
