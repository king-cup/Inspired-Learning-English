package com.vocabdrill.student.data

import kotlinx.serialization.Serializable

/**
 * One vocabulary entry, exactly as the Vocab Drill Board stores it.
 *   w = word   p = part of speech   c = Chinese gloss
 *   e = example sentence   s = synonym   a = antonym
 */
@Serializable
data class Entry(
    val w: String,
    val p: String = "",
    val c: String = "",
    val e: String = "",
    val s: String = "",
    val a: String = ""
) {
    val key: String get() = w.trim().lowercase() + "|" + p.trim().lowercase()
}

@Serializable
data class UnitRef(val id: String, val label: String)

@Serializable
data class Group(val name: String, val units: List<UnitRef> = emptyList())

@Serializable
data class TypeBlock(
    val type: String,
    val groupLabel: String = "",
    val groups: List<Group> = emptyList()
)

@Serializable
data class Bundle(
    val types: List<TypeBlock> = emptyList(),
    val data: Map<String, List<Entry>> = emptyMap()
)

/** A unit resolved against the bundle: knows its book, its label and its words. */
data class ResolvedUnit(
    val id: String,
    val label: String,
    val groupName: String,
    val typeName: String,
    val words: List<Entry>
)
