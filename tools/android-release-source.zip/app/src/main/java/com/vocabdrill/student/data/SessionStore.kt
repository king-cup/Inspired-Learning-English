package com.vocabdrill.student.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Unfinished Cards / Practice / Test runs, so a phone call, a mis-swiped back
 * gesture or the OS killing the app overnight does not throw away work.
 *
 * The web client keeps these in sessionStorage, which dies with the tab. This
 * one is a file, deliberately: a student on a cheap handset with aggressive
 * memory management loses the process constantly, and "your test vanished" is
 * the failure that makes someone stop using the app. Recovery is worth more
 * here than symmetry with the web.
 *
 * Each screen owns the SHAPE of its own state and stores it as an encoded JSON
 * string; this object only owns the filing. Runs are keyed by wordKey inside
 * those payloads, never by list position, so a restored run survives a
 * vocabulary update that reorders the unit.
 */
object SessionStore {

    const val MODE_CARDS = "cards"
    const val MODE_PRACTICE = "practice"
    const val MODE_TEST = "test"

    /** Anything older than this is stale enough that resuming would confuse. */
    private const val MAX_AGE_MS = 14L * 24 * 60 * 60 * 1000

    @Serializable
    private data class Record(val savedAt: Long, val data: String)

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val serializer = MapSerializer(String.serializer(), Record.serializer())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var file: File
    private lateinit var tmp: File
    private var started = false

    private var records: MutableMap<String, Record> = mutableMapOf()

    private fun key(unitId: String, mode: String) = "$mode|$unitId"

    fun init(context: Context) {
        if (started) return
        started = true
        file = File(context.filesDir, "sessions.json")
        tmp = File(context.filesDir, "sessions.json.tmp")
        runCatching {
            if (file.exists()) {
                records = json.decodeFromString(serializer, file.readText()).toMutableMap()
            }
        }
        // Drop anything too old on the way in rather than offering a stale resume.
        val cutoff = System.currentTimeMillis() - MAX_AGE_MS
        val before = records.size
        records.entries.removeAll { it.value.savedAt < cutoff }
        if (records.size != before) persist()
    }

    private fun persist() {
        if (!started) return
        val snapshot = records.toMap()
        scope.launch {
            runCatching {
                tmp.writeText(json.encodeToString(serializer, snapshot))
                if (file.exists()) file.delete()
                tmp.renameTo(file)
            }
        }
    }

    fun save(unitId: String, mode: String, data: String) {
        if (!started) return
        records[key(unitId, mode)] = Record(System.currentTimeMillis(), data)
        persist()
    }

    fun load(unitId: String, mode: String): String? =
        records[key(unitId, mode)]?.data

    fun has(unitId: String, mode: String): Boolean = records.containsKey(key(unitId, mode))

    fun clear(unitId: String, mode: String) {
        if (records.remove(key(unitId, mode)) != null) persist()
    }

    /** Called by resetUnit: wiping a unit's records must not leave a run behind
     *  that would immediately re-populate them. */
    fun clearUnit(unitId: String) {
        val before = records.size
        records.entries.removeAll { it.key.endsWith("|$unitId") }
        if (records.size != before) persist()
    }

    fun clearAll() {
        if (records.isEmpty()) return
        records.clear()
        persist()
    }
}
