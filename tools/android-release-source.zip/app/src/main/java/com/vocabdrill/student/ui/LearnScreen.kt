package com.vocabdrill.student.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.BackHandler
import com.vocabdrill.student.data.Entry
import com.vocabdrill.student.data.PracticeSession
import com.vocabdrill.student.data.SessionStore
import com.vocabdrill.student.data.ProgressStore
import com.vocabdrill.student.data.Question
import com.vocabdrill.student.data.QuestionFactory
import com.vocabdrill.student.data.QType
import com.vocabdrill.student.data.VocabRepository
import com.vocabdrill.student.i18n.LocalStrings
import kotlinx.serialization.json.Json
import kotlin.random.Random

private val SESSION_JSON = Json { ignoreUnknownKeys = true; encodeDefaults = true }

private const val ROUND = 5

@Composable
fun LearnScreen(unitId: String, onBack: () -> Unit, onDone: () -> Unit) {
    val t = LocalStrings.current
    val unit = remember(unitId) { VocabRepository.resolve(unitId) }
    val speaker = LocalSpeaker.current
    val pool = unit?.words.orEmpty()
    val rnd = remember { Random(System.nanoTime()) }

    val mainRun = remember(pool) { pool.shuffled(rnd) }

    // --- session state ---
    var currentRun by remember(pool) { mutableStateOf(mainRun) }
    var pos by remember(pool) { mutableStateOf(0) }
    var isRetry by remember(pool) { mutableStateOf(false) }
    var retryPass by remember(pool) { mutableStateOf(0) }
    var firstPassRight by remember(pool) { mutableStateOf(0) }
    var answeredTotal by remember(pool) { mutableStateOf(0) }
    // Counted separately from answeredTotal: retries are extra work, not extra
    // progress, and folding them into one number produced "21 / 20".
    var firstPassAnswered by remember(pool) { mutableStateOf(0) }
    val wrongKeys = remember(pool) { mutableStateListOf<String>() }
    val roundMarks = remember(pool) { mutableStateListOf<Boolean>() }
    var showBreak by remember(pool) { mutableStateOf(false) }
    var finished by remember(pool) { mutableStateOf(false) }
    var saved by remember(pool) { mutableStateOf(false) }

    var chosen by remember(pool) { mutableStateOf(-1) }

    // --- session recovery ---
    var resumeOffer by remember(pool) { mutableStateOf<PracticeSession?>(null) }
    var restoreChecked by remember(pool) { mutableStateOf(false) }
    var confirmLeave by remember(pool) { mutableStateOf(false) }
    val started = answeredTotal > 0

    LaunchedEffect(pool) {
        if (restoreChecked || pool.isEmpty()) return@LaunchedEffect
        restoreChecked = true
        val raw = SessionStore.load(unitId, SessionStore.MODE_PRACTICE) ?: return@LaunchedEffect
        val saved0 = runCatching {
            SESSION_JSON.decodeFromString(PracticeSession.serializer(), raw)
        }.getOrNull()
        // A run whose words have all vanished from the unit is not resumable.
        if (saved0 != null && saved0.runKeys.any { k -> pool.any { it.key == k } }) {
            resumeOffer = saved0
        } else {
            SessionStore.clear(unitId, SessionStore.MODE_PRACTICE)
        }
    }

    fun persistSession() {
        if (finished || resumeOffer != null) return
        if (answeredTotal == 0 && pos == 0 && !showBreak) return
        SessionStore.save(
            unitId, SessionStore.MODE_PRACTICE,
            SESSION_JSON.encodeToString(
                PracticeSession.serializer(),
                PracticeSession(
                    mainKeys = mainRun.map { it.key },
                    runKeys = currentRun.map { it.key },
                    pos = pos,
                    isRetry = isRetry,
                    retryPass = retryPass,
                    firstPassRight = firstPassRight,
                    answeredTotal = answeredTotal,
                    firstPassAnswered = firstPassAnswered,
                    wrongKeys = wrongKeys.toList(),
                    roundMarks = roundMarks.toList(),
                    showBreak = showBreak
                )
            )
        )
    }

    LaunchedEffect(pos, isRetry, retryPass, answeredTotal, showBreak, finished, resumeOffer) {
        persistSession()
    }

    if (pool.size < 2) {
        Column(Modifier.fillMaxSize().background(Ink.paper).padding(14.dp)) {
            TopBar(t["common.back"], t["mode.practice"], onBack)
            Spacer(Modifier.height(30.dp))
            Text(t["practice.tooShort"].uppercase(), style = kicker(11, 2.5), color = Ink.ink)
        }
        return
    }

    // ---------------- resume offer ----------------
    resumeOffer?.let { saved0 ->
        ResumeDialog(
            modeLabel = t["session.practice"],
            onResume = {
                val byKey = pool.associateBy { it.key }
                val run = saved0.runKeys.mapNotNull { byKey[it] }
                if (run.isNotEmpty()) {
                    currentRun = run
                    pos = saved0.pos.coerceIn(0, run.lastIndex)
                    isRetry = saved0.isRetry
                    retryPass = saved0.retryPass
                    firstPassRight = saved0.firstPassRight
                    answeredTotal = saved0.answeredTotal
                    firstPassAnswered = saved0.firstPassAnswered
                    wrongKeys.clear(); wrongKeys.addAll(saved0.wrongKeys.filter { byKey.containsKey(it) })
                    roundMarks.clear(); roundMarks.addAll(saved0.roundMarks)
                    showBreak = saved0.showBreak
                }
                resumeOffer = null
            },
            onStartOver = {
                SessionStore.clear(unitId, SessionStore.MODE_PRACTICE)
                resumeOffer = null
            }
        )
        return
    }

    if (confirmLeave) {
        LeaveDialog(
            modeLabel = t["session.practice"],
            onStay = { confirmLeave = false },
            onLeave = { confirmLeave = false; persistSession(); onBack() }
        )
    }

    BackHandler(enabled = started) { confirmLeave = true }

    // ---------------- finished ----------------
    if (finished) {
        val pct = (firstPassRight * 100) / mainRun.size.coerceAtLeast(1)
        LaunchedEffect(finished, saved) {
            if (!saved) {
                ProgressStore.finishLearn(unitId, pct)
                SessionStore.clear(unitId, SessionStore.MODE_PRACTICE)
                saved = true
            }
        }
        LearnResults(
            unitLabel = unit?.label ?: unitId,
            total = mainRun.size,
            firstPassRight = firstPassRight,
            extraAnswers = answeredTotal - mainRun.size,
            onAgain = {
                currentRun = pool.shuffled(rnd); pos = 0; isRetry = false; retryPass = 0
                firstPassRight = 0; answeredTotal = 0; firstPassAnswered = 0
                wrongKeys.clear(); roundMarks.clear()
                chosen = -1; finished = false; saved = false
            },
            onDone = onDone
        )
        return
    }

    // ---------------- round break ----------------
    if (showBreak) {
        val runComplete = pos >= currentRun.size
        RoundBreak(
            marks = roundMarks.toList(),
            answered = answeredTotal,
            total = mainRun.size,
            firstPassRight = firstPassRight,
            remaining = wrongKeys.size,
            isRetry = isRetry,
            runComplete = runComplete,
            onContinue = {
                roundMarks.clear()
                showBreak = false
                if (runComplete) {
                    if (wrongKeys.isEmpty()) {
                        finished = true
                    } else {
                        val next = wrongKeys.mapNotNull { k -> pool.firstOrNull { it.key == k } }
                        currentRun = next.shuffled(rnd)
                        pos = 0
                        isRetry = true
                        retryPass += 1
                    }
                }
            }
        )
        return
    }

    // ---------------- asking ----------------
    val entry = currentRun[pos.coerceIn(0, currentRun.lastIndex)]
    val question = remember(entry.key, pos, isRetry, retryPass) {
        QuestionFactory.build(entry, pool, rnd)
    }

    Column(
        Modifier.fillMaxSize().background(Ink.paper).verticalScroll(rememberScrollState()).padding(14.dp)
    ) {
        TopBar(
            t["common.back"],
            if (isRetry) t["practice.fixing"] else t["mode.practice"]
        ) { if (started) confirmLeave = true else onBack() }

        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (isRetry) t.f("practice.miss", pos + 1, currentRun.size) else t.f("practice.q", pos + 1, currentRun.size),
                style = kicker(11, 2.0, FontWeight.Bold)
            )
            // First pass only, and clamped: the bar measures the unit, not the
            // effort, so a student who needed six retries still ends at 100%.
            RuleBar(
                (firstPassAnswered.toFloat() / mainRun.size.coerceAtLeast(1)).coerceIn(0f, 1f),
                Modifier.padding(start = 12.dp).weight(1f),
                height = 11
            )
        }

        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                t.f("practice.firstPass", firstPassAnswered, mainRun.size),
                style = kicker(11, 1.0), color = Ink.ink.copy(alpha = 0.75f)
            )
            val retries = answeredTotal - firstPassAnswered
            if (retries > 0) Text(
                t.f("practice.retriesDone", retries),
                style = kicker(11, 1.0), color = Ink.ink.copy(alpha = 0.75f)
            )
        }

        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            repeat(ROUND) { i ->
                val m = roundMarks.getOrNull(i)
                Box(
                    Modifier
                        .weight(1f)
                        .height(6.dp)
                        .border(1.dp, Ink.ink)
                        .background(
                            when (m) {
                                true -> Ink.rightEdge
                                false -> Ink.wrongEdge
                                null -> Ink.paper
                            }
                        )
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        // prompt
        Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(instructionFor(question, t), right = tagFor(question.type, t))
            Column(Modifier.padding(16.dp)) {
                if (question.type == QType.SENTENCE_GAP) {
                    Text(
                        question.prompt,
                        fontFamily = Serif, fontSize = 17.sp, lineHeight = 26.sp, color = Ink.ink
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            question.prompt,
                            fontFamily = Serif,
                            fontSize = 28.sp,
                            lineHeight = 34.sp,
                            fontWeight = FontWeight.Bold,
                            color = Ink.ink,
                            modifier = Modifier.weight(1f)
                        )
                        if (question.type == QType.WORD_TO_MEANING) {
                            HardButton("▶", Modifier.border(1.5.dp, Ink.ink), fontSize = 12, padH = 10, padV = 6) {
                                speaker?.speak(question.entry.w)
                            }
                        }
                    }
                    if (question.subPrompt.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Tag(question.subPrompt)
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        question.options.forEachIndexed { i, opt ->
            val state = when {
                chosen < 0 -> 0
                i == question.correctIndex -> 1
                i == chosen -> 2
                else -> 0
            }
            OptionRow(
                letter = "ABCD"[i].toString(),
                text = opt,
                state = state,
                enabled = chosen < 0,
                onClick = {
                    if (chosen < 0) {
                        chosen = i
                        val correct = i == question.correctIndex
                        roundMarks.add(correct)
                        answeredTotal += 1
                        ProgressStore.recordAnswer(unitId, question.entry, correct)
                        if (!isRetry) {
                            firstPassAnswered += 1
                            if (correct) firstPassRight += 1
                            else if (!wrongKeys.contains(question.entry.key)) wrongKeys.add(question.entry.key)
                        } else {
                            if (correct) wrongKeys.remove(question.entry.key)
                        }
                    }
                }
            )
            Spacer(Modifier.height(8.dp))
        }

        if (chosen >= 0) {
            val correct = chosen == question.correctIndex
            Spacer(Modifier.height(4.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .border(2.dp, if (correct) Ink.rightEdge else Ink.wrongEdge)
                    .background(if (correct) Ink.rightFill else Ink.wrongFill)
                    .padding(13.dp)
            ) {
                Text(
                    (if (correct) t["practice.correct"] else t["practice.notQuite"]).uppercase(),
                    style = kicker(12, 2.5, FontWeight.Bold),
                    color = if (correct) Ink.rightEdge else Ink.wrongEdge
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "${question.entry.w}  ·  ${question.entry.p}  —  ${question.entry.c}",
                    fontFamily = Serif, fontSize = 15.sp, color = Ink.ink
                )
                if (question.entry.e.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        question.entry.e,
                        fontFamily = Serif, fontSize = 13.sp, lineHeight = 20.sp,
                        color = Ink.ink.copy(alpha = 0.85f)
                    )
                }
                if (!correct) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        t["practice.comesBack"],
                        style = kicker(9, 1.5), color = Ink.wrongEdge
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            HardButton(
                t["common.continue"],
                Modifier.fillMaxWidth().border(2.dp, Ink.ink),
                fontSize = 13
            ) {
                chosen = -1
                pos += 1
                if (pos % ROUND == 0 || pos >= currentRun.size) showBreak = true
            }
        }

        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun OptionRow(
    letter: String,
    text: String,
    state: Int,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val edge = when (state) { 1 -> Ink.rightEdge; 2 -> Ink.wrongEdge; else -> Ink.ink }
    val fill = when (state) { 1 -> Ink.rightFill; 2 -> Ink.wrongFill; else -> Ink.paper }
    Row(
        Modifier
            .fillMaxWidth()
            .border(2.dp, edge)
            .background(fill)
            .clickable(enabled = enabled) { onClick() },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            letter,
            style = kicker(13, 1.0, FontWeight.Bold),
            color = Ink.paper,
            modifier = Modifier
                .background(edge)
                .width(38.dp)
                .padding(vertical = 15.dp),
            textAlign = TextAlign.Center
        )
        Text(
            text,
            fontFamily = Serif,
            fontSize = 17.sp,
            lineHeight = 23.sp,
            color = Ink.ink,
            modifier = Modifier.weight(1f).padding(horizontal = 13.dp, vertical = 12.dp)
        )
    }
}

@Composable
private fun RoundBreak(
    marks: List<Boolean>,
    answered: Int,
    total: Int,
    firstPassRight: Int,
    remaining: Int,
    isRetry: Boolean,
    runComplete: Boolean,
    onContinue: () -> Unit
) {
    val t = LocalStrings.current
    val got = marks.count { it }
    Column(
        Modifier.fillMaxSize().background(Ink.paper).padding(14.dp),
        verticalArrangement = Arrangement.Center
    ) {
        PaperHeader(
            kickerText = if (isRetry) t["practice.fixing"] else t["practice.checkpoint"],
            title = if (runComplete && remaining > 0) t["practice.roundDone"]
                    else if (runComplete) t["practice.allCorrect"]
                    else t.f("practice.gotOf", got, marks.size),
            leftFoot = t.f("practice.answered", answered),
            rightFoot = t.f("practice.firstTime", firstPassRight, total)
        )

        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            marks.forEach { ok ->
                Box(
                    Modifier
                        .weight(1f)
                        .height(46.dp)
                        .border(2.dp, if (ok) Ink.rightEdge else Ink.wrongEdge)
                        .background(if (ok) Ink.rightFill else Ink.wrongFill),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (ok) "✓" else "✗",
                        fontFamily = Mono, fontSize = 20.sp,
                        color = if (ok) Ink.rightEdge else Ink.wrongEdge
                    )
                }
            }
            repeat((5 - marks.size).coerceAtLeast(0)) {
                Box(Modifier.weight(1f).height(46.dp))
            }
        }

        Spacer(Modifier.height(18.dp))
        Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(t["practice.progress"], right = "$answered / $total")
            Column(Modifier.padding(13.dp)) {
                RuleBar(answered.toFloat() / total.coerceAtLeast(1), Modifier.fillMaxWidth(), height = 16)
                Spacer(Modifier.height(9.dp))
                Text(
                    (if (remaining == 0) t["practice.nothingLeft"]
                     else t.f("practice.stillToGet", remaining)).uppercase(),
                    style = kicker(10, 2.0, FontWeight.Bold),
                    color = if (remaining == 0) Ink.rightEdge else Ink.wrongEdge
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        HardButton(
            when {
                runComplete && remaining > 0 -> t.f("practice.retestMissed", remaining)
                runComplete -> t["practice.seeResult"]
                else -> t["practice.keepGoing"]
            },
            Modifier.fillMaxWidth().border(2.dp, Ink.ink),
            fontSize = 13
        ) { onContinue() }
    }
}

@Composable
private fun LearnResults(
    unitLabel: String,
    total: Int,
    firstPassRight: Int,
    extraAnswers: Int,
    onAgain: () -> Unit,
    onDone: () -> Unit
) {
    val t = LocalStrings.current
    val pct = (firstPassRight * 100) / total.coerceAtLeast(1)
    Column(
        Modifier.fillMaxSize().background(Ink.paper).verticalScroll(rememberScrollState()).padding(14.dp)
    ) {
        PaperHeader(
            kickerText = t["practice.complete"],
            title = unitLabel,
            leftFoot = t.f("practice.firstTime", firstPassRight, total),
            rightFoot = "$pct%"
        )
        Spacer(Modifier.height(16.dp))
        Column(
            Modifier.fillMaxWidth().border(2.dp, Ink.rightEdge).background(Ink.rightFill).padding(16.dp)
        ) {
            Text(t["practice.everyCorrect"].uppercase(), style = kicker(11, 2.0, FontWeight.Bold), color = Ink.rightEdge)
            Spacer(Modifier.height(6.dp))
            Text(
                if (extraAnswers > 0) t.f("practice.extraTries", extraAnswers)
                else t["practice.straightThrough"],
                fontFamily = Serif, fontSize = 14.sp, color = Ink.ink
            )
        }
        Spacer(Modifier.height(14.dp))
        BlockButton(t["practice.again"], t["practice.againCaption"]) { onAgain() }
        Spacer(Modifier.height(10.dp))
        HardButton(t["common.done"], Modifier.fillMaxWidth().border(2.dp, Ink.ink), fontSize = 12) { onDone() }
        Spacer(Modifier.height(24.dp))
    }
}
