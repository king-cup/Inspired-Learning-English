package com.vocabdrill.student.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vocabdrill.student.audio.Speaker
import com.vocabdrill.student.data.PASS_PCT
import androidx.compose.ui.platform.LocalContext
import com.vocabdrill.student.data.AudioCache
import com.vocabdrill.student.data.ContentRepository
import com.vocabdrill.student.data.ProfileStore
import com.vocabdrill.student.data.ProgressStore
import com.vocabdrill.student.data.VocabRepository
import com.vocabdrill.student.i18n.LocalStrings
import kotlinx.coroutines.flow.MutableStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun UnitScreen(
    unitId: String,
    onBack: () -> Unit,
    onStudy: () -> Unit,
    onPractice: () -> Unit,
    onCards: () -> Unit,
    onTest: () -> Unit
) {
    val t = LocalStrings.current
    val unit = remember(unitId) { VocabRepository.resolve(unitId) }
    val progress by ProgressStore.state.collectAsState()

    // Remembered for the Library's "carry on" shortcut. A convenience, not a
    // record: it lives in the profile so resetting progress does not lose it.
    LaunchedEffect(unitId) { ProfileStore.setLastUnit(unitId) }

    // Pull this unit's clips the moment it opens, so the first tap on a word is
    // already a real recording rather than the device voice. One pack, not forty
    // requests; fire and forget, and it never interrupts the library-wide sync.
    val context = LocalContext.current
    LaunchedEffect(unitId) {
        val u = unit ?: return@LaunchedEffect
        AudioCache.ensureUnit(
            context,
            unitId,
            u.words.mapTo(HashSet()) { Speaker.slug(it.w) },
            ContentRepository.audioVersion()
        )
    }
    var confirmReset by remember { mutableStateOf(false) }
    val speaker = LocalSpeaker.current

    if (unit == null) {
        Box(Modifier.fillMaxSize().background(Ink.paper), contentAlignment = Alignment.Center) {
            Text(t["unit.notFound"].uppercase(), style = kicker(11, 3.0), color = Ink.ink)
        }
        return
    }

    val words = unit.words
    val known = progress.knownCount(unitId, words)
    val stat = progress.unit(unitId)
    val frac = if (words.isEmpty()) 0f else known.toFloat() / words.size

    Column(
        Modifier
            .fillMaxSize()
            .background(Ink.paper)
            .verticalScroll(rememberScrollState())
            .padding(14.dp)
    ) {
        TopBar(t["common.back"], unit.typeName, onBack)

        Spacer(Modifier.height(12.dp))
        PaperHeader(
            kickerText = unit.groupName.ifBlank { t["lib.book"] },
            title = unit.label,
            leftFoot = t.f("unit.words", words.size),
            rightFoot = if (stat.lastMs > 0)
                t.f("unit.lastUsed", SimpleDateFormat("d MMM", Locale.UK).format(Date(stat.lastMs)))
            else t["unit.notStarted"]
        )

        // ---- record --------------------------------------------------------
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(t["unit.record"], right = t.f("unit.knownOf", known, words.size))
            Column(Modifier.padding(13.dp)) {
                RuleBar(frac, Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    StatCell(t["unit.bestTest"], if (stat.bestPct > 0) "${stat.bestPct}%" else "—")
                    StatCell(t["unit.lastTest"], if (stat.tests.isNotEmpty()) "${stat.lastPct}%" else "—")
                    StatCell(t["unit.testsDone"], stat.tests.size.toString())
                    StatCell(t["unit.cardRuns"], stat.cardRuns.toString())
                }
            }
        }

        // ---- modes, in teaching order --------------------------------------
        Spacer(Modifier.height(14.dp))
        BlockButton(t["mode.study"], t["mode.studyCaption"]) { onStudy() }
        Spacer(Modifier.height(10.dp))
        BlockButton(t["mode.practice"], t["mode.practiceCaption"]) { onPractice() }
        Spacer(Modifier.height(10.dp))
        BlockButton(t["mode.cards"], t["mode.cardsCaption"]) { onCards() }
        Spacer(Modifier.height(10.dp))
        BlockButton(t["mode.test"], t.f("mode.testCaption", PASS_PCT)) { onTest() }

        // ---- words they keep missing ---------------------------------------
        // Built from data the app already collects and never showed. This is the
        // part Quizlet cannot do for this class: their own repeated misses.
        val missed = remember(progress, unitId) {
            words.map { it to progress.stat(unitId, it) }
                .filter { it.second.wrong >= 2 && it.second.wrong > it.second.right }
                .sortedByDescending { it.second.wrong }
                .take(12)
        }
        Spacer(Modifier.height(18.dp))
        Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(t["unit.missed"], right = if (missed.isEmpty()) "" else missed.size.toString())
            if (missed.isEmpty()) {
                Text(
                    t["unit.missedNone"],
                    fontFamily = Serif, fontSize = 14.sp, color = Ink.ink.copy(alpha = 0.7f),
                    modifier = Modifier.padding(13.dp)
                )
            } else {
                Column(Modifier.padding(vertical = 4.dp)) {
                    missed.forEach { (e, st) ->
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "${e.w}   —   ${e.c}",
                                fontFamily = Serif, fontSize = 14.sp, color = Ink.ink,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                t.f("unit.missedTimes", st.wrong),
                                style = kicker(9, 1.0, FontWeight.Bold), color = Ink.wrongEdge
                            )
                        }
                    }
                }
            }
        }

        // ---- test history ---------------------------------------------------
        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(t["unit.history"], right = if (stat.tests.isEmpty()) "" else stat.tests.size.toString())
            if (stat.tests.isEmpty()) {
                Text(
                    t["unit.historyNone"],
                    fontFamily = Serif, fontSize = 14.sp, color = Ink.ink.copy(alpha = 0.7f),
                    modifier = Modifier.padding(13.dp)
                )
            } else {
                val fmt = remember { SimpleDateFormat("d MMM HH:mm", Locale.UK) }
                stat.tests.asReversed().take(12).forEach { run ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                t.f("unit.attempt", run.attempt) +
                                    (if (run.retest) "  ·  " + t["unit.retestTag"] else ""),
                                style = kicker(10, 1.5, FontWeight.Bold), color = Ink.ink
                            )
                            Text(
                                fmt.format(Date(run.at)) + "   ·   " + t.f("test.scoreOf", run.correct, run.total),
                                style = kicker(9, 1.0), color = Ink.ink.copy(alpha = 0.7f)
                            )
                        }
                        Text(
                            "${run.pct}%",
                            style = kicker(15, 1.0, FontWeight.Bold),
                            color = if (run.passed) Ink.rightEdge else Ink.wrongEdge
                        )
                        Spacer(Modifier.width(0.dp))
                        Box(
                            Modifier
                                .padding(start = 10.dp)
                                .border(1.5.dp, if (run.passed) Ink.rightEdge else Ink.wrongEdge)
                                .background(if (run.passed) Ink.rightFill else Ink.wrongFill)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(
                                if (run.passed) t["unit.pass"] else t["unit.fail"],
                                style = kicker(9, 1.5, FontWeight.Bold),
                                color = if (run.passed) Ink.rightEdge else Ink.wrongEdge
                            )
                        }
                    }
                    HRule(1.0)
                }
            }
        }

        // ---- audio warning --------------------------------------------------
        Spacer(Modifier.height(18.dp))
        val idle = remember { MutableStateFlow(Speaker.Status.STARTING) }
        val speechStatus by (speaker?.status ?: idle).collectAsState()
        if (speaker != null && !speaker.hasBundledAudio && speechStatus == Speaker.Status.UNAVAILABLE) {
            Column(
                Modifier.fillMaxWidth().border(2.dp, Ink.wrongEdge).background(Ink.wrongFill).padding(11.dp)
            ) {
                Text(t["audio.noEngine"].uppercase(), style = kicker(10, 1.5, FontWeight.Bold), color = Ink.wrongEdge)
                Text(
                    t["audio.noEngineBody"],
                    fontFamily = Serif, fontSize = 12.sp, color = Ink.wrongEdge,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Spacer(Modifier.height(14.dp))
        }

        HardButton(t["unit.reset"], Modifier.fillMaxWidth().border(1.5.dp, Ink.ink), fontSize = 10) {
            confirmReset = true
        }
        Spacer(Modifier.height(24.dp))
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            containerColor = Ink.paper,
            title = { Text(t["unit.resetAsk"].uppercase(), style = kicker(12, 2.0, FontWeight.Bold), color = Ink.ink) },
            text = { Text(t.f("unit.resetBody", unit.label), fontFamily = Serif, fontSize = 14.sp, color = Ink.ink) },
            confirmButton = { HardButton(t["unit.reset"], fontSize = 11) { ProgressStore.resetUnit(unitId); confirmReset = false } },
            dismissButton = { HardButton(t["common.cancel"], fontSize = 11) { confirmReset = false } }
        )
    }
}

@Composable
fun TopBar(left: String, right: String, onLeft: () -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        HardButton(left, Modifier.border(1.5.dp, Ink.ink), fontSize = 10, padH = 10, padV = 6, onClick = onLeft)
        Text(right.uppercase(), style = kicker(9, 2.0), color = Ink.ink)
    }
}

@Composable
private fun StatCell(label: String, value: String) {
    Column {
        Text(label.uppercase(), style = kicker(8, 2.0), color = Ink.ink)
        Text(value, fontFamily = Mono, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink.ink)
    }
}
