package com.vocabdrill.student.data

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Progress export / import and the shareable text report.
 *
 * The envelope is a CROSS-PLATFORM contract with the PWA's store.js: a backup
 * written on an iPhone must restore on Android and vice versa. That is the only
 * migration path this project has -- there is no server and no account -- so
 * the field names, the schema number and the validation rules all have to stay
 * byte-compatible with `exportBackup()` / `validateBackup()` on the web.
 */
object Backup {

    const val APP_ID = "inspired-vocab"
    const val KIND = "progress-backup"
    const val SCHEMA = 1

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = true }
    private val strict = Json { ignoreUnknownKeys = true }

    @Serializable
    data class Envelope(
        val app: String = APP_ID,
        val kind: String = KIND,
        val schema: Int = SCHEMA,
        val exportedAt: String = "",
        val progress: Progress = Progress()
    )

    private fun iso(ms: Long): String {
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date(ms))
    }

    fun dateStamp(ms: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ms))

    fun fileName(ms: Long = System.currentTimeMillis()) = "vocab-progress-${dateStamp(ms)}.json"
    fun reportFileName(ms: Long = System.currentTimeMillis()) = "progress-report-${dateStamp(ms)}.txt"

    fun export(p: Progress, atMs: Long = System.currentTimeMillis()): String =
        json.encodeToString(Envelope.serializer(), Envelope(exportedAt = iso(atMs), progress = p))

    /**
     * Returns the progress to install, or null if this is not a backup file.
     *
     * Accepts a bare `{words, units}` object as well as the envelope: the web
     * shipped raw `toJSON()` output before the envelope existed and a student
     * may still be carrying one. Validation is deliberately shallow -- enough to
     * refuse a photo or a homework PDF, not so strict that a slightly older
     * export is rejected and a student loses everything.
     */
    fun parse(text: String): Progress? = runCatching {
        val root = strict.parseToJsonElement(text).jsonObject
        val body: JsonObject = when {
            root.containsKey("progress") -> root["progress"]!!.jsonObject
            root.containsKey("words") && root.containsKey("units") -> root
            else -> return@runCatching null
        }
        val words = body["words"]?.jsonObject ?: return@runCatching null
        val units = body["units"]?.jsonObject ?: return@runCatching null
        // Every word value must be an object carrying a boolean `known`.
        for ((_, v) in words) {
            val o = v.jsonObject
            val k = o["known"]?.jsonPrimitive ?: return@runCatching null
            if (k.content != "true" && k.content != "false") return@runCatching null
        }
        for ((_, v) in units) v.jsonObject
        strict.decodeFromJsonElement(Progress.serializer(), body)
    }.getOrNull()

    // ---- report ----------------------------------------------------------

    data class Missed(val word: String, val zh: String, val wrong: Int, val unitLabel: String)
    data class Best(val label: String, val bestPct: Int, val tests: Int)

    data class Summary(
        val unitsStarted: Int,
        val unitsComplete: Int,
        val wordsKnown: Int,
        val topMissed: List<Missed>,
        val bestScores: List<Best>
    )

    /**
     * "Started" is deliberately generous -- any evidence at all that the student
     * opened the unit and did something. A unit counts as passed on bestPct, so
     * one good run is never erased by a later bad one.
     */
    fun summarise(p: Progress): Summary {
        val started = p.units.count { (_, u) ->
            u.cardRuns > 0 || u.learnRuns > 0 || u.tests.isNotEmpty() || u.lastMs > 0L
        }
        val complete = p.units.count { (_, u) -> u.bestPct >= PASS_PCT }
        val known = p.words.count { it.value.known }

        val missed = p.words.entries
            .filter { it.value.wrong >= 2 && it.value.wrong > it.value.right }
            .sortedByDescending { it.value.wrong }
            .take(15)
            .map { (key, stat) ->
                // key is "<unitId>|<word>|<pos>"; recover the word for display.
                val parts = key.split("|")
                val unitId = parts.getOrElse(0) { "" }
                val word = parts.getOrElse(1) { key }
                val entry = VocabRepository.wordsFor(unitId)
                    .firstOrNull { it.w.trim().lowercase() == word }
                Missed(
                    word = entry?.w ?: word,
                    zh = entry?.c.orEmpty(),
                    wrong = stat.wrong,
                    unitLabel = VocabRepository.resolve(unitId)?.let { "${it.groupName} ${it.label}".trim() } ?: unitId
                )
            }

        val best = p.units.entries
            .filter { it.value.tests.isNotEmpty() }
            .sortedByDescending { it.value.bestPct }
            .take(15)
            .map { (unitId, u) ->
                Best(
                    label = VocabRepository.resolve(unitId)?.let { "${it.groupName} ${it.label}".trim() } ?: unitId,
                    bestPct = u.bestPct,
                    tests = u.tests.size
                )
            }

        return Summary(started, complete, known, missed, best)
    }
}
