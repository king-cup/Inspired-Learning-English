package com.vocabdrill.student.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.LaunchedEffect
import com.vocabdrill.student.data.Entry
import com.vocabdrill.student.data.PASS_PCT
import com.vocabdrill.student.data.SessionStore
import com.vocabdrill.student.data.TestSession
import com.vocabdrill.student.data.ProfileStore
import com.vocabdrill.student.data.ProgressStore
import com.vocabdrill.student.data.QType
import com.vocabdrill.student.data.Question
import com.vocabdrill.student.data.QuestionFactory
import com.vocabdrill.student.data.VocabRepository
import com.vocabdrill.student.i18n.LocalStrings
import kotlinx.serialization.json.Json
import kotlin.random.Random

private val SESSION_JSON = Json { ignoreUnknownKeys = true; encodeDefaults = true }

/**
 * A test asks the two recall directions only.
 *
 * A sentence-gap item shows the answer inside its own example sentence, which
 * is a useful scaffold while practising and a free mark in an exam. Practice
 * keeps all three shapes.
 */
private val TEST_TYPES = listOf(QType.WORD_TO_MEANING, QType.MEANING_TO_WORD)

private enum class Phase { SETUP, ASKING, RESULT }

/**
 * Summative assessment, deliberately unlike Practice: no feedback of any kind
 * until the student presses Complete. They choose the length, they can revisit
 * and change answers before submitting, and only then does anything turn green
 * or red.
 */
@Composable
fun TestScreen(unitId: String, onBack: () -> Unit, onDone: () -> Unit) {
    val t = LocalStrings.current
    val unit = remember(unitId) { VocabRepository.resolve(unitId) }
    val profile by ProfileStore.state.collectAsState()
    val pool = unit?.words.orEmpty()
    val rnd = remember { Random(System.nanoTime()) }

    var phase by remember { mutableStateOf(Phase.SETUP) }
    var isRetest by remember { mutableStateOf(false) }
    var questions by remember { mutableStateOf<List<Question>>(emptyList()) }
    var pos by remember { mutableStateOf(0) }
    val answers = remember { mutableStateMapOf<Int, Int>() }   // question index -> chosen option
    var confirmFinish by remember { mutableStateOf(false) }
    var wrongEntries by remember { mutableStateOf<List<Entry>>(emptyList()) }
    var score by remember { mutableStateOf(0) }

    // --- session recovery ---
    var resumeOffer by remember { mutableStateOf<TestSession?>(null) }
    var restoreChecked by remember { mutableStateOf(false) }
    var confirmLeave by remember { mutableStateOf(false) }

    fun persistTest() {
        if (phase != Phase.ASKING) return
        SessionStore.save(
            unitId, SessionStore.MODE_TEST,
            SESSION_JSON.encodeToString(
                TestSession.serializer(),
                TestSession(
                    questionKeys = questions.map { it.entry.key },
                    // -1 means unanswered; the map is sparse and a list is not.
                    answers = questions.indices.map { answers[it] ?: -1 },
                    pos = pos,
                    isRetest = isRetest
                )
            )
        )
    }

    LaunchedEffect(pool) {
        if (restoreChecked || pool.isEmpty()) return@LaunchedEffect
        restoreChecked = true
        val raw = SessionStore.load(unitId, SessionStore.MODE_TEST) ?: return@LaunchedEffect
        val saved = runCatching {
            SESSION_JSON.decodeFromString(TestSession.serializer(), raw)
        }.getOrNull()
        if (saved != null && saved.questionKeys.any { k -> pool.any { it.key == k } }) {
            resumeOffer = saved
        } else {
            SessionStore.clear(unitId, SessionStore.MODE_TEST)
        }
    }

    LaunchedEffect(pos, answers.size, phase) { persistTest() }

    if (unit == null || pool.size < 2) {
        Column(Modifier.fillMaxSize().background(Ink.paper).padding(14.dp)) {
            TopBar(t["common.back"], t["mode.test"], onBack)
            Spacer(Modifier.height(30.dp))
            Text(t["practice.tooShort"].uppercase(), style = kicker(11, 2.5), color = Ink.ink)
        }
        return
    }

    resumeOffer?.let { saved ->
        ResumeDialog(
            modeLabel = t["session.test"],
            onResume = {
                val byKey = pool.associateBy { it.key }
                val entries = saved.questionKeys.mapNotNull { byKey[it] }
                if (entries.isNotEmpty()) {
                    // Questions are rebuilt rather than serialised: the options
                    // are regenerated from the same unit, so a restored test is
                    // the same assessment even if the wording of a distractor
                    // moves. The ANSWERS are what must survive verbatim.
                    questions = entries.map { QuestionFactory.build(it, pool, rnd, TEST_TYPES) }
                    answers.clear()
                    saved.answers.forEachIndexed { i, a -> if (a >= 0 && i <= questions.lastIndex) answers[i] = a }
                    pos = saved.pos.coerceIn(0, questions.lastIndex)
                    isRetest = saved.isRetest
                    phase = Phase.ASKING
                }
                resumeOffer = null
            },
            onStartOver = {
                SessionStore.clear(unitId, SessionStore.MODE_TEST)
                resumeOffer = null
            }
        )
        return
    }

    if (confirmLeave) {
        LeaveDialog(
            modeLabel = t["session.test"],
            onStay = { confirmLeave = false },
            onLeave = { confirmLeave = false; persistTest(); onBack() }
        )
    }

    BackHandler(enabled = phase == Phase.ASKING && answers.isNotEmpty()) { confirmLeave = true }

    fun startTest(entries: List<Entry>, retest: Boolean) {
        questions = entries.shuffled(rnd).map { QuestionFactory.build(it, pool, rnd, TEST_TYPES) }
        answers.clear()
        pos = 0
        isRetest = retest
        phase = Phase.ASKING
    }

    fun finish() {
        var correct = 0
        val wrong = mutableListOf<Entry>()
        questions.forEachIndexed { i, q ->
            val ok = answers[i] == q.correctIndex
            if (ok) correct++ else wrong += q.entry
            ProgressStore.recordTestAnswer(unitId, q.entry, ok)
        }
        score = correct
        wrongEntries = wrong
        ProgressStore.finishTest(unitId, correct, questions.size, isRetest)
        SessionStore.clear(unitId, SessionStore.MODE_TEST)
        phase = Phase.RESULT
    }

    when (phase) {
        // ------------------------------------------------------------- SETUP
        Phase.SETUP -> Column(
            Modifier.fillMaxSize().background(Ink.paper).verticalScroll(rememberScrollState()).padding(14.dp)
        ) {
            TopBar(t["common.back"], t["mode.test"], onBack)
            Spacer(Modifier.height(12.dp))
            PaperHeader(
                kickerText = unit.groupName.ifBlank { t["lib.book"] },
                title = unit.label,
                leftFoot = t["test.setup"],
                rightFoot = t.f("unit.words", pool.size)
            )
            Spacer(Modifier.height(14.dp))
            Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
                BarLabel(t["test.howMany"])
                Column(Modifier.padding(13.dp)) {
                    Text(
                        t.f("test.lengthHelp", PASS_PCT),
                        fontFamily = Serif, fontSize = 14.sp, color = Ink.ink
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            // Only offer lengths the unit can actually fill.
            if (pool.size >= 10) {
                BlockButton(t["test.ten"], "") { startTest(pool.shuffled(rnd).take(10), false) }
                Spacer(Modifier.height(10.dp))
            }
            if (pool.size >= 20) {
                BlockButton(t["test.twenty"], "") { startTest(pool.shuffled(rnd).take(20), false) }
                Spacer(Modifier.height(10.dp))
            }
            BlockButton(t.f("test.all", pool.size), "") { startTest(pool, false) }
            Spacer(Modifier.height(30.dp))
        }

        // ------------------------------------------------------------ ASKING
        Phase.ASKING -> {
            val q = questions[pos.coerceIn(0, questions.lastIndex)]
            val chosen = answers[pos] ?: -1
            Column(
                Modifier.fillMaxSize().background(Ink.paper).verticalScroll(rememberScrollState()).padding(14.dp)
            ) {
                TopBar(
                    t["common.back"],
                    if (isRetest) t["test.retestTitle"] else t["mode.test"]
                ) { if (answers.isNotEmpty()) confirmLeave = true else onBack() }

                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(t.f("test.q", pos + 1, questions.size), style = kicker(11, 2.0, FontWeight.Bold), color = Ink.ink)
                    RuleBar(answers.size.toFloat() / questions.size, Modifier.padding(start = 12.dp).weight(1f), height = 11)
                }
                Text(
                    t["test.noAnswersYet"].uppercase(),
                    style = kicker(8, 2.0), color = Ink.ink.copy(alpha = 0.6f),
                    modifier = Modifier.padding(top = 5.dp)
                )

                Spacer(Modifier.height(14.dp))
                Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
                    BarLabel(instructionFor(q, t), right = tagFor(q.type, t))
                    Column(Modifier.padding(16.dp)) {
                        if (q.type == QType.SENTENCE_GAP) {
                            Text(q.prompt, fontFamily = Serif, fontSize = 17.sp, lineHeight = 26.sp, color = Ink.ink)
                        } else {
                            Text(
                                q.prompt,
                                fontFamily = Serif, fontSize = 28.sp, lineHeight = 34.sp,
                                fontWeight = FontWeight.Bold, color = Ink.ink
                            )
                            if (q.subPrompt.isNotBlank()) {
                                Spacer(Modifier.height(8.dp))
                                Tag(q.subPrompt)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                q.options.forEachIndexed { i, opt ->
                    // Selected, NOT marked. Nothing here reveals correctness.
                    val on = i == chosen
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .border(2.dp, Ink.ink)
                            .background(Ink.paper)
                            .clickable { answers[pos] = i },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "ABCD"[i].toString(),
                            style = kicker(13, 1.0, FontWeight.Bold),
                            color = Ink.paper,
                            modifier = Modifier.background(Ink.ink).width(38.dp).padding(vertical = 15.dp),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            opt,
                            fontFamily = Serif, fontSize = 17.sp, lineHeight = 23.sp,
                            color = Ink.ink,
                            modifier = Modifier.weight(1f).padding(horizontal = 13.dp, vertical = 12.dp)
                        )
                        if (on) {
                            Box(
                                Modifier.padding(end = 12.dp).background(Ink.ink).padding(horizontal = 7.dp, vertical = 4.dp)
                            ) { Text("✓", fontFamily = Mono, fontSize = 12.sp, color = Ink.paper) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }

                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HardButton(
                        "←",
                        Modifier
                            .border(2.dp, Ink.ink)
                            .heightIn(min = 48.dp)
                            .semantics { contentDescription = t["a11y.prev"] },
                        fontSize = 23, padH = 20, padV = 8,
                        enabled = pos > 0
                    ) { if (pos > 0) pos-- }
                    HardButton(
                        "→",
                        Modifier
                            .weight(1f)
                            .border(2.dp, Ink.ink)
                            .heightIn(min = 48.dp)
                            .semantics { contentDescription = t["a11y.next"] },
                        fontSize = 23, padV = 8,
                        enabled = pos < questions.lastIndex
                    ) { if (pos < questions.lastIndex) pos++ }
                }
                Spacer(Modifier.height(10.dp))
                HardButton(t["test.finish"], Modifier.fillMaxWidth().border(2.dp, Ink.ink), fontSize = 13) {
                    if (answers.size < questions.size) confirmFinish = true else finish()
                }
                Spacer(Modifier.height(28.dp))
            }

            if (confirmFinish) {
                AlertDialog(
                    onDismissRequest = { confirmFinish = false },
                    containerColor = Ink.paper,
                    title = { Text(t["test.finishAsk"].uppercase(), style = kicker(12, 2.0, FontWeight.Bold), color = Ink.ink) },
                    text = {
                        Text(
                            t.f("test.finishBody", answers.size, questions.size),
                            fontFamily = Serif, fontSize = 14.sp, color = Ink.ink
                        )
                    },
                    confirmButton = { HardButton(t["test.finish"], fontSize = 11) { confirmFinish = false; finish() } },
                    dismissButton = { HardButton(t["common.cancel"], fontSize = 11) { confirmFinish = false } }
                )
            }
        }

        // ------------------------------------------------------------ RESULT
        Phase.RESULT -> {
            val total = questions.size
            val pct = if (total == 0) 0 else (score * 100) / total
            val passed = pct >= PASS_PCT
            val name = profile.name.ifBlank { "" }
            Column(
                Modifier.fillMaxSize().background(Ink.paper).verticalScroll(rememberScrollState()).padding(14.dp)
            ) {
                TopBar(t["common.back"], t["test.result"], onDone)
                Spacer(Modifier.height(12.dp))
                PaperHeader(
                    kickerText = t["test.result"],
                    title = unit.label,
                    leftFoot = t.f("test.scoreOf", score, total),
                    rightFoot = if (passed) t["unit.pass"] else t["unit.fail"]
                )
                Spacer(Modifier.height(16.dp))
                GradeBlock(
                    pct = pct, correct = score, total = total, passed = passed,
                    caption = if (passed) t.f("test.passedMsg", name) else t.f("test.failedMsg", name)
                )

                Spacer(Modifier.height(16.dp))
                if (wrongEntries.isEmpty()) {
                    Column(
                        Modifier.fillMaxWidth().border(2.dp, Ink.rightEdge).background(Ink.rightFill).padding(14.dp)
                    ) {
                        Text(t["test.allRight"].uppercase(), style = kicker(11, 2.0, FontWeight.Bold), color = Ink.rightEdge)
                    }
                } else {
                    Column(Modifier.fillMaxWidth().border(2.dp, Ink.wrongEdge)) {
                        BarLabel(t["test.gotWrong"], right = wrongEntries.size.toString())
                        Column(Modifier.background(Ink.wrongFill).fillMaxWidth().padding(12.dp)) {
                            wrongEntries.forEach { e ->
                                Text(
                                    "${e.w}  ·  ${e.p}   —   ${e.c}",
                                    fontFamily = Serif, fontSize = 14.sp, color = Ink.ink,
                                    modifier = Modifier.padding(vertical = 3.dp)
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    BlockButton(t.f("test.retestWrong", wrongEntries.size), t["test.retestCaption"]) {
                        startTest(wrongEntries, true)
                    }
                }

                Spacer(Modifier.height(10.dp))
                BlockButton(t["test.takeAgain"], t["test.takeAgainCaption"]) { phase = Phase.SETUP }
                Spacer(Modifier.height(10.dp))
                HardButton(t["common.done"], Modifier.fillMaxWidth().border(2.dp, Ink.ink), fontSize = 12) { onDone() }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

internal fun instructionFor(q: Question, t: com.vocabdrill.student.i18n.Strings): String = when (q.type) {
    QType.WORD_TO_MEANING -> t["practice.meaningQ"]
    QType.MEANING_TO_WORD -> t["practice.recallQ"]
    QType.SENTENCE_GAP -> t["practice.gapQ"]
}

internal fun tagFor(type: QType, t: com.vocabdrill.student.i18n.Strings): String = when (type) {
    QType.WORD_TO_MEANING -> t["practice.tagMeaning"]
    QType.MEANING_TO_WORD -> t["practice.tagRecall"]
    QType.SENTENCE_GAP -> t["practice.tagContext"]
}
