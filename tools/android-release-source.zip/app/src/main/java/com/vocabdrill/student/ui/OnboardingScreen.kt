package com.vocabdrill.student.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vocabdrill.student.i18n.Lang
import com.vocabdrill.student.i18n.LocalStrings
import com.vocabdrill.student.i18n.stringsFor

/**
 * Shown once, on first launch. Collects the two things every later screen
 * depends on: what to call the student, and which language to speak to them in.
 * The language buttons are labelled in their own language so a student who
 * cannot read the current one can still find theirs.
 */
@Composable
fun OnboardingScreen(onDone: (name: String, lang: Lang) -> Unit) {
    var name by remember { mutableStateOf("") }
    var lang by remember { mutableStateOf(Lang.EN) }
    var warn by remember { mutableStateOf(false) }

    // Preview the chosen language immediately -- the screen retranslates as
    // they tap, which is the clearest possible confirmation of the choice.
    val t = remember(lang) { stringsFor(lang) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Ink.paper)
            .verticalScroll(rememberScrollState())
            .padding(14.dp)
    ) {
        Spacer(Modifier.height(18.dp))
        PaperHeader(
            kickerText = t["onboard.kicker"],
            title = t["app.title"],
            leftFoot = t["onboard.title"],
            rightFoot = "v$APP_VERSION"
        )

        // --- name ------------------------------------------------------------
        Spacer(Modifier.height(18.dp))
        Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(t["onboard.nameLabel"])
            Column(Modifier.padding(13.dp)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, if (warn && name.isBlank()) Ink.wrongEdge else Ink.ink)
                        .padding(horizontal = 12.dp, vertical = 13.dp)
                ) {
                    if (name.isEmpty()) {
                        Text(t["onboard.nameHint"], style = kicker(15, 0.5), color = Ink.ink.copy(alpha = 0.35f))
                    }
                    BasicTextField(
                        value = name,
                        onValueChange = { if (it.length <= 24) { name = it; warn = false } },
                        singleLine = true,
                        textStyle = TextStyle(fontFamily = Mono, fontSize = 15.sp, color = Ink.ink),
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Words,
                            imeAction = ImeAction.Done
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Text(
                    if (warn && name.isBlank()) t["onboard.needName"] else t["onboard.nameHelp"],
                    fontFamily = Serif,
                    fontSize = 13.sp,
                    color = if (warn && name.isBlank()) Ink.wrongEdge else Ink.ink.copy(alpha = 0.75f),
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }

        // --- language --------------------------------------------------------
        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(t["onboard.langLabel"])
            Row(Modifier.fillMaxWidth().padding(13.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Lang.entries.forEach { option ->
                    HardButton(
                        option.label,
                        Modifier.weight(1f).border(2.dp, Ink.ink),
                        selected = option == lang,
                        fontSize = 14,
                        padV = 16,
                        onClick = { lang = option }
                    )
                }
            }
            Text(
                t["onboard.langHelp"],
                fontFamily = Serif,
                fontSize = 13.sp,
                color = Ink.ink.copy(alpha = 0.75f),
                modifier = Modifier.padding(start = 13.dp, end = 13.dp, top = 6.dp, bottom = 13.dp)
            )
        }

        Spacer(Modifier.height(20.dp))
        BlockButton(t["onboard.begin"], t["onboard.nameHelp"]) {
            if (name.isBlank()) warn = true else onDone(name.trim(), lang)
        }
        Spacer(Modifier.height(30.dp))
    }
}
