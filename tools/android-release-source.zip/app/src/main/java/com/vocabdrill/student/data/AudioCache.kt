package com.vocabdrill.student.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.cancellation.CancellationException

/**
 * Clips for words the APK does not ship.
 *
 * The PWA has no equivalent of this: on the web the service worker just fetches
 * audio/<slug>.m4a on demand. An installed APK instead ships ~5k pre-generated
 * .ogg clips in assets/audio/, and a remote content update can introduce words
 * that were never in that build. Those -- and only those -- are pulled from the
 * same audio/ directory the website serves.
 *
 * Deliberately a separate object from ContentRepository: the two have different
 * failure rules. Content is all-or-nothing and blocks the first screen; audio is
 * best-effort, runs long after startup, and a clip that never arrives costs the
 * student nothing worse than the device voice.
 *
 * Format: the site's clips are AAC-LC in MP4 (.m4a), which MediaPlayer decodes
 * natively on every supported API level, so the web files are reused as-is and
 * there is no Android-specific audio hosting to keep in sync.
 *
 * PACKS (v1.04, ported from js/audio.js): a few hundred clips is a few hundred
 * HTTP round trips, and on a classroom connection the round trips -- not the
 * bytes -- are what the student waits through. A pack is the original .m4a
 * files concatenated with NO framing plus an index of [offset, length], so a
 * slice at the recorded offset is byte-identical to the standalone file. Each
 * slice is written to filesDir/audio/<slug>.m4a exactly as the per-clip path
 * would have written it, which is why Speaker knows nothing about any of this.
 */
object AudioCache {

    /** 4-6 keeps a classroom wifi usable while still finishing a few hundred
     *  clips in a reasonable time. More just makes every request slower. */
    private const val CONCURRENCY = 5
    private const val CLIP_TIMEOUT_MS = 20_000

    /** A book pack is ~2.6 MB against a clip's ~5 KB. The read timeout is per
     *  chunk rather than for the whole body, but a first byte on a congested
     *  school link can still be slow enough to need the extra headroom. */
    private const val PACK_TIMEOUT_MS = 30_000

    /** A pack is only worth a request if it brings several clips; below that the
     *  individual files are cheaper than the bytes we would waste. */
    private const val MIN_PACK_GAIN = 3

    /**
     * And it is only worth a request if most of what it carries is wanted.
     * Clips average ~5.7 KB, so ten times that per clip actually gained is the
     * point where the round trips saved stop paying for the bytes wasted.
     *
     * Without this, three new words scattered across three units of one book
     * beat every unit pack on gain and pulled that book's 2.6 MB pack for
     * ~15 KB of audio -- on a student's mobile data.
     */
    private const val MAX_BYTES_PER_NEW_CLIP = 60_000L

    /** A slice is allocated as one ByteArray, so a hostile or corrupt index must
     *  not be able to ask for a gigabyte. Real clips are ~5 KB. */
    private const val MAX_CLIP_BYTES = 4L * 1024 * 1024

    private const val TAG = "VocabDrill"

    /** Slugs are [a-z0-9_] by construction (see Speaker.slug), but they arrive
     *  from a remote file and are turned into a filename here, so anything that
     *  could walk out of filesDir is dropped rather than trusted. */
    private val SAFE_SLUG = Regex("^[A-Za-z0-9._-]+$")

    /** What Settings can show while a batch runs. total == 0 means idle.
     *  Named AudioProgress because `Progress` is already the saved-records model
     *  in this package and shadowing it here would be a trap. */
    data class AudioProgress(val done: Int = 0, val total: Int = 0, val failed: Int = 0)

    @Serializable
    private data class AudioState(val audioVersion: String = "1")

    // ---- pack index model ------------------------------------------------
    // Mirrors tools/build_audio_packs.py. `units` and `books` are the web UI's
    // lookup tables and are not needed here: planning works off `packs` alone,
    // and ignoreUnknownKeys drops them rather than paying to model them.

    @Serializable
    private data class PackEntry(
        val url: String = "",
        val bytes: Long = 0L,
        /** slug -> [offset, length] into the pack file. */
        val clips: Map<String, List<Long>> = emptyMap()
    )

    @Serializable
    private data class PackIndex(
        val version: Int = 1,
        val audioVersion: String = "1",
        val ext: String = ".m4a",
        val packs: Map<String, PackEntry> = emptyMap()
    )

    private data class Plan(val packIds: List<String>, val leftover: Set<String>)

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _progress = MutableStateFlow(AudioProgress())
    val progress: StateFlow<AudioProgress> = _progress

    private lateinit var dir: File
    private lateinit var stateFile: File
    private lateinit var stateTmp: File
    private lateinit var packsFile: File
    private lateinit var packsTmp: File
    private var started = false

    @Volatile private var audioVersion: String = "1"

    /**
     * Bumped every time the audioVersion wipe empties filesDir/audio. A batch
     * carries the value it started with and refuses to file a clip once it no
     * longer matches, so bytes fetched for the old audio can never be renamed
     * into place after the wipe has already walked past that filename.
     */
    private val versionEpoch = AtomicInteger(0)

    /** Held for the microseconds of a rename and for the whole wipe, so the two
     *  can never interleave. See [commit]. */
    private val fileGate = Any()

    /** Slugs present in filesDir/audio as .m4a. Source of truth is the disk;
     *  this is only the in-memory mirror, rebuilt on init. */
    private val downloaded = ConcurrentHashMap.newKeySet<String>()

    /** Slugs shipped in the APK. These are .ogg and are never touched by an
     *  audioVersion bump -- that version only cache-busts the website's files. */
    private val bundled = ConcurrentHashMap.newKeySet<String>()

    /**
     * Slugs some batch is currently fetching. A batch only works on a slug it
     * won the claim for, which is what lets [ensureUnit] run alongside a full
     * [sync] instead of cancelling it: the two can overlap freely because they
     * can never hold the same filename at the same time.
     */
    private val claims = ConcurrentHashMap.newKeySet<String>()

    @Volatile private var job: Job? = null

    /** One in-flight prefetch per unit. Opening the same unit twice, or a
     *  recomposition firing the effect again, must not start a second batch. */
    private val unitJobs = HashMap<String, Job>()

    // The pack index is ~490 KB of JSON and is wanted by every batch, so it is
    // parsed once and guarded by a mutex rather than fetched per batch.
    private val packMutex = Mutex()
    private var packIndex: PackIndex? = null
    private var packVersion: String? = null
    /** Reverse map slug -> pack ids, built with the index. Without it the greedy
     *  loop rescans every pack's clip list every round -- ~10k entries per pass,
     *  which is real time on a student's phone. */
    @Volatile private var packBySlug: Map<String, List<String>> = emptyMap()
    /** An audioVersion we already know has no usable packs, so a unit open does
     *  not re-ask the network every time. */
    private var packMissForVersion: String? = null

    fun init(context: Context) {
        if (started) return
        synchronized(this) {
            if (started) return
            val app = context.applicationContext
            dir = File(app.filesDir, "audio")
            stateFile = File(app.filesDir, "audio-state.json")
            stateTmp = File(app.filesDir, "audio-state.json.tmp")
            packsFile = File(app.filesDir, "audio-packs.json")
            packsTmp = File(app.filesDir, "audio-packs.json.tmp")
            runCatching {
                if (stateFile.exists()) {
                    audioVersion = json.decodeFromString(AudioState.serializer(), stateFile.readText())
                        .audioVersion.ifBlank { "1" }
                }
            }
            runCatching {
                app.assets.list("audio")?.forEach { name ->
                    if (name.endsWith(".ogg")) bundled.add(name.removeSuffix(".ogg"))
                }
            }
            refreshFromDisk()
            started = true
        }
    }

    private fun refreshFromDisk() {
        downloaded.clear()
        runCatching {
            dir.listFiles()?.forEach { f ->
                if (!f.isFile) return@forEach
                // Scratch files from a batch that was killed mid-download. They
                // are never valid clips, so sweep them rather than let them pile
                // up -- an abandoned pack download is multi-megabyte.
                if (f.name.endsWith(".tmp")) { f.delete(); return@forEach }
                if (f.name.endsWith(".m4a") && f.length() > 0L) {
                    downloaded.add(f.name.removeSuffix(".m4a"))
                }
            }
        }
    }

    /** Slugs with a downloaded clip on disk. Copies, so prefer
     *  [downloadedCount] for anything on a recomposition path. */
    fun downloadedSlugs(): Set<String> = downloaded.toSet()

    /** How many downloaded clips are on disk. O(1), safe to poll. */
    fun downloadedCount(): Int = downloaded.size

    /** True when [slug] can be pronounced from a downloaded clip. */
    fun hasDownloaded(slug: String): Boolean = downloaded.contains(slug)

    /** The audioVersion the downloaded clips were fetched at. */
    fun downloadedAudioVersion(): String = audioVersion

    /**
     * Bring the download cache in line with the content that was just applied.
     * Returns immediately; the work runs on [scope]. Safe to call on every load.
     */
    fun sync(context: Context, wanted: Set<String>, version: String) {
        // init() lists ~5k asset names; deliberately NOT done here, because
        // sync() is called from the startup load and must not add to it.
        val app = context.applicationContext
        // A newer sync always wins: the previous one was aimed at content that
        // is no longer active. Waiting for it to unwind before starting matters
        // -- two batches racing on the same slug would be writing the same file.
        val previous = job
        previous?.cancel()
        job = scope.launch {
            runCatching { previous?.join() }
            init(app)
            runCatching { syncNow(wanted, version) }
                .onFailure { if (it !is CancellationException) Log.w(TAG, "[audio] sync failed: ${it.message}") }
        }
    }

    /**
     * Warm one unit's clips, for the moment a student opens it. Fire and forget.
     *
     * Unlike [sync] this does NOT cancel the running full sync -- the student
     * wants this unit now, but they also still want the rest to finish. The two
     * therefore overlap, and the only thing that must never happen is two
     * writers on one filename. That is handled by [claims]: every batch takes
     * an exclusive claim on each slug before touching it and only works on the
     * ones it won, so an overlapping sync and ensureUnit partition the slugs
     * between them rather than duplicating any. Neither ever waits on the other.
     *
     * It also never wipes: an audioVersion change is the full sync's business
     * (see [syncNow]), and this simply stands down when it is asked for a
     * version that is not the one on disk.
     */
    fun ensureUnit(context: Context, unitId: String, wanted: Set<String>, version: String) {
        val app = context.applicationContext
        synchronized(unitJobs) {
            val running = unitJobs[unitId]
            if (running != null && running.isActive) return
            unitJobs[unitId] = scope.launch {
                init(app)
                runCatching { ensureUnitNow(wanted, version) }
                    .onFailure {
                        if (it !is CancellationException) {
                            Log.w(TAG, "[audio] unit $unitId prefetch failed: ${it.message}")
                        }
                    }
            }
        }
    }

    private suspend fun ensureUnitNow(wanted: Set<String>, version: String) {
        val v = version.ifBlank { "1" }
        // Asked for audio the device does not have installed. Fetching it here
        // would race the wipe the full sync is about to do, and the full sync
        // will fetch these same slugs anyway.
        if (v != audioVersion) return

        val epoch = versionEpoch.get()
        val work = wanted.asSequence()
            .filter { it.isNotBlank() && SAFE_SLUG.matches(it) }
            .filter { it !in bundled && it !in downloaded }
            .filter { claims.add(it) }
            .toList()
        if (work.isEmpty()) return

        if (!dir.exists()) dir.mkdirs()
        try {
            // No progress reporting: Settings shows the full sync's batch, and a
            // 40-clip unit prefetch overwriting that counter would make the
            // library download look like it had restarted.
            downloadBatch(work, v, epoch, null)
        } finally {
            work.forEach { claims.remove(it) }
        }
    }

    private suspend fun syncNow(wanted: Set<String>, version: String) {
        val v = version.ifBlank { "1" }

        // An audioVersion bump means the publisher REPLACED clips at the same
        // paths. Everything already downloaded is therefore the old recording
        // and has to go; the bundled .ogg assets are a different pipeline and
        // are left alone. The new version is persisted BEFORE the re-download
        // so a kill mid-batch does not delete the same files a second time --
        // the missing ones are simply picked up on the next launch.
        if (v != audioVersion) {
            synchronized(fileGate) {
                runCatching { dir.listFiles()?.forEach { it.delete() } }
                downloaded.clear()
                audioVersion = v
                versionEpoch.incrementAndGet()
            }
            persistVersion(v)
            // Packs are published with the audio they slice. The set we cached
            // belongs to the recordings we just deleted, and slicing it would
            // file the old audio under the new version's names.
            invalidatePacks()
        }
        val epoch = versionEpoch.get()

        val missing = wanted.asSequence()
            .filter { it.isNotBlank() && SAFE_SLUG.matches(it) }
            .filter { it !in bundled && it !in downloaded }
            .toList()

        // Whatever an ensureUnit batch already claimed is ITS work. Excluded
        // from the total as well as the loop, so done + failed still reaches
        // total and the Settings line still finishes at 100%.
        val work = missing.filter { claims.add(it) }

        _progress.value = AudioProgress(done = 0, total = work.size, failed = 0)
        if (work.isEmpty()) return

        Log.i(TAG, "[audio] fetching ${work.size} clip(s) at audioVersion $v")
        if (!dir.exists()) dir.mkdirs()

        try {
            val (done, failed) = downloadBatch(work, v, epoch) { d, f ->
                _progress.value = AudioProgress(d, work.size, f)
            }
            _progress.value = AudioProgress(done, work.size, failed)
            if (failed > 0) {
                // Not fatal and not retried in a loop: a clip that failed is
                // simply still missing next launch, and the next sync picks it up.
                Log.w(TAG, "[audio] $failed clip(s) failed; will retry next launch")
            }
        } finally {
            work.forEach { claims.remove(it) }
        }
    }

    /**
     * Fetch [slugs], packs first and one-by-one for the rest. Returns
     * (done, failed); together they always add up to slugs.size.
     *
     * [epoch] is the caller's audioVersion generation -- see [versionEpoch].
     */
    private suspend fun downloadBatch(
        slugs: List<String>,
        v: String,
        epoch: Int,
        onProgress: ((done: Int, failed: Int) -> Unit)?
    ): Pair<Int, Int> {
        val suffix = ContentRepository.audioSuffix(v)
        val done = AtomicInteger(0)
        val failed = AtomicInteger(0)

        var perClip: List<String> = slugs

        val index = packIndexFor(v)
        if (index != null) {
            val wanted = slugs.toHashSet()
            val plan = planPacks(index, slugs)
            // Written from several workers, read only after they have joined.
            val leftover = Collections.synchronizedList(ArrayList<String>(plan.leftover))

            if (plan.packIds.isNotEmpty()) {
                Log.i(
                    TAG,
                    "[audio] ${plan.packIds.size} pack(s) cover ${slugs.size - plan.leftover.size} clip(s)"
                )
                val cursor = AtomicInteger(0)
                coroutineScope {
                    repeat(minOf(CONCURRENCY, plan.packIds.size)) {
                        launch(Dispatchers.IO) {
                            while (true) {
                                ensureActive()
                                val i = cursor.getAndIncrement()
                                if (i >= plan.packIds.size) return@launch
                                val id = plan.packIds[i]
                                val pack = index.packs[id] ?: continue
                                val covered = pack.clips.keys.filter { it in wanted }
                                val filed = runCatching { fetchPack(pack, covered, suffix, epoch) }
                                    .onFailure { e ->
                                        if (e !is CancellationException) {
                                            Log.w(TAG, "[audio] pack $id failed: ${e.message}")
                                        }
                                    }
                                    .getOrNull()
                                if (filed == null) {
                                    // One bad pack must not lose the words it
                                    // covered -- hand them back to the per-clip
                                    // path rather than reporting them failed.
                                    leftover.addAll(covered)
                                } else {
                                    done.addAndGet(filed.size)
                                    covered.forEach { if (it !in filed) leftover.add(it) }
                                }
                                onProgress?.invoke(done.get(), failed.get())
                            }
                        }
                    }
                }
            }
            perClip = ArrayList(leftover)
        }

        // Whatever packs did not cover, fetch the old way.
        val singles = perClip
        if (singles.isNotEmpty()) {
            val cursor = AtomicInteger(0)
            coroutineScope {
                repeat(minOf(CONCURRENCY, singles.size)) {
                    launch(Dispatchers.IO) {
                        while (true) {
                            ensureActive()
                            val i = cursor.getAndIncrement()
                            if (i >= singles.size) return@launch
                            val slug = singles[i]
                            val ok = fetchClip(
                                ContentRepository.BASE_URL + "audio/" + slug + ".m4a" + suffix,
                                File(dir, "$slug.m4a"),
                                epoch
                            )
                            if (ok) {
                                downloaded.add(slug)
                                done.incrementAndGet()
                            } else {
                                failed.incrementAndGet()
                            }
                            onProgress?.invoke(done.get(), failed.get())
                        }
                    }
                }
            }
        }

        return done.get() to failed.get()
    }

    // ---- planning (faithful port of js/audio.js planPacks) ----------------

    /**
     * Work out which packs to fetch for a set of wanted slugs.
     *
     * Greedy set cover: take the pack that covers the most still-wanted clips,
     * and on a tie take the SMALLER one. That one tiebreak is what makes this do
     * the right thing at both ends without a special case -- asking for one unit
     * picks that unit's 120 KB pack rather than its book's 2.5 MB one (both
     * cover it fully), while asking for a whole book picks the book pack (it
     * covers far more than any single unit pack).
     *
     * A candidate must also clear [MIN_PACK_GAIN] and [MAX_BYTES_PER_NEW_CLIP];
     * slugs no eligible pack covers fall out as leftover and are fetched one at
     * a time, which is exactly what they are worth.
     */
    private fun planPacks(index: PackIndex, wantedSlugs: Collection<String>): Plan {
        // LinkedHashSet/LinkedHashMap throughout, so a tie on BOTH gain and
        // bytes resolves the same way it does in the browser.
        val want = LinkedHashSet(wantedSlugs)
        val chosen = ArrayList<String>()

        while (want.isNotEmpty()) {
            val gain = LinkedHashMap<String, Int>()
            for (slug in want) {
                val ids = packBySlug[slug] ?: continue
                for (id in ids) gain[id] = (gain[id] ?: 0) + 1
            }
            var best: String? = null
            var bestGain = 0
            var bestBytes = Long.MAX_VALUE
            for ((id, g) in gain) {
                val b = index.packs[id]?.bytes ?: 0L
                // Screened BEFORE the comparison, not after: a wasteful pack
                // that wins on gain would otherwise shut out the thrifty ones
                // behind it and take the whole round with it.
                if (b > MAX_BYTES_PER_NEW_CLIP * g) continue
                if (g > bestGain || (g == bestGain && b < bestBytes)) {
                    best = id
                    bestGain = g
                    bestBytes = b
                }
            }
            val pick = best ?: break
            if (bestGain < MIN_PACK_GAIN) break
            chosen.add(pick)
            index.packs[pick]?.clips?.keys?.forEach { want.remove(it) }
        }
        return Plan(chosen, want)
    }

    private fun buildReverseMap(index: PackIndex): Map<String, List<String>> {
        val m = HashMap<String, MutableList<String>>(4096)
        for ((id, entry) in index.packs) {
            for (slug in entry.clips.keys) m.getOrPut(slug) { ArrayList(2) }.add(id)
        }
        return m
    }

    // ---- pack index ------------------------------------------------------

    /**
     * The pack index for [v], or null when this publish has no packs, the
     * network is unreachable, or the index does not belong to [v].
     *
     * Under a mutex so a full sync and a unit prefetch starting together fetch
     * and parse it once, not twice.
     */
    private suspend fun packIndexFor(v: String): PackIndex? = packMutex.withLock {
        packIndex?.let { if (packVersion == v) return@withLock it }
        if (packMissForVersion == v) return@withLock null

        // Not remembered as a miss: a publish with no packs today may have them
        // after the next content update, and re-checking this costs nothing.
        val rel = ContentRepository.audioPacksUrl() ?: return@withLock null
        if (!safeRelUrl(rel)) return@withLock null

        // A cached index built for other audio is not merely stale, it is
        // actively wrong, so it is dropped here rather than trusted and the
        // publisher's current one is fetched instead.
        val fromDisk = runCatching {
            if (packsFile.isFile) parsePacks(packsFile.readText()) else null
        }.getOrNull()?.takeIf { it.audioVersion.ifBlank { "1" } == v }

        val resolved = fromDisk ?: fetchPackIndex(rel, v) ?: return@withLock null

        packIndex = resolved
        packVersion = v
        packBySlug = buildReverseMap(resolved)
        Log.i(TAG, "[audio] pack index: ${resolved.packs.size} pack(s) at audioVersion $v")
        resolved
    }

    private fun fetchPackIndex(rel: String, v: String): PackIndex? {
        // A failed fetch is NOT remembered: it is usually a lift or a dead
        // classroom wifi, and one such moment must not cost the whole process
        // its packs. The two rejections below are decisions about the file
        // itself, so those do latch -- re-fetching cannot change the answer.
        val text = runCatching { fetchText(ContentRepository.BASE_URL + rel, PACK_TIMEOUT_MS) }
            .onFailure { Log.w(TAG, "[audio] pack index unavailable: ${it.message}") }
            .getOrNull() ?: return null
        val parsed = parsePacks(text)
        if (parsed == null) {
            Log.w(TAG, "[audio] pack index failed validation; using per-clip downloads")
            packMissForVersion = v
            return null
        }
        // Slicing packs built for different recordings would file the wrong
        // bytes under every clip name -- silence, or worse, the wrong word --
        // and nothing downstream could tell. Refusing costs one slow sync.
        val theirs = parsed.audioVersion.ifBlank { "1" }
        if (theirs != v) {
            Log.w(TAG, "[audio] pack index is for audioVersion $theirs but content is $v; using per-clip downloads")
            packMissForVersion = v
            return null
        }
        runCatching { writeAtomic(packsFile, packsTmp, text) }
            .onFailure { Log.w(TAG, "[audio] could not cache pack index: ${it.message}") }
        return parsed
    }

    private suspend fun invalidatePacks() = packMutex.withLock {
        packIndex = null
        packVersion = null
        packBySlug = emptyMap()
        packMissForVersion = null
    }

    /** Port of content.js validatePacks, plus the byte count this port relies on
     *  to detect a truncated download. Returns null for anything unusable. */
    private fun parsePacks(text: String): PackIndex? = runCatching {
        val p = json.decodeFromString(PackIndex.serializer(), text)
        if (p.packs.isEmpty()) return@runCatching null
        // Both of these describe the slicing contract itself. A future format
        // or a different container would still parse into this shape and would
        // still be sliced -- into files that are named .m4a and are not.
        if (p.version != 1) return@runCatching null
        if (p.ext.isNotBlank() && p.ext != ".m4a") return@runCatching null
        for (entry in p.packs.values) {
            // Keeps a manifest we did not write from pointing pack downloads at
            // an arbitrary path; everything we fetch stays under the site's
            // audio/ directory.
            if (!entry.url.startsWith("audio/") || entry.url.contains("..")) return@runCatching null
            if (entry.bytes <= 0L) return@runCatching null
        }
        p
    }.getOrNull()

    /** The manifest is remote text and audioPacksUrl is pasted onto BASE_URL, so
     *  refuse anything that could aim the fetch at another origin. Re-checked
     *  here as well as in ContentRepository.audioPacksUrl(): this is the object
     *  that actually opens the connection, and it should not have to trust that
     *  every caller upstream did the check. */
    private fun safeRelUrl(rel: String): Boolean =
        rel.startsWith("content/") && !rel.contains("://") && !rel.contains("..")

    // ---- fetching --------------------------------------------------------

    /**
     * Fetch one pack and file every wanted clip it carries as a normal
     * per-clip .m4a. Returns the slugs actually written; the caller hands the
     * rest back to the per-clip path. Throws only for a pack-level failure.
     *
     * The body goes to a FILE, never to a ByteArray: the largest pack is ~2.6 MB
     * and holding that plus its slices on a tight phone is exactly the kind of
     * allocation that gets a background coroutine killed. RandomAccessFile then
     * cuts one ~5 KB slice at a time.
     */
    private fun fetchPack(pack: PackEntry, wanted: List<String>, suffix: String, epoch: Int): Set<String> {
        val tmp = File(dir, "pack." + System.nanoTime() + ".tmp")
        try {
            val conn = URL(ContentRepository.BASE_URL + pack.url + suffix).openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = PACK_TIMEOUT_MS
            conn.readTimeout = PACK_TIMEOUT_MS
            conn.useCaches = false
            try {
                val code = conn.responseCode
                if (code !in 200..299) throw IOException("HTTP $code")
                conn.inputStream.use { input ->
                    tmp.outputStream().buffered(64 * 1024).use { out -> input.copyTo(out) }
                }
            } finally {
                runCatching { conn.disconnect() }
            }

            // The only integrity check available. A truncated body or a proxy's
            // error page would otherwise be sliced into hundreds of unplayable
            // files, each of which looks downloaded and is never retried.
            val len = tmp.length()
            if (len != pack.bytes) throw IOException("pack is $len bytes, expected ${pack.bytes}")

            val filed = HashSet<String>()
            RandomAccessFile(tmp, "r").use { raf ->
                for (slug in wanted) {
                    if (!SAFE_SLUG.matches(slug)) continue
                    val span = pack.clips[slug] ?: continue
                    if (span.size < 2) continue
                    val off = span[0]
                    val size = span[1]
                    // index/pack mismatch, or an index asking for an absurd
                    // allocation. Either way this slug falls back to its own file.
                    if (off < 0L || size <= 0L || size > MAX_CLIP_BYTES || off + size > len) continue
                    val bytes = ByteArray(size.toInt())
                    raf.seek(off)
                    raf.readFully(bytes)
                    if (writeClip(slug, bytes, epoch)) {
                        downloaded.add(slug)
                        filed.add(slug)
                    }
                }
            }
            return filed
        } finally {
            // Multi-megabyte scratch: gone as soon as the slices are out, not
            // left for the next launch's sweep.
            runCatching { tmp.delete() }
        }
    }

    private fun writeClip(slug: String, bytes: ByteArray, epoch: Int): Boolean {
        val target = File(dir, "$slug.m4a")
        val tmp = File(dir, "$slug.m4a." + System.nanoTime() + ".tmp")
        return runCatching {
            tmp.outputStream().use { it.write(bytes) }
            if (!commit(tmp, target, epoch)) throw IOException("stale or rename failed")
            true
        }.getOrElse {
            runCatching { tmp.delete() }
            false
        }
    }

    private fun fetchClip(url: String, target: File, epoch: Int): Boolean {
        // Attempt-unique so two workers can never share a scratch file, and so a
        // leftover .tmp from a killed process is never mistaken for this one's.
        val tmp = File(target.parentFile, target.name + "." + System.nanoTime() + ".tmp")
        return runCatching {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = CLIP_TIMEOUT_MS
            conn.readTimeout = CLIP_TIMEOUT_MS
            conn.useCaches = false
            try {
                val code = conn.responseCode
                if (code !in 200..299) throw IOException("HTTP $code")
                conn.inputStream.use { input ->
                    tmp.outputStream().use { out -> input.copyTo(out) }
                }
            } finally {
                runCatching { conn.disconnect() }
            }
            // A truncated or empty body would make MediaPlayer fail on every
            // future tap, which is worse than having no clip at all.
            if (tmp.length() <= 0L) throw IOException("empty body")
            if (!commit(tmp, target, epoch)) throw IOException("stale or rename failed")
            true
        }.getOrElse {
            runCatching { tmp.delete() }
            false
        }
    }

    /**
     * Publish one finished clip. Taken under the same lock as the audioVersion
     * wipe so the two cannot interleave: either the rename lands before the wipe
     * lists the directory (and the wipe removes it, and the sync that did the
     * wiping re-fetches it), or it lands after and the epoch check refuses it.
     * There is no order in which stale audio survives under a fresh version.
     */
    private fun commit(tmp: File, target: File, epoch: Int): Boolean = synchronized(fileGate) {
        if (versionEpoch.get() != epoch) return@synchronized false
        if (target.exists()) target.delete()
        tmp.renameTo(target)
    }

    private fun fetchText(url: String, timeoutMs: Int): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = timeoutMs
        conn.readTimeout = timeoutMs
        // Same belt and braces as ContentRepository.fetchText: a pack index held
        // by a CDN or a school proxy could describe packs that no longer exist.
        conn.useCaches = false
        conn.setRequestProperty("Cache-Control", "no-store, no-cache, max-age=0")
        conn.setRequestProperty("Pragma", "no-cache")
        conn.setRequestProperty("Accept", "application/json")
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("HTTP $code for $url")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            runCatching { conn.disconnect() }
        }
    }

    private fun writeAtomic(target: File, tmp: File, text: String) {
        tmp.writeText(text)
        if (target.exists()) target.delete()
        if (!tmp.renameTo(target)) {
            tmp.delete()
            throw IOException("could not rename ${tmp.name} -> ${target.name}")
        }
    }

    private fun persistVersion(v: String) {
        if (!started) return
        runCatching {
            writeAtomic(stateFile, stateTmp, json.encodeToString(AudioState.serializer(), AudioState(v)))
        }.onFailure { Log.w(TAG, "[audio] could not persist audioVersion: ${it.message}") }
    }
}
