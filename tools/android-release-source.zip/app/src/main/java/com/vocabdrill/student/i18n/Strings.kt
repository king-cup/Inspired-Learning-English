package com.vocabdrill.student.i18n

import androidx.compose.runtime.staticCompositionLocalOf

enum class Lang(val code: String, val label: String) {
    EN("en", "English"),
    ZH("zh", "中文");

    companion object {
        fun of(code: String?) = entries.firstOrNull { it.code == code } ?: EN
    }
}

/**
 * In-app translation, deliberately NOT Android resource folders: the app has no
 * AppCompat, and the language switch has to override the device locale rather
 * than follow it.
 *
 * Book and unit names are never translated -- they are the publishers' English
 * titles and stay English in both interfaces.
 */
class Strings(private val table: Map<String, String>) {
    operator fun get(key: String): String = table[key] ?: EN_TABLE[key] ?: key
    fun f(key: String, vararg args: Any): String =
        try { String.format(get(key), *args) } catch (e: Exception) { get(key) }
}

val LocalStrings = staticCompositionLocalOf { Strings(EN_TABLE) }

/** The active language, for the few places that need to branch on it rather
 *  than look up a key -- part-of-speech expansion above all. */
val LocalLang = staticCompositionLocalOf { Lang.EN }

fun stringsFor(lang: Lang) = Strings(if (lang == Lang.ZH) ZH_TABLE else EN_TABLE)

/** Keys present in English but missing from Chinese. Empty is the only good answer. */
fun missingTranslations(): Set<String> = EN_TABLE.keys - ZH_TABLE.keys

private val EN_TABLE = mapOf(
    // --- app ---------------------------------------------------------------
    "app.title" to "Inspired English Vocab App",
    "app.kicker" to "student edition · works offline",
    "common.back" to "← Back",
    "common.done" to "Done",
    "common.cancel" to "Cancel",
    "common.continue" to "Continue",
    "common.start" to "Start",
    "common.save" to "Save",
    "common.of" to "of",

    // --- onboarding --------------------------------------------------------
    "onboard.kicker" to "welcome",
    "onboard.title" to "Before you start",
    "onboard.nameLabel" to "What is your name?",
    "onboard.nameHint" to "Your first name",
    "onboard.nameHelp" to "Your teacher will see this name if you show them your progress.",
    "onboard.langLabel" to "Choose your language",
    "onboard.langHelp" to "You can change this later in Settings.",
    "onboard.begin" to "Start learning",
    "onboard.needName" to "Please enter your name first.",

    // --- library -----------------------------------------------------------
    "lib.listType" to "List type",
    "lib.book" to "Book",
    "lib.group" to "Group",
    "lib.units" to "Units",
    "lib.complete" to "%d / %d complete",
    "lib.known" to "%d/%d known",
    "lib.best" to "best %d%%",
    "lib.settings" to "Settings",
    "lib.empty" to "No word lists found",
    "lib.hello" to "Hello, %s",

    // --- unit --------------------------------------------------------------
    "unit.notFound" to "Unit not found",
    "unit.words" to "%d words",
    "unit.lastUsed" to "last %s",
    "unit.notStarted" to "not started",
    "unit.record" to "Your record",
    "unit.knownOf" to "%d / %d known",
    "unit.bestTest" to "Best test",
    "unit.lastTest" to "Last test",
    "unit.testsDone" to "Tests done",
    "unit.cardRuns" to "Card runs",
    "unit.reset" to "Reset this unit",
    "unit.resetAsk" to "Reset this unit?",
    "unit.resetBody" to "This clears everything you have marked for %s. Other units are not touched.",
    "unit.missed" to "Words you keep missing",
    "unit.missedNone" to "Nothing yet — keep practising",
    "unit.missedTimes" to "wrong %d×",
    "unit.history" to "Test history",
    "unit.historyNone" to "No tests yet",
    "unit.attempt" to "Attempt %d",
    "unit.pass" to "PASS",
    "unit.fail" to "FAIL",
    "unit.retestTag" to "retest",

    // --- modes -------------------------------------------------------------
    "mode.study" to "Study",
    "mode.studyCaption" to "The whole list. Tap any word to hear it said aloud.",
    "mode.practice" to "Practice",
    "mode.practiceCaption" to "Multiple choice, five at a time. You see the answer after each one.",
    "mode.cards" to "Cards",
    "mode.cardsCaption" to "Swipe right if you know it, left if you don't. Tap the card to flip it.",
    "mode.test" to "Test",
    "mode.testCaption" to "No answers until the end. You need %d%% to pass.",

    // --- study -------------------------------------------------------------
    "study.find" to "Find",
    "study.wordList" to "Word list",
    "study.shown" to "%d shown",
    "study.example" to "Example",
    "study.same" to "Same meaning",
    "study.opposite" to "Opposite",
    "study.noExample" to "No example for this word yet",
    "study.tapToHear" to "tap a word to hear it",

    // --- cards -------------------------------------------------------------
    "cards.tapToFlip" to "Tap to flip",
    "cards.sayIt" to "▶  Say it",
    "cards.dontKnow" to "✗  Don't know",
    "cards.know" to "✓  I know it",
    "cards.flip" to "↻  Flip",
    "cards.hint" to "Swipe left = don't know · Swipe right = know · Tap to flip",
    "cards.finished" to "Cards finished",
    "cards.knownOf" to "%d of %d known",
    "cards.stillToLearn" to "Still to learn",
    "cards.drillMissed" to "Drill the %d I missed",
    "cards.drillMissedCaption" to "Only the words you swiped left.",
    "cards.again" to "Shuffle and go again",
    "cards.againCaption" to "The whole list, new order.",
    "cards.allKnown" to "Every word known",
    "cards.empty" to "This list is empty",
    "cards.retry" to "Cards · retry",

    // --- practice ----------------------------------------------------------
    "practice.tooShort" to "This list is too short to test",
    "practice.q" to "Q %d / %d",
    "practice.miss" to "Miss %d / %d",
    "practice.fixing" to "Practice · fixing misses",
    "practice.meaningQ" to "What does this word mean?",
    "practice.recallQ" to "Which word means this?",
    "practice.gapQ" to "Which word fills the gap?",
    "practice.tagMeaning" to "meaning",
    "practice.tagRecall" to "recall",
    "practice.tagContext" to "in context",
    "practice.correct" to "Correct",
    "practice.notQuite" to "Not quite",
    "practice.comesBack" to "This one comes back at the end.",
    "practice.checkpoint" to "Checkpoint",
    "practice.roundDone" to "Round done",
    "practice.allCorrect" to "All correct",
    "practice.gotOf" to "%d of %d",
    "practice.answered" to "%d answered",
    "practice.firstTime" to "%d / %d first time",
    "practice.progress" to "Progress",
    "practice.nothingLeft" to "Nothing left to fix",
    "practice.stillToGet" to "%d still to get right",
    "practice.retestMissed" to "Retest the %d I missed",
    "practice.seeResult" to "See the result",
    "practice.keepGoing" to "Keep going",
    "practice.complete" to "Practice complete",
    "practice.everyCorrect" to "Every word answered correctly",
    "practice.extraTries" to "You needed %d extra tries to clear the ones you missed.",
    "practice.straightThrough" to "Straight through, no retries.",
    "practice.again" to "Practise again",
    "practice.againCaption" to "Same list, questions reshuffled.",

    // --- test --------------------------------------------------------------
    "test.setup" to "Set up your test",
    "test.howMany" to "How many questions?",
    "test.ten" to "10 questions",
    "test.twenty" to "20 questions",
    "test.all" to "All %d words",
    "test.lengthHelp" to "You need %d%% to pass. You will not see any answers until you finish.",
    "test.begin" to "Start the test",
    "test.q" to "Question %d of %d",
    "test.answered" to "%d answered",
    "test.noAnswersYet" to "No answers until you finish",
    "test.finish" to "Complete test",
    "test.finishAsk" to "Finish and see your score?",
    "test.finishBody" to "You have answered %d of %d. Unanswered questions count as wrong.",
    "test.result" to "Test result",
    "test.passedMsg" to "Congratulations %s, you passed!",
    "test.failedMsg" to "You failed %s, try harder next time!",
    "test.scoreOf" to "%d / %d correct",
    "test.gotWrong" to "Words you got wrong",
    "test.allRight" to "You got every word right",
    "test.retestWrong" to "Retest the %d I got wrong",
    "test.retestCaption" to "Only the words you missed.",
    "test.takeAgain" to "Take the test again",
    "test.takeAgainCaption" to "New questions from the whole unit.",
    "test.retestTitle" to "Test · retest",

    // --- settings ----------------------------------------------------------
    "set.title" to "Settings",
    "set.kicker" to "your app, your way",
    "set.name" to "Your name",
    "set.nameChange" to "Change name",
    "set.language" to "Language",
    "set.display" to "Display",
    "set.invert" to "Invert colours",
    "set.invertHelp" to "White becomes black. Right stays green, wrong stays red.",
    "set.cards" to "Cards",
    "set.reverse" to "Show Chinese first",
    "set.reverseHelp" to "The card starts on the Chinese side and you recall the English word.",
    "set.on" to "On",
    "set.off" to "Off",
    "set.audio" to "Pronunciation",
    "set.audioClips" to "Built-in recordings",
    "set.audioTts" to "Your phone's voice",
    "set.audioNone" to "Not available on this phone",
    "set.about" to "About",
    "set.version" to "Version %s",

    // --- audio warning -----------------------------------------------------
    "audio.noEngine" to "No speech engine on this phone",
    "audio.noEngineBody" to "Tapping a word will be silent. Install a text-to-speech engine in Settings → Accessibility, or ask your teacher for the version with built-in audio.",

    // --- v1.02: session recovery -------------------------------------------
    "session.resumeTitle" to "Carry on where you stopped?",
    "session.resumeBody" to "You have an unfinished %s in this unit.",
    "session.resume" to "Carry on",
    "session.startOver" to "Start over",
    "session.leaveTitle" to "Leave this %s?",
    "session.leaveBody" to "Your answers so far will be saved.",
    "session.keepGoing" to "Keep going",
    "session.leave" to "Leave",
    "session.cards" to "card deck",
    "session.practice" to "practice run",
    "session.test" to "test",

    // --- v1.02: honest practice progress -----------------------------------
    "practice.firstPass" to "%d / %d first pass",
    "practice.retriesDone" to "%d retries",

    // --- v1.02: continue where you left off --------------------------------
    "lib.continueKick" to "pick up where you left off",
    "lib.continue" to "Continue %s",

    // --- v1.02: study disclosure -------------------------------------------
    "study.details" to "DETAILS",
    "study.hide" to "HIDE",

    // --- v1.02: backup / restore / report ----------------------------------
    "set.data" to "Progress & backup",
    "set.dataHelp" to "Uninstalling the app deletes everything it remembers. A backup file is the only way to move your progress to another phone.",
    "set.backup" to "Back up progress",
    "set.restore" to "Restore progress",
    "set.shareReport" to "Share progress report",
    "set.lastBackup" to "Last backup: %s",
    "set.neverBackedUp" to "Never backed up",
    "backup.saved" to "Backup saved.",
    "backup.failed" to "Could not save the backup.",
    "backup.restoreTitle" to "Replace all progress?",
    "backup.restoreBody" to "Everything this phone remembers will be replaced by the backup file. This cannot be undone.",
    "backup.replace" to "Replace",
    "backup.restored" to "Progress restored.",
    "backup.invalid" to "That file is not a progress backup.",
    "report.title" to "PROGRESS REPORT",
    "report.student" to "Student",
    "report.generated" to "Generated",
    "report.unitsStarted" to "Units started",
    "report.unitsComplete" to "Units passed",
    "report.wordsKnown" to "Words known",
    "report.topMissed" to "Words most often missed",
    "report.bestScores" to "Best test scores",
    "report.none" to "(none yet)",

    // --- v1.02: retryable load error ---------------------------------------
    "error.loadTitle" to "Could not load the word lists",
    "error.loadBody" to "Check your connection and try again. If this keeps happening, tell your teacher.",
    "common.retry" to "Try again",

    // --- v1.03: remote vocabulary ------------------------------------------
    "set.vocab" to "Vocabulary",
    "set.checkUpdates" to "Check for new words",
    "set.contentVersion" to "Word list: %s",
    "set.contentBundled" to "Word list: built in",
    "set.lastChecked" to "Last checked: %s",
    "set.neverChecked" to "Not checked yet",
    "set.audioDownloaded" to "%d downloaded recordings",
    "update.checking" to "Checking…",
    "update.upToDate" to "Your words are up to date.",
    "update.updated" to "New words added.",
    "update.downloaded" to "New words ready.",
    "update.failed" to "Could not check right now.",
    "update.vocabReady" to "New vocabulary ready.",
    "update.reload" to "RELOAD",
    "update.dismiss" to "Dismiss",

    // --- accessibility ------------------------------------------------------
    "a11y.speak" to "Play pronunciation",
    "a11y.prev" to "Previous question",
    "a11y.next" to "Next question",
    "a11y.expand" to "Show details",
    "a11y.collapse" to "Hide details",
    "a11y.progress" to "Progress",

)

private val ZH_TABLE = mapOf(
    // --- app ---------------------------------------------------------------
    "app.title" to "因思博睿英语学习",
    "app.kicker" to "学生版 · 可离线使用",
    "common.back" to "← 返回",
    "common.done" to "完成",
    "common.cancel" to "取消",
    "common.continue" to "继续",
    "common.start" to "开始",
    "common.save" to "保存",
    "common.of" to "/",

    // --- onboarding --------------------------------------------------------
    "onboard.kicker" to "欢迎",
    "onboard.title" to "开始之前",
    "onboard.nameLabel" to "你叫什么名字？",
    "onboard.nameHint" to "你的名字",
    "onboard.nameHelp" to "如果你给老师看你的学习记录，老师会看到这个名字。",
    "onboard.langLabel" to "选择语言",
    "onboard.langHelp" to "以后可以在「设置」里更改。",
    "onboard.begin" to "开始学习",
    "onboard.needName" to "请先输入你的名字。",

    // --- library -----------------------------------------------------------
    "lib.listType" to "列表类型",
    "lib.book" to "教材",
    "lib.group" to "分组",
    "lib.units" to "单元",
    "lib.complete" to "已完成 %d / %d",
    "lib.known" to "已掌握 %d/%d",
    "lib.best" to "最好成绩 %d%%",
    "lib.settings" to "设置",
    "lib.empty" to "没有找到词表",
    "lib.hello" to "你好，%s",

    // --- unit --------------------------------------------------------------
    "unit.notFound" to "找不到该单元",
    "unit.words" to "%d 个单词",
    "unit.lastUsed" to "上次 %s",
    "unit.notStarted" to "尚未开始",
    "unit.record" to "你的记录",
    "unit.knownOf" to "已掌握 %d / %d",
    "unit.bestTest" to "最好成绩",
    "unit.lastTest" to "上次成绩",
    "unit.testsDone" to "测验次数",
    "unit.cardRuns" to "卡片次数",
    "unit.reset" to "清除本单元记录",
    "unit.resetAsk" to "清除本单元记录？",
    "unit.resetBody" to "这将清除你在 %s 的所有记录。其他单元不受影响。",
    "unit.missed" to "经常做错的单词",
    "unit.missedNone" to "暂时没有 — 继续加油",
    "unit.missedTimes" to "错 %d 次",
    "unit.history" to "测验记录",
    "unit.historyNone" to "还没有测验记录",
    "unit.attempt" to "第 %d 次",
    "unit.pass" to "通过",
    "unit.fail" to "未通过",
    "unit.retestTag" to "重测",

    // --- modes -------------------------------------------------------------
    "mode.study" to "学习",
    "mode.studyCaption" to "完整词表。点击单词即可听发音。",
    "mode.practice" to "练习",
    "mode.practiceCaption" to "选择题，每五题一组。每题作答后立即看到答案。",
    "mode.cards" to "卡片",
    "mode.cardsCaption" to "认识就右滑，不认识就左滑。点击卡片翻面。",
    "mode.test" to "测验",
    "mode.testCaption" to "做完之前不显示答案。需要 %d%% 才能通过。",

    // --- study -------------------------------------------------------------
    "study.find" to "查找",
    "study.wordList" to "单词表",
    "study.shown" to "显示 %d 个",
    "study.example" to "例句",
    "study.same" to "近义词",
    "study.opposite" to "反义词",
    "study.noExample" to "这个单词还没有例句",
    "study.tapToHear" to "点击单词听发音",

    // --- cards -------------------------------------------------------------
    "cards.tapToFlip" to "点击翻面",
    "cards.sayIt" to "▶  读一遍",
    "cards.dontKnow" to "✗  不认识",
    "cards.know" to "✓  我认识",
    "cards.flip" to "↻  翻面",
    "cards.hint" to "左滑＝不认识 · 右滑＝认识 · 点击翻面",
    "cards.finished" to "卡片完成",
    "cards.knownOf" to "认识 %d / %d",
    "cards.stillToLearn" to "还需要学习",
    "cards.drillMissed" to "重练这 %d 个",
    "cards.drillMissedCaption" to "只练你左滑的单词。",
    "cards.again" to "打乱后再来一次",
    "cards.againCaption" to "完整词表，重新排序。",
    "cards.allKnown" to "全部认识",
    "cards.empty" to "这个词表是空的",
    "cards.retry" to "卡片 · 重练",

    // --- practice ----------------------------------------------------------
    "practice.tooShort" to "这个词表太短，无法测验",
    "practice.q" to "第 %d / %d 题",
    "practice.miss" to "错题 %d / %d",
    "practice.fixing" to "练习 · 订正错题",
    "practice.meaningQ" to "这个单词是什么意思？",
    "practice.recallQ" to "哪个单词是这个意思？",
    "practice.gapQ" to "哪个单词填入空格？",
    "practice.tagMeaning" to "词义",
    "practice.tagRecall" to "回忆",
    "practice.tagContext" to "语境",
    "practice.correct" to "正确",
    "practice.notQuite" to "不对",
    "practice.comesBack" to "这题最后会再出现一次。",
    "practice.checkpoint" to "阶段小结",
    "practice.roundDone" to "本组完成",
    "practice.allCorrect" to "全部正确",
    "practice.gotOf" to "答对 %d / %d",
    "practice.answered" to "已答 %d 题",
    "practice.firstTime" to "一次答对 %d / %d",
    "practice.progress" to "进度",
    "practice.nothingLeft" to "没有需要订正的了",
    "practice.stillToGet" to "还有 %d 个要答对",
    "practice.retestMissed" to "重做错的 %d 题",
    "practice.seeResult" to "查看结果",
    "practice.keepGoing" to "继续",
    "practice.complete" to "练习完成",
    "practice.everyCorrect" to "所有单词都答对了",
    "practice.extraTries" to "你多用了 %d 次机会订正错题。",
    "practice.straightThrough" to "一次通过，没有重做。",
    "practice.again" to "再练一次",
    "practice.againCaption" to "同一词表，题目重新排列。",

    // --- test --------------------------------------------------------------
    "test.setup" to "设置测验",
    "test.howMany" to "测验多少题？",
    "test.ten" to "10 题",
    "test.twenty" to "20 题",
    "test.all" to "全部 %d 个单词",
    "test.lengthHelp" to "需要 %d%% 才能通过。做完之前不会显示任何答案。",
    "test.begin" to "开始测验",
    "test.q" to "第 %d 题，共 %d 题",
    "test.answered" to "已答 %d 题",
    "test.noAnswersYet" to "做完之后才显示答案",
    "test.finish" to "交卷",
    "test.finishAsk" to "交卷并查看成绩？",
    "test.finishBody" to "你已作答 %d / %d 题。未作答的题目按错误计算。",
    "test.result" to "测验结果",
    "test.passedMsg" to "恭喜 %s，你通过了！",
    "test.failedMsg" to "%s，你没有通过，下次要更努力！",
    "test.scoreOf" to "答对 %d / %d",
    "test.gotWrong" to "做错的单词",
    "test.allRight" to "所有单词都答对了",
    "test.retestWrong" to "重测错的 %d 个",
    "test.retestCaption" to "只测你做错的单词。",
    "test.takeAgain" to "再测一次",
    "test.takeAgainCaption" to "从整个单元重新出题。",
    "test.retestTitle" to "测验 · 重测",

    // --- settings ----------------------------------------------------------
    "set.title" to "设置",
    "set.kicker" to "按你的习惯来",
    "set.name" to "你的名字",
    "set.nameChange" to "修改名字",
    "set.language" to "语言",
    "set.display" to "显示",
    "set.invert" to "反色显示",
    "set.invertHelp" to "白底变黑底。正确仍然是绿色，错误仍然是红色。",
    "set.cards" to "卡片",
    "set.reverse" to "先显示中文",
    "set.reverseHelp" to "卡片正面显示中文，你来回忆英文单词。",
    "set.on" to "开",
    "set.off" to "关",
    "set.audio" to "发音",
    "set.audioClips" to "内置录音",
    "set.audioTts" to "手机语音",
    "set.audioNone" to "此手机不支持",
    "set.about" to "关于",
    "set.version" to "版本 %s",

    // --- audio warning -----------------------------------------------------
    "audio.noEngine" to "此手机没有语音引擎",
    "audio.noEngineBody" to "点击单词不会有声音。可以在「设置 → 无障碍」中安装语音引擎，或者向老师索取内置录音的版本。",

    // --- v1.02: session recovery -------------------------------------------
    "session.resumeTitle" to "接着上次继续吗？",
    "session.resumeBody" to "这个单元里有一次没做完的%s。",
    "session.resume" to "继续",
    "session.startOver" to "重新开始",
    "session.leaveTitle" to "要离开这个%s吗？",
    "session.leaveBody" to "你已经作答的部分会被保存。",
    "session.keepGoing" to "继续做",
    "session.leave" to "离开",
    "session.cards" to "卡片练习",
    "session.practice" to "练习",
    "session.test" to "测验",

    // --- v1.02: honest practice progress -----------------------------------
    "practice.firstPass" to "第一遍 %d / %d",
    "practice.retriesDone" to "重做 %d 次",

    // --- v1.02: continue where you left off --------------------------------
    "lib.continueKick" to "接着上次继续",
    "lib.continue" to "继续 %s",

    // --- v1.02: study disclosure -------------------------------------------
    "study.details" to "详情",
    "study.hide" to "收起",

    // --- v1.02: backup / restore / report ----------------------------------
    "set.data" to "学习记录与备份",
    "set.dataHelp" to "卸载应用会删除所有记录。备份文件是把学习进度转到另一台手机的唯一方法。",
    "set.backup" to "备份学习记录",
    "set.restore" to "恢复学习记录",
    "set.shareReport" to "分享学习报告",
    "set.lastBackup" to "上次备份：%s",
    "set.neverBackedUp" to "还没有备份过",
    "backup.saved" to "备份已保存。",
    "backup.failed" to "备份保存失败。",
    "backup.restoreTitle" to "替换全部学习记录？",
    "backup.restoreBody" to "这台手机上的所有记录都会被备份文件替换，且无法撤销。",
    "backup.replace" to "替换",
    "backup.restored" to "学习记录已恢复。",
    "backup.invalid" to "这个文件不是学习记录备份。",
    "report.title" to "学习报告",
    "report.student" to "学生",
    "report.generated" to "生成时间",
    "report.unitsStarted" to "已开始的单元",
    "report.unitsComplete" to "已通过的单元",
    "report.wordsKnown" to "已掌握的单词",
    "report.topMissed" to "最常做错的单词",
    "report.bestScores" to "最好的测验成绩",
    "report.none" to "（暂无）",

    // --- v1.02: retryable load error ---------------------------------------
    "error.loadTitle" to "无法加载单词表",
    "error.loadBody" to "请检查网络后重试。如果一直这样，请告诉老师。",
    "common.retry" to "重试",

    // --- v1.03: remote vocabulary ------------------------------------------
    "set.vocab" to "单词表",
    "set.checkUpdates" to "检查新单词",
    "set.contentVersion" to "单词表：%s",
    "set.contentBundled" to "单词表：内置",
    "set.lastChecked" to "上次检查：%s",
    "set.neverChecked" to "还没有检查过",
    "set.audioDownloaded" to "已下载 %d 条录音",
    "update.checking" to "正在检查……",
    "update.upToDate" to "单词表已是最新。",
    "update.updated" to "已添加新单词。",
    "update.downloaded" to "新单词已准备好。",
    "update.failed" to "暂时无法检查。",
    "update.vocabReady" to "新单词已准备好。",
    "update.reload" to "重新载入",
    "update.dismiss" to "忽略",

    // --- accessibility ------------------------------------------------------
    "a11y.speak" to "播放读音",
    "a11y.prev" to "上一题",
    "a11y.next" to "下一题",
    "a11y.expand" to "展开详情",
    "a11y.collapse" to "收起详情",
    "a11y.progress" to "进度",

)

/**
 * Part of speech, expanded for display ONLY.
 *
 * The raw abbreviation stays in Entry.p and therefore in every progress key --
 * expanding it into a key would fork every record a student already has.
 * Unknown values are humanised rather than shown as a bare abbreviation.
 */
private val POS_EN = mapOf(
    "n" to "Noun", "v" to "Verb", "adj" to "Adjective", "adv" to "Adverb",
    "phr" to "Phrase", "phr.v" to "Phrasal verb", "prep" to "Preposition",
    "conj" to "Conjunction", "det" to "Determiner", "pron" to "Pronoun",
    "num" to "Number", "modal" to "Modal verb", "prefix" to "Prefix",
    "suffix" to "Suffix", "abbr" to "Abbreviation", "int" to "Interjection",
    "exclam" to "Exclamation", "art" to "Article", "aux" to "Auxiliary verb",
    "idiom" to "Idiom"
)

private val POS_ZH = mapOf(
    "n" to "名词", "v" to "动词", "adj" to "形容词", "adv" to "副词",
    "phr" to "短语", "phr.v" to "短语动词", "prep" to "介词",
    "conj" to "连词", "det" to "限定词", "pron" to "代词",
    "num" to "数词", "modal" to "情态动词", "prefix" to "前缀",
    "suffix" to "后缀", "abbr" to "缩写", "int" to "感叹词",
    "exclam" to "感叹词", "art" to "冠词", "aux" to "助动词",
    "idiom" to "习语"
)

/** Empty in, empty out -- the caller renders no tag at all rather than a blank box. */
fun displayPos(raw: String, lang: Lang): String {
    val k = raw.trim().lowercase()
    if (k.isEmpty()) return ""
    val table = if (lang == Lang.ZH) POS_ZH else POS_EN
    table[k]?.let { return it }
    POS_EN[k]?.let { return it }
    return k.replaceFirstChar { it.uppercaseChar() }
}
