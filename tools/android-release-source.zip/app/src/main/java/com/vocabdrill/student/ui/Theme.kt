package com.vocabdrill.student.ui

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.vocabdrill.student.audio.Speaker

const val APP_VERSION = "1.04"

/**
 * The palette, held as SNAPSHOT STATE rather than constants.
 *
 * Every screen already reads Ink.ink / Ink.paper, so making these observable
 * means the invert-colours setting recomposes the whole app with no changes at
 * any call site.
 *
 * Note the dark values are NOT a naive inversion. #e9f5ec is a near-white
 * green; on black it reads as a grey smear. Dark mode gets its own pair so
 * right still reads green and wrong still reads red at proper contrast.
 */
object Ink {
    var ink by mutableStateOf(Color(0xFF000000))
        private set
    var paper by mutableStateOf(Color(0xFFFFFFFF))
        private set
    var hover by mutableStateOf(Color(0xFFE8E8E8))
        private set
    var rule by mutableStateOf(Color(0xFF999999))
        private set
    var shade by mutableStateOf(Color(0xFFEEEEEE))
        private set
    var rightFill by mutableStateOf(Color(0xFFE9F5EC))
        private set
    var rightEdge by mutableStateOf(Color(0xFF1C7A3E))
        private set
    var wrongFill by mutableStateOf(Color(0xFFFDECEB))
        private set
    var wrongEdge by mutableStateOf(Color(0xFFB3261E))
        private set

    var inverted by mutableStateOf(false)
        private set

    fun apply(dark: Boolean) {
        inverted = dark
        if (dark) {
            ink = Color(0xFFFFFFFF); paper = Color(0xFF000000)
            hover = Color(0xFF2A2A2A); rule = Color(0xFF666666); shade = Color(0xFF1A1A1A)
            rightFill = Color(0xFF10301C); rightEdge = Color(0xFF4ADE80)
            wrongFill = Color(0xFF3A1412); wrongEdge = Color(0xFFFF7A70)
        } else {
            ink = Color(0xFF000000); paper = Color(0xFFFFFFFF)
            hover = Color(0xFFE8E8E8); rule = Color(0xFF999999); shade = Color(0xFFEEEEEE)
            rightFill = Color(0xFFE9F5EC); rightEdge = Color(0xFF1C7A3E)
            wrongFill = Color(0xFFFDECEB); wrongEdge = Color(0xFFB3261E)
        }
    }
}

val Mono = FontFamily.Monospace
val Serif = FontFamily.Serif

/** Courier-ish, uppercase, wide letter spacing -- the label voice of the paper. */
fun kicker(size: Int = 9, spacing: Double = 3.0, weight: FontWeight = FontWeight.Normal) =
    TextStyle(fontFamily = Mono, fontSize = size.sp, letterSpacing = spacing.sp, fontWeight = weight)

private val CJK = Regex("[\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uF900-\\uFAFF\\u3000-\\u303F\\uFF00-\\uFFEF]")

fun hasCjk(s: String): Boolean = CJK.containsMatchIn(s)

/**
 * The kicker style, but safe for Chinese.
 *
 * Monospace has no Han glyphs, so CJK falls back to the system face anyway --
 * what actually shows is the letter spacing, which pushes Chinese characters
 * apart into something that reads as broken rather than as a label. Han also
 * has no case, so the uppercase half of the kicker voice is simply absent and
 * weight has to carry it instead.
 */
fun kickerFor(
    text: String,
    size: Int = 9,
    spacing: Double = 3.0,
    weight: FontWeight = FontWeight.Normal
): TextStyle = if (hasCjk(text)) {
    TextStyle(
        fontFamily = Serif,
        fontSize = size.sp,
        letterSpacing = 0.sp,
        fontWeight = if (weight == FontWeight.Normal) FontWeight.Bold else weight
    )
} else kicker(size, spacing, weight)

/** Nothing in this design is ever rounded, popups included. */
private val Square = RoundedCornerShape(0.dp)
private val SquareShapes = Shapes(
    extraSmall = Square, small = Square, medium = Square,
    large = Square, extraLarge = Square
)

private val DrillTypography = Typography(
    bodyLarge = TextStyle(fontFamily = Serif, fontSize = 15.sp),
    bodyMedium = TextStyle(fontFamily = Serif, fontSize = 14.sp),
    labelLarge = kicker(11, 1.5, FontWeight.Bold)
)

val LocalSpeaker = staticCompositionLocalOf<Speaker?> { null }

@Composable
fun DrillTheme(content: @Composable () -> Unit) {
    val scheme = lightColorScheme(
        primary = Ink.ink, onPrimary = Ink.paper,
        secondary = Ink.ink, onSecondary = Ink.paper,
        background = Ink.paper, onBackground = Ink.ink,
        surface = Ink.paper, onSurface = Ink.ink,
        surfaceVariant = Ink.paper, onSurfaceVariant = Ink.ink,
        error = Ink.wrongEdge, outline = Ink.ink
    )

    val view = LocalContext.current as? Activity
    SideEffect {
        view?.window?.let { w ->
            // The status bar is the black title bar's neighbour; in inverted
            // mode it has to swap with it or the top of the screen looks broken.
            w.statusBarColor = (if (Ink.inverted) Ink.paper else Ink.ink).toArgb()
            w.navigationBarColor = Ink.paper.toArgb()
            WindowCompat.getInsetsController(w, w.decorView).apply {
                isAppearanceLightStatusBars = Ink.inverted
                isAppearanceLightNavigationBars = !Ink.inverted
            }
        }
    }

    MaterialTheme(colorScheme = scheme, typography = DrillTypography, shapes = SquareShapes, content = content)
}
