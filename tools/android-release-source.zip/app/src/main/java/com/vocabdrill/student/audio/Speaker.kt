package com.vocabdrill.student.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import com.vocabdrill.student.data.AudioCache
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.util.Locale

/**
 * Pronunciation, in order of preference:
 *   1. a pre-generated clip bundled at assets/audio/<slug>.ogg
 *   2. a clip downloaded to filesDir/audio/<slug>.m4a for a word that arrived
 *      with a remote content update and so was never in this APK (AudioCache)
 *   3. the device's own TextToSpeech engine, en-US
 *
 * Step 3 is not reliable on every handset sold in China -- plenty ship with no
 * Google TTS engine at all -- which is why steps 1 and 2 exist. [status] reports
 * what is actually available so the UI can say so instead of failing silently.
 *
 * BUNDLED covers both local sources on purpose: to a student "there is a real
 * recording for this word" is one fact, not two, and splitting it would force
 * every existing caller of [status] to learn a new case.
 */
class Speaker(private val context: Context) {

    enum class Status { STARTING, BUNDLED, SYSTEM_TTS, UNAVAILABLE }

    private val _status = MutableStateFlow(Status.STARTING)
    val status: StateFlow<Status> = _status

    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private var player: MediaPlayer? = null

    private val clips: Set<String> by lazy {
        runCatching {
            context.assets.list("audio")?.filter { it.endsWith(".ogg") }?.toSet() ?: emptySet()
        }.getOrDefault(emptySet())
    }

    /** Downloaded clips live outside the APK, so this is a plain directory. */
    private val downloadedDir: File by lazy { File(context.filesDir, "audio") }

    /** True when SOME real recording is available, bundled or downloaded. */
    val hasBundledAudio: Boolean
        get() = clips.isNotEmpty() || AudioCache.downloadedCount() > 0

    init {
        if (clips.isNotEmpty()) _status.value = Status.BUNDLED
        tts = TextToSpeech(context) { result ->
            ttsReady = result == TextToSpeech.SUCCESS && applyLanguage()
            if (_status.value != Status.BUNDLED) {
                _status.value = if (ttsReady) Status.SYSTEM_TTS else Status.UNAVAILABLE
            }
        }
    }

    private fun applyLanguage(): Boolean {
        val engine = tts ?: return false
        val code = runCatching { engine.setLanguage(Locale.US) }.getOrNull() ?: return false
        return code != TextToSpeech.LANG_MISSING_DATA && code != TextToSpeech.LANG_NOT_SUPPORTED
    }

    fun speak(word: String) {
        val clean = word.trim()
        if (clean.isEmpty()) return
        val stem = slug(clean)
        if (clips.contains("$stem.ogg") && playAsset("audio/$stem.ogg")) return
        // Checked on disk rather than against AudioCache's in-memory set: this
        // must work even if the content loader has not run yet this process.
        val file = File(downloadedDir, "$stem.m4a")
        if (file.isFile && file.length() > 0L && playFile(file)) return
        speakWithTts(clean)
    }

    private fun playAsset(path: String): Boolean = runCatching {
        stop()
        val afd = context.assets.openFd(path)
        val mp = newPlayer()
        mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
        afd.close()
        mp.prepare()
        mp.start()
        player = mp
        true
    }.getOrDefault(false)

    /** A clip pulled down by AudioCache. Same lifecycle as [playAsset]: the
     *  completion listener releases it, and stop()/release() still own it. */
    private fun playFile(file: File): Boolean = runCatching {
        stop()
        val mp = newPlayer()
        mp.setDataSource(file.absolutePath)
        mp.prepare()
        mp.start()
        player = mp
        true
    }.getOrDefault(false)

    private fun newPlayer(): MediaPlayer {
        val mp = MediaPlayer()
        mp.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        mp.setOnCompletionListener { it.release(); if (player === it) player = null }
        // A half-downloaded or wrong-codec file must not leave a dead player
        // wired up as the current one: stop() cannot release a player in the
        // error state, so it is released here instead and the reference dropped.
        mp.setOnErrorListener { p, _, _ ->
            runCatching { p.release() }
            if (player === p) player = null
            true
        }
        return mp
    }

    private fun speakWithTts(word: String) {
        val engine = tts ?: return
        // The init callback can lose the race on some devices; re-check once here.
        if (!ttsReady) {
            ttsReady = applyLanguage()
            if (ttsReady && _status.value != Status.BUNDLED) _status.value = Status.SYSTEM_TTS
        }
        if (!ttsReady) return
        runCatching {
            engine.stop()
            engine.speak(word, TextToSpeech.QUEUE_FLUSH, null, "vd-" + word.hashCode())
        }
    }

    fun stop() {
        runCatching { player?.stop(); player?.release() }
        player = null
        runCatching { tts?.stop() }
    }

    fun release() {
        stop()
        runCatching { tts?.shutdown() }
        tts = null
    }

    companion object {
        /** Must match slug() in tools/generate_audio.py exactly. */
        fun slug(word: String): String {
            val sb = StringBuilder()
            var lastUnderscore = false
            for (ch in word.trim().lowercase()) {
                if (ch in 'a'..'z' || ch in '0'..'9') {
                    sb.append(ch); lastUnderscore = false
                } else if (!lastUnderscore) {
                    sb.append('_'); lastUnderscore = true
                }
            }
            return sb.toString().trim('_').ifEmpty { "x" }
        }
    }
}
