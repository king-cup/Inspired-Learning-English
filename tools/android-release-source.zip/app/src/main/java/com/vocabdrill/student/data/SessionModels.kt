package com.vocabdrill.student.data

import kotlinx.serialization.Serializable

/**
 * The persisted shape of an unfinished run, one class per mode.
 *
 * Everything references words by their Entry.key, never by position in the
 * unit. A vocabulary update can reorder or extend a unit between the moment a
 * student is interrupted and the moment they come back; keys survive that,
 * indices do not. A key that no longer exists is simply dropped on restore.
 */
@Serializable
data class PracticeSession(
    val mainKeys: List<String> = emptyList(),
    val runKeys: List<String> = emptyList(),
    val pos: Int = 0,
    val isRetry: Boolean = false,
    val retryPass: Int = 0,
    val firstPassRight: Int = 0,
    val answeredTotal: Int = 0,
    val firstPassAnswered: Int = 0,
    val wrongKeys: List<String> = emptyList(),
    val roundMarks: List<Boolean> = emptyList(),
    val showBreak: Boolean = false
)

@Serializable
data class TestSession(
    val questionKeys: List<String> = emptyList(),
    val answers: List<Int> = emptyList(),
    val pos: Int = 0,
    val isRetest: Boolean = false
)

@Serializable
data class CardsSession(
    val orderKeys: List<String> = emptyList(),
    val index: Int = 0,
    val knownKeys: List<String> = emptyList(),
    val missedKeys: List<String> = emptyList(),
    val onlyKeys: List<String>? = null
)
