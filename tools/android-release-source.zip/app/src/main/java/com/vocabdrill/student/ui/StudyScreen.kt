package com.vocabdrill.student.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import com.vocabdrill.student.data.Entry
import com.vocabdrill.student.data.ProgressStore
import com.vocabdrill.student.data.VocabRepository
import com.vocabdrill.student.i18n.LocalStrings

@Composable
fun StudyScreen(unitId: String, onBack: () -> Unit) {
    val unit = remember(unitId) { VocabRepository.resolve(unitId) }
    val t = LocalStrings.current
    val speaker = LocalSpeaker.current
    val progress by ProgressStore.state.collectAsState()
    var query by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(-1) }

    val words = unit?.words.orEmpty()
    val shown = remember(words, query) {
        if (query.isBlank()) words
        else words.filter {
            it.w.contains(query, true) || it.c.contains(query) || it.p.contains(query, true)
        }
    }

    Column(Modifier.fillMaxSize().background(Ink.paper).padding(14.dp)) {
        TopBar(t["common.back"], t["mode.study"], onBack)

        Spacer(Modifier.height(12.dp))
        PaperHeader(
            kickerText = (unit?.groupName ?: "").ifBlank { "word list" },
            title = unit?.label ?: unitId,
            leftFoot = t.f("unit.words", words.size),
            rightFoot = t["study.tapToHear"]
        )

        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth().border(2.dp, Ink.ink),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                t["study.find"].uppercase(),
                style = kicker(9, 2.0),
                color = Ink.paper,
                modifier = Modifier.background(Ink.ink).padding(horizontal = 11.dp, vertical = 11.dp)
            )
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = TextStyle(fontFamily = Mono, fontSize = 14.sp, color = Ink.ink),
                modifier = Modifier.weight(1f).padding(horizontal = 11.dp)
            )
            if (query.isNotEmpty()) {
                HardButton("×", fontSize = 13, padH = 12, padV = 10) { query = "" }
            }
        }

        Spacer(Modifier.height(12.dp))
        Column(Modifier.weight(1f).fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(t["study.wordList"], right = t.f("study.shown", shown.size))
            LazyColumn(Modifier.fillMaxWidth()) {
                itemsIndexed(shown, key = { i, e -> e.key + "#" + i }) { i, e ->
                    val known = progress.stat(unitId, e).known
                    WordRow(
                        number = words.indexOf(e) + 1,
                        entry = e,
                        known = known,
                        expanded = expanded == i,
                        onSpeak = { speaker?.speak(e.w) },
                        onToggle = { expanded = if (expanded == i) -1 else i }
                    )
                    HRule(1.0)
                }
            }
        }
    }
}

@Composable
private fun WordRow(
    number: Int,
    entry: Entry,
    known: Boolean,
    expanded: Boolean,
    onSpeak: () -> Unit,
    onToggle: () -> Unit
) {
    val t = LocalStrings.current
    Column(Modifier.fillMaxWidth().background(if (known) Ink.rightFill else Ink.paper)) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                number.toString().padStart(2, '0'),
                style = kicker(10, 1.0, FontWeight.Bold),
                modifier = Modifier.width(38.dp).padding(start = 11.dp)
            )
            // The word itself is the speak target.
            Column(
                Modifier
                    .weight(1f)
                    .clickable { onSpeak() }
                    .padding(vertical = 11.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        entry.w,
                        fontFamily = Serif,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Ink.ink
                    )
                    Spacer(Modifier.width(8.dp))
                    SpeakerGlyph(18)
                    if (entry.p.isNotBlank()) {
                        Spacer(Modifier.width(8.dp))
                        PosTag(entry.p)
                    }
                }
                Text(
                    entry.c,
                    fontFamily = Serif,
                    fontSize = 14.sp,
                    color = Ink.ink,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
            // A word, not a glyph: "+" tested badly -- students did not know it
            // opened the sentence and synonyms, so most never opened it at all.
            Box(
                Modifier
                    .heightIn(min = 48.dp)
                    .widthIn(min = 60.dp)
                    .clickable { onToggle() }
                    .semantics {
                        contentDescription = if (expanded) t["a11y.collapse"] else t["a11y.expand"]
                    }
                    .padding(horizontal = 10.dp, vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (expanded) t["study.hide"] else t["study.details"],
                    style = kicker(11, 1.0, FontWeight.Bold),
                    color = Ink.ink
                )
            }
        }
        AnimatedVisibility(visible = expanded) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Ink.shade)
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                if (entry.e.isNotBlank()) {
                    Text(t["study.example"].uppercase(), style = kicker(8, 2.5), color = Ink.ink)
                    Spacer(Modifier.height(3.dp))
                    Text(
                        highlight(entry.e, entry.w),
                        fontFamily = Serif,
                        fontSize = 14.sp,
                        lineHeight = 21.sp,
                        color = Ink.ink
                    )
                }
                if (entry.s.isNotBlank() || entry.a.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        if (entry.s.isNotBlank()) Column(Modifier.weight(1f)) {
                            Text(t["study.same"].uppercase(), style = kicker(8, 2.0), color = Ink.ink)
                            Text(entry.s, fontFamily = Serif, fontSize = 14.sp, color = Ink.ink)
                        }
                        if (entry.a.isNotBlank()) Column(Modifier.weight(1f)) {
                            Text(t["study.opposite"].uppercase(), style = kicker(8, 2.0), color = Ink.ink)
                            Text(entry.a, fontFamily = Serif, fontSize = 14.sp, color = Ink.ink)
                        }
                    }
                }
            }
        }
    }
}

/** Bold the target word wherever it appears in its own example sentence. */
private fun highlight(sentence: String, word: String) = buildAnnotatedString {
    val stem = word.trim().lowercase()
    if (stem.isEmpty()) { append(sentence); return@buildAnnotatedString }
    val lower = sentence.lowercase()
    var i = 0
    while (i < sentence.length) {
        val hit = lower.indexOf(stem, i)
        if (hit < 0) { append(sentence.substring(i)); break }
        append(sentence.substring(i, hit))
        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
            append(sentence.substring(hit, hit + stem.length))
        }
        i = hit + stem.length
    }
}
