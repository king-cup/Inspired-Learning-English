package com.vocabdrill.student.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vocabdrill.student.data.ContentRepository
import com.vocabdrill.student.data.ProfileStore
import com.vocabdrill.student.data.VocabRepository
import com.vocabdrill.student.i18n.Lang
import com.vocabdrill.student.i18n.LocalLang
import com.vocabdrill.student.i18n.LocalStrings
import com.vocabdrill.student.i18n.stringsFor

sealed interface Screen {
    data object Library : Screen
    data object Settings : Screen
    data class UnitHome(val unitId: String) : Screen
    data class Cards(val unitId: String, val onlyKeys: List<String>? = null) : Screen
    data class Study(val unitId: String) : Screen
    data class Practice(val unitId: String) : Screen
    data class Test(val unitId: String) : Screen
}

@Composable
fun AppRoot() {
    val context = LocalContext.current
    var loaded by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    val profile by ProfileStore.state.collectAsState()

    // The palette is snapshot state, so flipping this recomposes the whole app.
    LaunchedEffect(profile.inverted) { Ink.apply(profile.inverted) }

    val strings = remember(profile.lang) { stringsFor(Lang.of(profile.lang)) }

    // Bumped by the Try again button to re-run the loader.
    var loadAttempt by remember { mutableStateOf(0) }

    LaunchedEffect(loadAttempt) {
        loadError = null
        // ContentRepository.load already moves to Dispatchers.IO, and it never
        // throws for a network problem -- only if even the bundled assets are
        // unreadable, which is a broken install rather than a bad connection.
        val result = runCatching {
            val res = ContentRepository.load(context)
            VocabRepository.adopt(res.bundle)
            res
        }
        result.onSuccess { loaded = true }.onFailure { loadError = it.message ?: it.toString() }
    }

    val lang = remember(profile.lang) { Lang.of(profile.lang) }

    CompositionLocalProvider(LocalStrings provides strings, LocalLang provides lang) {
        when {
            loadError != null -> Box(
                Modifier.fillMaxSize().background(Ink.paper), contentAlignment = Alignment.Center
            ) {
                // The exception text goes to logcat, not to a fourteen-year-old.
                LaunchedEffect(loadError) {
                    android.util.Log.w("VocabDrill", "load failed: " + loadError)
                }
                Column(Modifier.padding(24.dp)) {
                    Text(
                        strings["error.loadTitle"].uppercase(),
                        style = kickerFor(strings["error.loadTitle"], 12, 2.0, FontWeight.Bold),
                        color = Ink.ink
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        strings["error.loadBody"],
                        fontFamily = Serif, fontSize = 14.sp, lineHeight = 21.sp, color = Ink.ink
                    )
                    Spacer(Modifier.height(18.dp))
                    HardButton(
                        strings["common.retry"],
                        Modifier.fillMaxWidth().border(2.dp, Ink.ink),
                        fontSize = 12
                    ) { loaded = false; loadAttempt += 1 }
                }
            }

            !loaded -> Box(
                Modifier.fillMaxSize().background(Ink.paper), contentAlignment = Alignment.Center
            ) {
                Text("…", style = kicker(20, 3.0), color = Ink.ink)
            }

            // Shown exactly once. After this the app always knows their name.
            !profile.onboarded -> OnboardingScreen { name, lang ->
                ProfileStore.completeOnboarding(name, lang.code)
            }

            else -> Navigator()
        }
    }
}

/** A drill is on screen: never swap the word list under it. */
private fun Screen.isSession(): Boolean =
    this is Screen.Cards || this is Screen.Practice || this is Screen.Test

@Composable
private fun Navigator() {
    val context = LocalContext.current
    val t = LocalStrings.current
    val stack = remember { mutableStateListOf<Screen>(Screen.Library) }
    var selectedType by rememberSaveable { mutableStateOf(0) }
    var selectedGroup by rememberSaveable { mutableStateOf(0) }
    var barDismissed by remember { mutableStateOf(false) }
    var pendingTick by remember { mutableStateOf(0) }

    // Navigating OUT of a drill is the safe moment to swap in new words.
    // Navigating IN with an update waiting raises the bar instead, so the
    // student knows and can choose -- it never interrupts them.
    LaunchedEffect(stack.size, stack.lastOrNull(), pendingTick) {
        if (!stack.last().isSession() && ContentRepository.hasPending()) {
            ContentRepository.applyPendingIfReady(context)?.let {
                VocabRepository.adopt(it.bundle)
                barDismissed = false
                pendingTick += 1
            }
        }
    }

    BackHandler(enabled = stack.size > 1) { stack.removeAt(stack.lastIndex) }

    val push: (Screen) -> Unit = { stack.add(it) }
    val pop: () -> Unit = { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    val popToUnit: () -> Unit = {
        while (stack.size > 1 && stack.last() !is Screen.UnitHome) stack.removeAt(stack.lastIndex)
    }

    val showBar = !barDismissed && ContentRepository.hasPending() && stack.last().isSession()

    Column(Modifier.fillMaxSize()) {
    Box(Modifier.weight(1f)) {
    when (val s = stack.last()) {
        is Screen.Library -> LibraryScreen(
            typeIndex = selectedType,
            groupIndex = selectedGroup,
            onType = { selectedType = it; selectedGroup = 0 },
            onGroup = { selectedGroup = it },
            onOpenUnit = { push(Screen.UnitHome(it)) },
            onSettings = { push(Screen.Settings) }
        )

        is Screen.Settings -> SettingsScreen(onBack = pop)

        is Screen.UnitHome -> UnitScreen(
            unitId = s.unitId,
            onBack = pop,
            onStudy = { push(Screen.Study(s.unitId)) },
            onPractice = { push(Screen.Practice(s.unitId)) },
            onCards = { push(Screen.Cards(s.unitId)) },
            onTest = { push(Screen.Test(s.unitId)) }
        )

        is Screen.Cards -> FlashcardsScreen(
            unitId = s.unitId,
            onlyKeys = s.onlyKeys,
            onBack = pop,
            onDrillMissed = { keys ->
                stack.removeAt(stack.lastIndex)
                push(Screen.Cards(s.unitId, keys))
            },
            onDone = popToUnit
        )

        is Screen.Study -> StudyScreen(unitId = s.unitId, onBack = pop)
        is Screen.Practice -> LearnScreen(unitId = s.unitId, onBack = pop, onDone = popToUnit)
        is Screen.Test -> TestScreen(unitId = s.unitId, onBack = pop, onDone = popToUnit)
    }
    }
    if (showBar) {
        UpdateBar(
            message = t["update.vocabReady"],
            actionLabel = t["update.reload"],
            dismissLabel = t["update.dismiss"],
            onAction = {
                // Back to the Library: leaving the drill is what applies it.
                while (stack.size > 1) stack.removeAt(stack.lastIndex)
                barDismissed = false
            },
            onDismiss = { barDismissed = true }
        )
    }
    }
}
