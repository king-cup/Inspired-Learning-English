package com.vocabdrill.student.data

import kotlinx.serialization.Serializable

@Serializable
data class WordStat(
    val known: Boolean = false,
    val right: Int = 0,
    val wrong: Int = 0,
    val seen: Int = 0,
    val lastMs: Long = 0L
)

/** One completed test. Length is stored because the student picks it, so a
 *  10-question 80% and a 60-question 80% are not the same achievement. */
@Serializable
data class TestRun(
    val at: Long = 0L,
    val attempt: Int = 1,
    val correct: Int = 0,
    val total: Int = 0,
    val retest: Boolean = false
) {
    val pct: Int get() = if (total == 0) 0 else (correct * 100) / total
    val passed: Boolean get() = pct >= PASS_PCT
}

const val PASS_PCT = 80

@Serializable
data class UnitStat(
    val bestPct: Int = 0,
    val lastPct: Int = 0,
    val lastMs: Long = 0L,
    val learnRuns: Int = 0,
    val cardRuns: Int = 0,
    val tests: List<TestRun> = emptyList()
)

/**
 * Everything the app remembers. Words are keyed by
 *   "<unitId>|<word lowercased>|<pos lowercased>"
 * deliberately NOT by list position, so re-issuing a unit with the words in a
 * different order cannot silently re-point a student's history.
 */
@Serializable
data class Progress(
    val version: Int = 1,
    val words: Map<String, WordStat> = emptyMap(),
    val units: Map<String, UnitStat> = emptyMap()
) {
    fun wordKey(unitId: String, e: Entry) = unitId + "|" + e.key
    fun stat(unitId: String, e: Entry): WordStat = words[wordKey(unitId, e)] ?: WordStat()
    fun unit(unitId: String): UnitStat = units[unitId] ?: UnitStat()

    fun knownCount(unitId: String, entries: List<Entry>): Int =
        entries.count { stat(unitId, it).known }
}
