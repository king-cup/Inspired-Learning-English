package com.vocabdrill.student.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vocabdrill.student.data.ProfileStore
import com.vocabdrill.student.data.ProgressStore
import com.vocabdrill.student.data.VocabRepository
import com.vocabdrill.student.i18n.LocalStrings

@Composable
fun LibraryScreen(
    typeIndex: Int,
    groupIndex: Int,
    onType: (Int) -> Unit,
    onGroup: (Int) -> Unit,
    onOpenUnit: (String) -> Unit,
    onSettings: () -> Unit
) {
    val t = LocalStrings.current
    val types = remember { VocabRepository.types() }
    val progress by ProgressStore.state.collectAsState()
    val profile by ProfileStore.state.collectAsState()

    if (types.isEmpty()) {
        Box(Modifier.fillMaxSize().background(Ink.paper), contentAlignment = Alignment.Center) {
            Text(t["lib.empty"].uppercase(), style = kicker(11, 3.0), color = Ink.ink)
        }
        return
    }

    val tb = types[typeIndex.coerceIn(0, types.lastIndex)]
    val g = tb.groups[groupIndex.coerceIn(0, tb.groups.lastIndex)]

    Column(Modifier.fillMaxSize().background(Ink.paper)) {

        Column(Modifier.padding(start = 14.dp, end = 14.dp, top = 14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                HardButton(
                    "⚙  " + t["lib.settings"],
                    Modifier.border(1.5.dp, Ink.ink),
                    fontSize = 10, padH = 11, padV = 6,
                    onClick = onSettings
                )
            }
            Spacer(Modifier.height(10.dp))
            PaperHeader(
                kickerText = t["app.kicker"],
                title = t["app.title"],
                // The unit/word totals are gone; the student's own name is more
                // use to them than a corpus statistic.
                leftFoot = if (profile.name.isNotBlank()) t.f("lib.hello", profile.name) else "",
                rightFoot = "v$APP_VERSION"
            )
        }

        // ---- carry on -----------------------------------------------------
        // Most sessions are a student returning to the unit they were in
        // yesterday. Two dropdowns is the wrong price for the commonest action.
        val last = remember(profile.lastUnit) {
            profile.lastUnit.takeIf { it.isNotBlank() }?.let { VocabRepository.resolve(it) }
        }
        if (last != null) {
            Column(Modifier.padding(horizontal = 14.dp).padding(top = 12.dp)) {
                BlockButton(
                    label = t.f("lib.continue", "${last.groupName} ${last.label}".trim()),
                    caption = t["lib.continueKick"],
                    modifier = Modifier.fillMaxWidth().border(2.dp, Ink.ink)
                ) { onOpenUnit(last.id) }
            }
        }

        // ---- selectors: dropdowns, not tab strips -------------------------
        Column(Modifier.padding(horizontal = 14.dp).padding(top = 12.dp).border(2.dp, Ink.ink)) {
            PaperDropdown(
                label = t["lib.listType"],
                value = tb.type,
                options = types.map { it.type },
                onPick = { onType(it) }
            )
            HRule()
            PaperDropdown(
                label = if (tb.groupLabel.equals("Book", true)) t["lib.book"] else t["lib.group"],
                value = g.name,
                options = tb.groups.map { it.name },
                onPick = { onGroup(it) }
            )
        }

        // ---- units --------------------------------------------------------
        Column(
            Modifier
                .padding(horizontal = 14.dp)
                .padding(top = 12.dp, bottom = 12.dp)
                .weight(1f)
                .fillMaxWidth()
                .border(2.dp, Ink.ink)
        ) {
            val doneUnits = g.units.count { u ->
                val ws = VocabRepository.wordsFor(u.id)
                ws.isNotEmpty() && progress.knownCount(u.id, ws) == ws.size
            }
            BarLabel(t["lib.units"], right = t.f("lib.complete", doneUnits, g.units.size))
            LazyColumn(Modifier.fillMaxWidth()) {
                items(g.units, key = { it.id }) { u ->
                    val words = VocabRepository.wordsFor(u.id)
                    val known = progress.knownCount(u.id, words)
                    val stat = progress.unit(u.id)
                    UnitRow(
                        label = u.label,
                        knownText = t.f("lib.known", known, words.size),
                        bestText = if (stat.bestPct > 0) "   ·   " + t.f("lib.best", stat.bestPct) else "",
                        fraction = if (words.isEmpty()) 0f else known.toFloat() / words.size,
                        onClick = { onOpenUnit(u.id) }
                    )
                    HRule(1.0)
                }
            }
        }
    }
}

@Composable
private fun UnitRow(
    label: String,
    knownText: String,
    bestText: String,
    fraction: Float,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 13.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            // Book and unit names are the publishers' English titles and stay
            // English in both interfaces.
            Text(label, fontFamily = Serif, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Ink.ink)
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                RuleBar(fraction, Modifier.width(120.dp), height = 10)
                Text("  $knownText$bestText", style = kicker(9, 1.0), color = Ink.ink)
            }
        }
        Text("›", fontFamily = Mono, fontSize = 20.sp, color = Ink.ink)
    }
}
