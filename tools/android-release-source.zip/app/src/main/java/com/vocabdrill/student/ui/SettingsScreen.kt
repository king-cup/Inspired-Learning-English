package com.vocabdrill.student.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vocabdrill.student.audio.Speaker
import com.vocabdrill.student.data.AudioCache
import com.vocabdrill.student.data.Backup
import com.vocabdrill.student.data.ContentRepository
import com.vocabdrill.student.data.Progress
import com.vocabdrill.student.data.ProfileStore
import com.vocabdrill.student.data.ProgressStore
import com.vocabdrill.student.data.VocabRepository
import com.vocabdrill.student.i18n.Lang
import com.vocabdrill.student.i18n.LocalStrings
import com.vocabdrill.student.i18n.Strings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val t = LocalStrings.current
    val profile by ProfileStore.state.collectAsState()
    val speaker = LocalSpeaker.current
    var editingName by remember { mutableStateOf(false) }
    var draft by remember(profile.name) { mutableStateOf(profile.name) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dateFmt = remember { SimpleDateFormat("d MMM HH:mm", Locale.UK) }

    // --- vocabulary ---------------------------------------------------------
    var checking by remember { mutableStateOf(false) }
    var updateMessage by remember { mutableStateOf<String?>(null) }
    // ContentRepository keeps its state on disk rather than in a flow, so a
    // finished check has to tell the two lines below to read it again.
    var contentTick by remember { mutableStateOf(0) }
    val activeVersion = remember(contentTick) { ContentRepository.activeVersion() }
    val lastCheckMs = remember(contentTick) { ContentRepository.lastCheckMs() }
    val audio by AudioCache.progress.collectAsState()
    // downloadedCount() is a plain counter, not state; keying it to the batch
    // progress is what makes the line climb while clips are arriving.
    val downloadedClips = remember(audio) { AudioCache.downloadedCount() }

    // --- progress & backup --------------------------------------------------
    var dataMessage by remember { mutableStateOf<String?>(null) }
    var pendingRestore by remember { mutableStateOf<Progress?>(null) }

    val backupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        // A null uri is the student backing out of the file picker, which is not
        // a failure and must not put a red message on the screen.
        if (uri != null) {
            val snapshot = ProgressStore.state.value
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        val text = Backup.export(snapshot)
                        val out = context.contentResolver.openOutputStream(uri)
                            ?: error("no output stream")
                        out.use { it.write(text.toByteArray()) }
                    }.isSuccess
                }
                if (ok) ProfileStore.markBackup(System.currentTimeMillis())
                dataMessage = if (ok) t["backup.saved"] else t["backup.failed"]
            }
        }
    }

    val restoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val parsed = withContext<Progress?>(Dispatchers.IO) {
                    runCatching {
                        val text = context.contentResolver.openInputStream(uri)
                            ?.use { it.bufferedReader().readText() }
                            ?: error("no input stream")
                        Backup.parse(text)
                    }.getOrNull()
                }
                if (parsed == null) {
                    dataMessage = t["backup.invalid"]
                } else {
                    // Nothing is written yet -- the student still has to say yes.
                    dataMessage = null
                    pendingRestore = parsed
                }
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Ink.paper)
            .verticalScroll(rememberScrollState())
            .padding(14.dp)
    ) {
        TopBar(t["common.back"], t["set.title"], onBack)

        Spacer(Modifier.height(12.dp))
        PaperHeader(
            kickerText = t["set.kicker"],
            title = t["set.title"],
            leftFoot = profile.name,
            rightFoot = t.f("set.version", APP_VERSION)
        )

        // --- name ------------------------------------------------------------
        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(t["set.name"])
            Column(Modifier.padding(13.dp)) {
                if (editingName) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .border(1.5.dp, Ink.ink)
                            .padding(horizontal = 12.dp, vertical = 13.dp)
                    ) {
                        BasicTextField(
                            value = draft,
                            onValueChange = { if (it.length <= 24) draft = it },
                            singleLine = true,
                            textStyle = TextStyle(fontFamily = Mono, fontSize = 15.sp, color = Ink.ink),
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Words,
                                imeAction = ImeAction.Done
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        HardButton(t["common.cancel"], Modifier.weight(1f).border(1.5.dp, Ink.ink), fontSize = 11) {
                            draft = profile.name; editingName = false
                        }
                        HardButton(t["common.save"], Modifier.weight(1f).border(1.5.dp, Ink.ink), fontSize = 11) {
                            if (draft.isNotBlank()) ProfileStore.setName(draft)
                            editingName = false
                        }
                    }
                } else {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text(
                            profile.name.ifBlank { "—" },
                            fontFamily = Serif,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Ink.ink,
                            modifier = Modifier.weight(1f)
                        )
                        HardButton(t["set.nameChange"], Modifier.border(1.5.dp, Ink.ink), fontSize = 10) {
                            draft = profile.name; editingName = true
                        }
                    }
                }
            }
        }

        // --- language --------------------------------------------------------
        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(t["set.language"])
            Row(Modifier.fillMaxWidth().padding(13.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Lang.entries.forEach { option ->
                    HardButton(
                        option.label,
                        Modifier.weight(1f).border(2.dp, Ink.ink),
                        selected = option.code == profile.lang,
                        fontSize = 13,
                        padV = 14,
                        onClick = { ProfileStore.setLang(option.code) }
                    )
                }
            }
        }

        // --- display ---------------------------------------------------------
        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(t["set.display"])
            ToggleRow(
                title = t["set.invert"],
                help = t["set.invertHelp"],
                checked = profile.inverted,
                onLabel = t["set.on"], offLabel = t["set.off"],
                onChange = { ProfileStore.setInverted(it) }
            )
        }

        // --- cards -----------------------------------------------------------
        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(t["set.cards"])
            ToggleRow(
                title = t["set.reverse"],
                help = t["set.reverseHelp"],
                checked = profile.cardsReversed,
                onLabel = t["set.on"], offLabel = t["set.off"],
                onChange = { ProfileStore.setCardsReversed(it) }
            )
        }

        // --- audio -----------------------------------------------------------
        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(t["set.audio"])
            val idle = remember { MutableStateFlow(Speaker.Status.STARTING) }
            val status by (speaker?.status ?: idle).collectAsState()
            val label = when {
                speaker?.hasBundledAudio == true -> t["set.audioClips"]
                status == Speaker.Status.SYSTEM_TTS -> t["set.audioTts"]
                status == Speaker.Status.UNAVAILABLE -> t["set.audioNone"]
                else -> "…"
            }
            Text(
                label,
                style = kicker(12, 1.5, FontWeight.Bold),
                color = if (status == Speaker.Status.UNAVAILABLE && speaker?.hasBundledAudio != true)
                    Ink.wrongEdge else Ink.ink,
                modifier = Modifier.padding(13.dp)
            )
        }

        // --- vocabulary (v1.03) ----------------------------------------------
        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(t["set.vocab"])
            Column(Modifier.padding(13.dp)) {
                val versionLine = activeVersion
                    ?.let { t.f("set.contentVersion", it) }
                    ?: t["set.contentBundled"]
                Text(
                    versionLine,
                    style = kickerFor(versionLine, 12, 1.5, FontWeight.Bold),
                    color = Ink.ink
                )

                val checkedLine = if (lastCheckMs > 0L)
                    t.f("set.lastChecked", dateFmt.format(Date(lastCheckMs)))
                else t["set.neverChecked"]
                Text(
                    checkedLine,
                    style = kickerFor(checkedLine, 11, 1.0),
                    color = Ink.ink.copy(alpha = 0.75f),
                    modifier = Modifier.padding(top = 4.dp)
                )

                // Recordings the APK did not ship. A batch in flight is worth
                // more to the student than the total, so it wins the line.
                val downloading = audio.total > 0 && audio.done < audio.total
                if (downloading) {
                    Text(
                        "${audio.done} / ${audio.total}",
                        style = kicker(11, 1.0, FontWeight.Bold),
                        color = Ink.ink.copy(alpha = 0.75f),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                } else if (downloadedClips > 0) {
                    val clipLine = t.f("set.audioDownloaded", downloadedClips)
                    Text(
                        clipLine,
                        style = kickerFor(clipLine, 11, 1.0),
                        color = Ink.ink.copy(alpha = 0.75f),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                Spacer(Modifier.height(12.dp))
                HardButton(
                    if (checking) t["update.checking"] else t["set.checkUpdates"],
                    Modifier.fillMaxWidth().border(1.5.dp, Ink.ink),
                    enabled = !checking,
                    fontSize = 11
                ) {
                    checking = true
                    updateMessage = null
                    scope.launch {
                        val outcome = runCatching {
                            ContentRepository.checkForUpdate(context, apply = true)
                        }.getOrElse { ContentRepository.UpdateOutcome.Failed }
                        updateMessage = when (outcome) {
                            // ContentRepository deliberately does not reach into
                            // VocabRepository, so without this the new words are
                            // on disk and active but nothing on screen shows them.
                            is ContentRepository.UpdateOutcome.Updated -> {
                                VocabRepository.adopt(outcome.content.bundle)
                                t["update.updated"]
                            }
                            is ContentRepository.UpdateOutcome.UpToDate -> t["update.upToDate"]
                            is ContentRepository.UpdateOutcome.Downloaded -> t["update.downloaded"]
                            is ContentRepository.UpdateOutcome.Failed -> t["update.failed"]
                        }
                        contentTick++
                        checking = false
                    }
                }

                updateMessage?.let { msg ->
                    Text(
                        msg,
                        style = kickerFor(msg, 11, 1.0, FontWeight.Bold),
                        color = Ink.ink,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }
            }
        }

        // --- progress & backup (v1.02-M) --------------------------------------
        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth().border(2.dp, Ink.ink)) {
            BarLabel(t["set.data"])
            Column(Modifier.padding(13.dp)) {
                Text(
                    t["set.dataHelp"],
                    fontFamily = Serif,
                    fontSize = 13.sp,
                    color = Ink.ink.copy(alpha = 0.75f)
                )

                val backupLine = if (profile.lastBackupMs > 0L)
                    t.f("set.lastBackup", dateFmt.format(Date(profile.lastBackupMs)))
                else t["set.neverBackedUp"]
                Text(
                    backupLine,
                    style = kickerFor(backupLine, 11, 1.0),
                    color = Ink.ink.copy(alpha = 0.75f),
                    modifier = Modifier.padding(top = 9.dp)
                )

                Spacer(Modifier.height(12.dp))
                HardButton(
                    t["set.backup"],
                    Modifier.fillMaxWidth().border(1.5.dp, Ink.ink),
                    fontSize = 11
                ) {
                    dataMessage = null
                    backupLauncher.launch(Backup.fileName())
                }

                Spacer(Modifier.height(8.dp))
                HardButton(
                    t["set.restore"],
                    Modifier.fillMaxWidth().border(1.5.dp, Ink.ink),
                    fontSize = 11
                ) {
                    dataMessage = null
                    // "*/*" last: some file managers hand back a backup typed as
                    // octet-stream, and refusing to even list it is worse than
                    // letting Backup.parse be the judge.
                    restoreLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                }

                Spacer(Modifier.height(8.dp))
                HardButton(
                    t["set.shareReport"],
                    Modifier.fillMaxWidth().border(1.5.dp, Ink.ink),
                    fontSize = 11
                ) {
                    dataMessage = null
                    val snapshot = ProgressStore.state.value
                    val name = profile.name
                    scope.launch {
                        val report = withContext<String?>(Dispatchers.IO) {
                            runCatching {
                                buildReport(t, name, Backup.summarise(snapshot))
                            }.getOrNull()
                        }
                        if (report == null) {
                            dataMessage = t["backup.failed"]
                        } else {
                            val send = Intent(Intent.ACTION_SEND)
                                .putExtra(Intent.EXTRA_TEXT, report)
                                .setType("text/plain")
                            runCatching { context.startActivity(Intent.createChooser(send, null)) }
                                .onFailure { dataMessage = t["backup.failed"] }
                        }
                    }
                }

                dataMessage?.let { msg ->
                    Text(
                        msg,
                        style = kickerFor(msg, 11, 1.0, FontWeight.Bold),
                        color = Ink.ink,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }
            }
        }

        Spacer(Modifier.height(30.dp))
    }

    pendingRestore?.let { restore ->
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            containerColor = Ink.paper,
            title = {
                Text(
                    t["backup.restoreTitle"],
                    style = kickerFor(t["backup.restoreTitle"], 12, 2.0, FontWeight.Bold),
                    color = Ink.ink
                )
            },
            text = {
                Text(t["backup.restoreBody"], fontFamily = Serif, fontSize = 14.sp, color = Ink.ink)
            },
            confirmButton = {
                HardButton(t["backup.replace"], fontSize = 11) {
                    ProgressStore.replaceAll(restore)
                    pendingRestore = null
                    dataMessage = t["backup.restored"]
                }
            },
            dismissButton = {
                HardButton(t["common.cancel"], fontSize = 11) { pendingRestore = null }
            }
        )
    }
}

/**
 * The plain-text report a student shows a teacher.
 *
 * Plain text on purpose: it has to survive WeChat, mail and a printout, and none
 * of those keep formatting. Every label comes from the string table so a Chinese
 * student sends their teacher a Chinese report.
 */
private fun buildReport(
    t: Strings,
    name: String,
    s: Backup.Summary,
    atMs: Long = System.currentTimeMillis()
): String {
    val b = StringBuilder()
    b.appendLine(t["report.title"])
    b.appendLine(t["report.student"] + ": " + name.ifBlank { "\u2014" })
    b.appendLine(t["report.generated"] + ": " + Backup.dateStamp(atMs))
    b.appendLine()
    b.appendLine(t["report.unitsStarted"] + ": " + s.unitsStarted)
    b.appendLine(t["report.unitsComplete"] + ": " + s.unitsComplete)
    b.appendLine(t["report.wordsKnown"] + ": " + s.wordsKnown)
    b.appendLine()
    b.appendLine(t["report.topMissed"] + ":")
    if (s.topMissed.isEmpty()) {
        b.appendLine("  " + t["report.none"])
    } else {
        for (m in s.topMissed) {
            val zh = if (m.zh.isBlank()) "" else " (" + m.zh + ")"
            b.appendLine("  " + m.word + zh + " \u2014 " + t.f("unit.missedTimes", m.wrong) + " \u2014 " + m.unitLabel)
        }
    }
    b.appendLine()
    b.appendLine(t["report.bestScores"] + ":")
    if (s.bestScores.isEmpty()) {
        b.appendLine("  " + t["report.none"])
    } else {
        for (x in s.bestScores) {
            b.appendLine("  " + x.label + " \u2014 " + x.bestPct + "% (" + t["unit.testsDone"] + ": " + x.tests + ")")
        }
    }
    return b.toString().trimEnd()
}
