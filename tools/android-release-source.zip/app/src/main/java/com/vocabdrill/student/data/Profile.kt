package com.vocabdrill.student.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File

@Serializable
data class Profile(
    val name: String = "",
    val lang: String = "en",
    val inverted: Boolean = false,
    /** Cards start on the Chinese side and the student recalls the English. */
    val cardsReversed: Boolean = false,
    val onboarded: Boolean = false,
    /** Last unit opened, for the Library's "carry on" shortcut. Independent of
     *  progress: it is a convenience, not a record, and resetting must not lose it. */
    val lastUnit: String = "",
    /** When the student last wrote a backup file. 0 = never. */
    val lastBackupMs: Long = 0L,
)

/**
 * Deliberately a SEPARATE file from progress.json: resetting a unit's records
 * must never cost a student their name and settings.
 */
object ProfileStore {

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var file: File
    private lateinit var tmp: File
    private var started = false

    private val _state = MutableStateFlow(Profile())
    val state: StateFlow<Profile> = _state

    fun init(context: Context) {
        if (started) return
        started = true
        file = File(context.filesDir, "profile.json")
        tmp = File(context.filesDir, "profile.json.tmp")
        runCatching {
            if (file.exists()) _state.value = json.decodeFromString(Profile.serializer(), file.readText())
        }
    }

    private fun update(block: (Profile) -> Profile) {
        val next = block(_state.value)
        _state.value = next
        if (!started) return
        scope.launch {
            runCatching {
                tmp.writeText(json.encodeToString(Profile.serializer(), next))
                if (file.exists()) file.delete()
                tmp.renameTo(file)
            }
        }
    }

    fun completeOnboarding(name: String, lang: String) =
        update { it.copy(name = name.trim(), lang = lang, onboarded = true) }

    fun setName(name: String) = update { it.copy(name = name.trim()) }
    fun setLang(lang: String) = update { it.copy(lang = lang) }
    fun setInverted(on: Boolean) = update { it.copy(inverted = on) }
    fun setCardsReversed(on: Boolean) = update { it.copy(cardsReversed = on) }

    fun setLastUnit(unitId: String) = update { it.copy(lastUnit = unitId) }
    fun markBackup(atMs: Long) = update { it.copy(lastBackupMs = atMs) }

    /** Never let a message read "Good job, !" */
    fun displayName(): String = _state.value.name.ifBlank { "" }
}
