package com.vocabdrill.student.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Remote published vocabulary -- the Android port of the PWA's js/content.js +
 * the loading half of js/data.js. Same publisher, same manifest, same files.
 *
 * Design guarantees, carried over verbatim from the web build:
 *  - The manifest is fetched fresh every time (no-store + cache-buster), so a
 *    new release appears on the FIRST launch after publishing.
 *  - A version's files are written to disk only after BOTH parse and validate,
 *    and the active pointer moves only after a whole version is on disk. A
 *    failed or half-finished update can never corrupt the working content.
 *  - A network failure is never fatal: the last known good version is kept, and
 *    if there has never been one, the APK's bundled assets are used.
 *
 * Where the web build used the Cache API + localStorage, this uses filesDir and
 * a single content-state.json, written tmp+rename like ProgressStore.
 */
object ContentRepository {

    /** Publisher origin. The only thing to change if the site ever moves. */
    const val BASE_URL = "https://inspiredvocab.netlify.app/"

    private const val MANIFEST_PATH = "content/manifest.json"
    private const val MANIFEST_TIMEOUT_MS = 6_000
    private const val DOWNLOAD_TIMEOUT_MS = 15_000

    private const val TAG = "VocabDrill"

    /** contentVersion becomes a directory name here, which it never was on the
     *  web (there it was only a cache key). Anything outside this charset could
     *  walk out of filesDir, so it is refused before it touches a path. */
    private val SAFE_VERSION = Regex("^[A-Za-z0-9._-]+$")

    // Lenient for our own model decoding, matching VocabRepository. Untrusted
    // remote text is parsed with [strictJson] instead -- leniency there would
    // accept unquoted tokens that JSON.parse (and therefore the PWA) rejects.
    private val json = Json { ignoreUnknownKeys = true; isLenient = true; encodeDefaults = true }
    private val strictJson = Json { ignoreUnknownKeys = true }
    private val clipListSerializer = ListSerializer(String.serializer())

    private lateinit var stateFile: File
    private lateinit var stateTmp: File
    private lateinit var contentDir: File
    private lateinit var appContext: Context
    private var started = false

    @Volatile private var state = ContentState()

    // ---- persisted model -------------------------------------------------

    @Serializable
    data class ContentManifest(
        val schemaVersion: Int = 1,
        val contentVersion: String = "",
        val vocabUrl: String = "",
        val audioIndexUrl: String = "",
        val audioVersion: String = "1",
        /** Optional, and absent from every publish before v1.04. A manifest
         *  without it is not invalid -- it just has no packs, and AudioCache
         *  falls back to fetching clips one at a time exactly as before. */
        val audioPacksUrl: String = "",
        val publishedAt: String = ""
    )

    @Serializable
    data class ContentState(
        val active: ContentManifest? = null,
        val pending: ContentManifest? = null,
        val lastCheckMs: Long = 0L
    )

    /** What load() actually produced, plus the flags the PWA's status object
     *  carries so Settings can explain what happened. */
    data class LoadResult(
        val bundle: Bundle,
        val clipSlugs: Set<String>,
        /** null means the APK's bundled assets are in use. */
        val activeVersion: String?,
        val audioVersion: String,
        val usedBundled: Boolean,
        val installedNew: Boolean,
        val appliedPending: Boolean,
        val updateAvailable: Boolean,
        val updateFailed: Boolean
    )

    sealed interface UpdateOutcome {
        /** Nothing newer to fetch. */
        data object UpToDate : UpdateOutcome
        /** Applied now; [content] is the new in-memory content, hand it to VocabRepository. */
        data class Updated(val content: LoadResult) : UpdateOutcome
        /** On disk and validated, but held back as pending because a session was active. */
        data object Downloaded : UpdateOutcome
        /** Network or validation failure. The working content is untouched. */
        data object Failed : UpdateOutcome
    }

    private data class Cached(val bundle: Bundle, val clips: List<String>)

    // ---- lifecycle -------------------------------------------------------

    fun init(context: Context) {
        if (started) return
        synchronized(this) {
            if (started) return
            appContext = context.applicationContext
            stateFile = File(appContext.filesDir, "content-state.json")
            stateTmp = File(appContext.filesDir, "content-state.json.tmp")
            contentDir = File(appContext.filesDir, "content")
            runCatching {
                if (stateFile.exists()) {
                    state = json.decodeFromString(ContentState.serializer(), stateFile.readText())
                }
            }.onFailure { Log.w(TAG, "[content] state unreadable, starting clean: ${it.message}") }
            started = true
        }
    }

    // ---- public accessors ------------------------------------------------

    /** contentVersion of the version in use, or null when running on the bundled assets. */
    fun activeVersion(): String? = state.active?.contentVersion

    fun lastCheckMs(): Long = state.lastCheckMs

    fun hasPending(): Boolean = state.pending != null

    /** Audio cache-busting version of the ACTIVE content. "1" means no suffix. */
    fun audioVersion(): String = state.active?.audioVersion?.takeIf { it.isNotBlank() } ?: "1"

    /**
     * Port of data.js audioSuffix(): version "1" adds NO query, so a student who
     * already has clips does not re-download them all. Only a real replacement
     * of existing audio files bumps this.
     */
    fun audioSuffix(version: String): String =
        if (version.isNotBlank() && version != "1") "?v=$version" else ""

    /**
     * Where the ACTIVE version's audio pack index lives, relative to [BASE_URL],
     * or null when this publish has no packs (or the app is running on the
     * bundled assets). Never required by [validateManifest]: an older publisher
     * that has never heard of packs must keep working untouched.
     *
     * The `content/` prefix is the same contract [validateManifest] enforces on
     * vocabUrl and audioIndexUrl: the published index is a version-stamped
     * content/audio-packs-<version>.json. Anything else is either the build
     * tool's local output or a manifest we should not be following, so it is
     * refused here rather than pasted onto [BASE_URL].
     */
    fun audioPacksUrl(): String? = state.active?.audioPacksUrl
        ?.takeIf { it.isNotBlank() && it.startsWith("content/") }

    // ---- validation (faithful port of js/content.js) ----------------------

    fun validateManifest(el: JsonElement?): Boolean {
        val o = el as? JsonObject ?: return false
        val sv = o["schemaVersion"] as? JsonPrimitive ?: return false
        // Must be the NUMBER 1: the PWA uses ===, so "1" as a string is a reject.
        if (sv.isString || sv.doubleOrNull != 1.0) return false
        if (!o.nonBlankString("contentVersion")) return false
        if (!o.nonBlankString("audioVersion")) return false
        for (key in arrayOf("vocabUrl", "audioIndexUrl")) {
            val p = o[key] as? JsonPrimitive ?: return false
            if (!p.isString || p.content.isBlank()) return false
            if (!p.content.startsWith("content/")) return false
        }
        return true
    }

    fun validateVocab(el: JsonElement?): Boolean {
        val o = el as? JsonObject ?: return false
        if (o["types"] !is JsonArray) return false
        val data = o["data"] as? JsonObject ?: return false
        var any = false
        for (list in data.values) {
            val arr = list as? JsonArray ?: return false
            for (e in arr) {
                val entry = e as? JsonObject ?: return false
                val w = entry["w"] as? JsonPrimitive ?: return false
                if (!w.isString || w.content.isBlank()) return false
            }
            if (arr.isNotEmpty()) any = true
        }
        // A vocab file with no words at all would leave the student with an
        // empty library; the bundled assets are strictly better than that.
        return any
    }

    fun validateAudioIndex(el: JsonElement?): Boolean {
        val arr = el as? JsonArray ?: return false
        return arr.all { (it as? JsonPrimitive)?.isString == true }
    }

    private fun JsonObject.nonBlankString(key: String): Boolean {
        val p = this[key] as? JsonPrimitive ?: return false
        return p.isString && p.content.isNotBlank()
    }

    // ---- network ---------------------------------------------------------

    /** Resolve a manifest-relative path the way `new URL(rel, baseURI)` does. */
    private fun absolute(rel: String): String = URL(URL(BASE_URL), rel).toString()

    private fun fetchText(url: String, timeoutMs: Int): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = timeoutMs
        conn.readTimeout = timeoutMs
        // Belt and braces against every layer that might hold an old copy:
        // the JVM's own cache, the CDN, and any transparent proxy on a
        // school/campus network.
        conn.useCaches = false
        conn.setRequestProperty("Cache-Control", "no-store, no-cache, max-age=0")
        conn.setRequestProperty("Pragma", "no-cache")
        conn.setRequestProperty("Accept", "application/json")
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("HTTP $code for $url")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            runCatching { conn.disconnect() }
        }
    }

    /** Fetch the manifest fresh. Throws on network error, timeout, non-OK, an
     *  invalid manifest, or a contentVersion that is not path-safe. */
    private fun fetchManifest(): ContentManifest {
        val url = absolute(MANIFEST_PATH) + "?_=" + System.currentTimeMillis()
        val el = runCatching { strictJson.parseToJsonElement(fetchText(url, MANIFEST_TIMEOUT_MS)) }
            .getOrElse { throw IOException("manifest unreadable: ${it.message}") }
        if (!validateManifest(el)) throw IOException("manifest failed validation")
        val m = json.decodeFromJsonElement(ContentManifest.serializer(), el)
        if (!SAFE_VERSION.matches(m.contentVersion)) {
            throw IOException("contentVersion '${m.contentVersion}' is not a safe directory name")
        }
        return m
    }

    // ---- version storage -------------------------------------------------

    private fun versionDir(m: ContentManifest): File = File(contentDir, m.contentVersion)
    private fun vocabFile(m: ContentManifest): File = File(versionDir(m), "vocab.json")
    private fun indexFile(m: ContentManifest): File = File(versionDir(m), "audio-index.json")

    private fun writeAtomic(target: File, text: String) {
        target.parentFile?.mkdirs()
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeText(text)
        if (target.exists()) target.delete()
        if (!tmp.renameTo(target)) {
            tmp.delete()
            throw IOException("could not rename ${tmp.name} -> ${target.name}")
        }
    }

    /**
     * Download + validate both files for a manifest and store them under the
     * version's own directory. Atomic in the sense that matters: NOTHING is
     * written unless both files parse and validate, so a half-published or
     * corrupt release can never end up on disk. Reuses files already there.
     * Throws on any failure.
     */
    private suspend fun downloadVersion(m: ContentManifest): Cached = coroutineScope {
        val vFile = vocabFile(m)
        val iFile = indexFile(m)

        // Both files in parallel, mirroring the PWA's Promise.all -- on a slow
        // classroom connection this halves the worst case.
        val vDeferred = async(Dispatchers.IO) {
            val onDisk = if (vFile.isFile) runCatching { vFile.readText() }.getOrNull() else null
            onDisk?.let { it to true } ?: (fetchText(absolute(m.vocabUrl), DOWNLOAD_TIMEOUT_MS) to false)
        }
        val iDeferred = async(Dispatchers.IO) {
            val onDisk = if (iFile.isFile) runCatching { iFile.readText() }.getOrNull() else null
            onDisk?.let { it to true } ?: (fetchText(absolute(m.audioIndexUrl), DOWNLOAD_TIMEOUT_MS) to false)
        }
        val (vText, vCached) = vDeferred.await()
        val (iText, iCached) = iDeferred.await()

        val vEl = runCatching { strictJson.parseToJsonElement(vText) }
            .getOrElse { throw IOException("vocab is not valid JSON") }
        val iEl = runCatching { strictJson.parseToJsonElement(iText) }
            .getOrElse { throw IOException("audio-index is not valid JSON") }
        if (!validateVocab(vEl)) throw IOException("vocab failed validation")
        if (!validateAudioIndex(iEl)) throw IOException("audio-index failed validation")

        val bundle = json.decodeFromJsonElement(Bundle.serializer(), vEl)
        val clips = json.decodeFromJsonElement(clipListSerializer, iEl)

        // Write only after BOTH validated, so a bad file never lands on disk.
        if (!vCached) writeAtomic(vFile, vText)
        if (!iCached) writeAtomic(iFile, iText)
        Cached(bundle, clips)
    }

    /** Load an already-downloaded version from disk. Returns null if either file
     *  is missing or invalid, so the caller can fall back. The offline path. */
    private fun loadFromCache(m: ContentManifest): Cached? = runCatching {
        val vFile = vocabFile(m)
        val iFile = indexFile(m)
        if (!vFile.isFile || !iFile.isFile) return null
        val vEl = strictJson.parseToJsonElement(vFile.readText())
        val iEl = strictJson.parseToJsonElement(iFile.readText())
        if (!validateVocab(vEl) || !validateAudioIndex(iEl)) return null
        Cached(
            json.decodeFromJsonElement(Bundle.serializer(), vEl),
            json.decodeFromJsonElement(clipListSerializer, iEl)
        )
    }.getOrNull()

    /** The APK's own assets -- the emergency fallback for a device that has
     *  never successfully fetched remote content. */
    private fun loadBundled(): Cached {
        val vText = appContext.assets.open("vocab.json").bufferedReader().use { it.readText() }
        val vEl = runCatching { strictJson.parseToJsonElement(vText) }
            .getOrElse { throw IOException("bundled vocab.json is not valid JSON") }
        if (!validateVocab(vEl)) throw IOException("bundled vocab.json invalid")
        val bundle = json.decodeFromJsonElement(Bundle.serializer(), vEl)

        // A missing or broken bundled audio-index is survivable -- the student
        // just gets the device voice -- so it degrades to empty instead of
        // throwing. A missing bundled vocab.json is not survivable.
        val clips = runCatching {
            val iText = appContext.assets.open("audio-index.json").bufferedReader().use { it.readText() }
            val iEl = strictJson.parseToJsonElement(iText)
            if (!validateAudioIndex(iEl)) emptyList<String>()
            else json.decodeFromJsonElement(clipListSerializer, iEl)
        }.getOrDefault(emptyList<String>())

        return Cached(bundle, clips)
    }

    // ---- state persistence -----------------------------------------------

    /**
     * Written synchronously rather than fired at a scope like ProgressStore:
     * the active pointer must be durable BEFORE we tell anyone the update
     * succeeded, or a kill in that window resurrects the old version while the
     * new files sit unused on disk.
     */
    private fun persist(next: ContentState) {
        state = next
        if (!started) return
        runCatching {
            stateTmp.writeText(json.encodeToString(ContentState.serializer(), next))
            if (stateFile.exists()) stateFile.delete()
            stateTmp.renameTo(stateFile)
        }.onFailure { Log.w(TAG, "[content] could not persist state: ${it.message}") }
    }

    private fun setActive(m: ContentManifest) = persist(state.copy(active = m))
    private fun setPending(m: ContentManifest) = persist(state.copy(pending = m))
    private fun clearPending() = persist(state.copy(pending = null))
    private fun setLastCheck(ms: Long) = persist(state.copy(lastCheckMs = ms))

    /** Drop version directories that are neither active nor pending, so old
     *  releases do not accumulate. Best-effort; failures are ignored. */
    fun pruneOldVersions() {
        runCatching {
            val keep = listOfNotNull(state.active, state.pending)
                .map { it.contentVersion }
                .toSet()
            contentDir.listFiles()?.forEach { dir ->
                if (dir.isDirectory && dir.name !in keep) dir.deleteRecursively()
            }
        }
    }

    // ---- loading ---------------------------------------------------------

    /**
     * Last-known-good content load, the port of data.js load(). Runs at startup.
     * Never throws for a network reason; the only throw left is "even the
     * bundled vocab.json is gone", which means a broken APK.
     */
    suspend fun load(context: Context): LoadResult = withContext(Dispatchers.IO) {
        init(context)

        var appliedPending = false
        var updateAvailable = false
        var updateFailed = false
        var installedNew = false
        var usedBundled = false

        // 0. Promote a version downloaded in a previous session -- but only if
        //    its files are genuinely still on disk and still validate.
        state.pending?.let { pending ->
            if (loadFromCache(pending) != null) {
                setActive(pending)
                appliedPending = true
            }
            clearPending()
        }

        var active = state.active
        var loaded: Cached? = null
        var loadedManifest: ContentManifest? = null

        // 1. Fresh manifest. A throw here is expected on a plane, in a lift, or
        //    on a school wifi that eats TLS -- it must never fail the load.
        val fresh = runCatching { fetchManifest() }
            .onFailure { Log.w(TAG, "[content] manifest check failed: ${it.message}") }
            .getOrNull()

        if (fresh != null) {
            setLastCheck(System.currentTimeMillis())
            if (active == null || fresh.contentVersion != active.contentVersion) {
                updateAvailable = true
                val dl = runCatching { downloadVersion(fresh) }
                    .onFailure { Log.w(TAG, "[content] update failed, keeping last good: ${it.message}") }
                    .getOrNull()
                if (dl != null) {
                    setActive(fresh)          // pointer moves only after both files are on disk
                    active = fresh
                    loaded = dl
                    loadedManifest = fresh
                    installedNew = true
                } else {
                    updateFailed = true
                }
            }
        }

        // 2. Load the (retained) active version from disk.
        if (loaded == null && active != null) {
            val cached = loadFromCache(active)
            if (cached != null) {
                loaded = cached
                loadedManifest = active
            } else {
                Log.w(TAG, "[content] active version missing from disk; falling back to bundled")
            }
        }

        // 3. Bundled emergency fallback. loadedManifest is null here by
        //    construction -- it is only ever set together with `loaded`.
        val content: Cached = loaded ?: loadBundled().also { usedBundled = true }

        val audioVersion = loadedManifest?.audioVersion?.takeIf { it.isNotBlank() } ?: "1"
        val clipSlugs = content.clips.toSet()

        pruneOldVersions()

        // Remote words have no clip in the APK. Fetching them is a background
        // concern that must never hold up the first screen, so this only queues.
        AudioCache.sync(appContext, clipSlugs, audioVersion)

        LoadResult(
            bundle = content.bundle,
            clipSlugs = clipSlugs,
            activeVersion = loadedManifest?.contentVersion,
            audioVersion = audioVersion,
            usedBundled = usedBundled,
            installedNew = installedNew,
            appliedPending = appliedPending,
            updateAvailable = updateAvailable,
            updateFailed = updateFailed
        )
    }

    /**
     * Check for a newer version. Called on foreground and from Settings.
     *   apply = true  -> swap now if it is safe (no drill in progress)
     *   apply = false -> download it and hold it as pending for the next launch
     *
     * On [UpdateOutcome.Updated] the caller must hand `content.bundle` to
     * VocabRepository; this object deliberately does not reach into it.
     */
    suspend fun checkForUpdate(context: Context, apply: Boolean): UpdateOutcome =
        withContext<UpdateOutcome>(Dispatchers.IO) {
            init(context)

            val fresh = runCatching { fetchManifest() }
                .onFailure { Log.w(TAG, "[content] check failed: ${it.message}") }
                .getOrNull() ?: return@withContext UpdateOutcome.Failed

            setLastCheck(System.currentTimeMillis())

            val active = state.active
            val pending = state.pending
            val haveIt = active?.contentVersion == fresh.contentVersion ||
                pending?.contentVersion == fresh.contentVersion

            // Already running it, and nothing queued behind it.
            if (active?.contentVersion == fresh.contentVersion && pending == null) {
                return@withContext UpdateOutcome.UpToDate
            }

            var dl: Cached? = null
            if (!haveIt) {
                dl = runCatching { downloadVersion(fresh) }
                    .onFailure { Log.w(TAG, "[content] update download failed: ${it.message}") }
                    .getOrNull()
                // A failed download leaves active and pending exactly as they were.
                if (dl == null) return@withContext UpdateOutcome.Failed
            }

            if (!apply) {
                setPending(fresh)
                return@withContext UpdateOutcome.Downloaded
            }

            val cached = dl ?: loadFromCache(fresh) ?: return@withContext UpdateOutcome.Failed
            setActive(fresh)
            clearPending()
            pruneOldVersions()

            val audioVersion = fresh.audioVersion.takeIf { it.isNotBlank() } ?: "1"
            val clipSlugs = cached.clips.toSet()
            AudioCache.sync(appContext, clipSlugs, audioVersion)

            UpdateOutcome.Updated(
                LoadResult(
                    bundle = cached.bundle,
                    clipSlugs = clipSlugs,
                    activeVersion = fresh.contentVersion,
                    audioVersion = audioVersion,
                    usedBundled = false,
                    installedNew = true,
                    appliedPending = false,
                    updateAvailable = true,
                    updateFailed = false
                )
            )
        }

    /**
     * Apply a version downloaded earlier, if its files are still good. Call this
     * on a safe navigation (back at the library, nothing in progress) so a
     * mid-session download lands without interrupting a drill. Returns null when
     * there is nothing to apply.
     */
    suspend fun applyPendingIfReady(context: Context): LoadResult? = withContext<LoadResult?>(Dispatchers.IO) {
        init(context)
        val pending = state.pending ?: return@withContext null
        val cached = loadFromCache(pending)
        if (cached == null) {
            clearPending()
            return@withContext null
        }
        setActive(pending)
        clearPending()
        pruneOldVersions()

        val audioVersion = pending.audioVersion.takeIf { it.isNotBlank() } ?: "1"
        val clipSlugs = cached.clips.toSet()
        AudioCache.sync(appContext, clipSlugs, audioVersion)

        LoadResult(
            bundle = cached.bundle,
            clipSlugs = clipSlugs,
            activeVersion = pending.contentVersion,
            audioVersion = audioVersion,
            usedBundled = false,
            installedNew = true,
            appliedPending = true,
            updateAvailable = false,
            updateFailed = false
        )
    }
}
