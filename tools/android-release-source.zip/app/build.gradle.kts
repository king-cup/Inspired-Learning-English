import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.serialization")
}

// Optional release signing. Provide either a keystore.properties file locally,
// or the KEYSTORE_FILE / KEYSTORE_PASSWORD / KEY_ALIAS / KEY_PASSWORD env vars in CI.
val keystorePropsFile = rootProject.file("keystore.properties")
val keystoreProps = Properties().apply {
    if (keystorePropsFile.exists()) keystorePropsFile.inputStream().use { load(it) }
}
fun sign(key: String, envName: String): String? =
    (keystoreProps.getProperty(key) ?: System.getenv(envName))?.takeIf { it.isNotBlank() }

val ksPath = sign("storeFile", "KEYSTORE_FILE")
val ksFile = ksPath?.let { rootProject.file(it) }
val hasSigning = ksFile != null && ksFile.exists()

android {
    namespace = "com.vocabdrill.student"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vocabdrill.student"
        minSdk = 24
        targetSdk = 34
        versionCode = 13
        versionName = providers.gradleProperty("previewVersion").orElse("1.10.2").get()
        vectorDrawables { useSupportLibrary = true }
    }

    if (hasSigning) {
        signingConfigs {
            create("release") {
                storeFile = ksFile
                storePassword = sign("storePassword", "KEYSTORE_PASSWORD")
                keyAlias = sign("keyAlias", "KEY_ALIAS")
                keyPassword = sign("keyPassword", "KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // If no keystore was supplied, fall back to the debug key so the APK
            // is still installable. Note: debug-signed builds cannot upgrade a
            // release-signed install and vice versa.
            signingConfig = if (hasSigning) signingConfigs.getByName("release")
                            else signingConfigs.getByName("debug")
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        create("preview") {
            initWith(getByName("release"))
            applicationIdSuffix = ".preview"
            versionNameSuffix = "-preview"
            resValue("string", "app_name", "Inspired Preview")
            matchingFallbacks += "release"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { compose = true }
    // Only the shared learner release ships; old native assets stay in source.
    sourceSets.getByName("main").assets.setSrcDirs(listOf("build/generated/learner-assets"))
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }

    // Audio assets must stay uncompressed so MediaPlayer can stream them
    // straight out of the APK via AssetFileDescriptor.
    androidResources {
        noCompress += "ogg"
        noCompress += "opus"
        noCompress += "m4a"
    }

    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
