// Repository wiring.
//
// Building from mainland China, Gradle's own downloads from dl.google.com and
// repo1.maven.org die with "SSL peer shut down incorrectly" even though curl
// reaches both fine -- so the Aliyun mirrors go first and upstream stays as a
// fallback. On CI (GitHub sets CI=true) the mirrors are skipped entirely,
// because a US runner should go straight to the source.

val useCnMirrors = System.getenv("CI").isNullOrBlank()

pluginManagement {
    repositories {
        if (System.getenv("CI").isNullOrBlank()) {
            maven("https://maven.aliyun.com/repository/google")
            maven("https://maven.aliyun.com/repository/central")
            maven("https://maven.aliyun.com/repository/gradle-plugin")
        }
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        if (System.getenv("CI").isNullOrBlank()) {
            maven("https://maven.aliyun.com/repository/google")
            maven("https://maven.aliyun.com/repository/central")
        }
        google()
        mavenCentral()
    }
}

rootProject.name = "VocabDrillStudent"
include(":app")
